use crate::detections::configs::StoredStatic;
use crate::detections::utils::write_color_buffer;
use crate::detections::{configs, utils};
use crate::filter::RuleExclude;
use crate::yaml::ParseYaml;
use hashbrown::HashMap;
use std::fs::{self, File};
use std::io::Write;
use termcolor::{BufferWriter, ColorChoice};

pub struct LevelTuning {}

impl LevelTuning {
    /// Rewrites the `level:` line of every rule file whose `id` appears in the level tuning
    /// CSV (rows of `id,new_level`), letting users persistently adjust rule severities.
    pub fn run(
        level_tuning_config_path: &str,
        rules_path: &str,
        stored_static: &StoredStatic,
    ) -> Result<(), String> {
        let read_result = match utils::read_csv(level_tuning_config_path) {
            Ok(csv_data) => csv_data,
            Err(e) => return Result::Err(e.to_string()),
        };

        // Read the tuning file into a rule-id -> new-level map.
        let mut tuning_map: HashMap<String, String> = HashMap::new();
        read_result.iter().try_for_each(|line| -> Result<(), String> {
            // Rows without any columns are already dropped at the read_csv stage, so first()
            // is never None.
            let id = line.first().unwrap();
            if !configs::IDS_REGEX.is_match(id) {
                return Result::Err(format!("Failed to read level tuning file. {id} is not correct id format, fix it."));
            }

            // The level column accepts "info" as an abbreviation of "informational" and may
            // carry a trailing inline comment after '#'
            // (e.g. "high # 'Rule title' - Originally critical"); only the part before '#'
            // is kept.
            let level = match line.get(1) {
                Some(_level) => {
                    if _level.starts_with("informational")
                        || _level.starts_with("low")
                        || _level.starts_with("medium")
                        || _level.starts_with("high")
                        || _level.starts_with("critical") {
                            _level.split('#').collect::<Vec<&str>>()[0].to_string()
                        } else if _level.starts_with("info"){
                            _level.split('#').collect::<Vec<&str>>()[0].to_string().replace("info", "informational")
                        }
                        else {
                            return Result::Err("level tuning file's level must in informational, low, medium, high, critical".to_string())
                        }
                    }
                // This only happens when the CSV header row has fewer than two columns: the csv
                // reader drops any row whose column count differs from the header's.
                _ => return Result::Err("Failed to read level...".to_string())
            };
            tuning_map.insert(id.to_string(), level);
            Ok(())
        })?;

        // Read the rule files.
        let mut rulefile_loader = ParseYaml::new(stored_static);
        // An empty RuleExclude is passed so that noisy and excluded rules are also treated as
        // update targets.
        let result_readdir = rulefile_loader.read_dir(
            rules_path,
            "informational",
            "",
            &RuleExclude::new(),
            stored_static,
        );
        if let Err(e) = result_readdir {
            return Result::Err(format!("{}", e));
        }

        // Rewrite the level of every loaded rule whose id appears in the tuning map, by plain
        // string replacement of the "level: <old>" text in the rule file.
        for (path, rule) in rulefile_loader.files {
            if let Some(new_level) = tuning_map.get(rule["id"].as_str().unwrap()) {
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    None,
                    &format!("path: {path}"),
                    true,
                )
                .ok();
                let mut content = match fs::read_to_string(&path) {
                    Ok(_content) => _content,
                    Err(e) => return Result::Err(e.to_string()),
                };
                let past_level = "level: ".to_string() + rule["level"].as_str().unwrap();

                if new_level.starts_with("informational") || new_level.starts_with("info") {
                    content = content.replace(&past_level, "level: informational");
                }
                if new_level.starts_with("low") {
                    content = content.replace(&past_level, "level: low");
                }
                if new_level.starts_with("medium") {
                    content = content.replace(&past_level, "level: medium");
                }
                if new_level.starts_with("high") {
                    content = content.replace(&past_level, "level: high");
                }
                if new_level.starts_with("critical") {
                    content = content.replace(&past_level, "level: critical");
                }

                let mut file = match File::options().write(true).truncate(true).open(&path) {
                    Ok(file) => file,
                    Err(e) => return Result::Err(e.to_string()),
                };

                file.write_all(content.as_bytes()).unwrap();
                file.flush().unwrap();
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    None,
                    &format!(
                        "level: {} -> {}",
                        rule["level"].as_str().unwrap(),
                        new_level
                    ),
                    true,
                )
                .ok();
            }
        }
        println!();
        Result::Ok(())
    }
}

#[cfg(test)]
mod tests {

    use std::path::Path;

    use super::*;
    use crate::detections::configs::{Action, CommonOptions, Config, LevelTuningOption};

    fn create_dummy_stored_static(level_tuning_path: &str) -> StoredStatic {
        StoredStatic::create_static_data(Config {
            action: Some(Action::LevelTuning(LevelTuningOption {
                level_tuning: Path::new(level_tuning_path).to_path_buf(),
                common_options: CommonOptions {
                    no_color: false,
                    quiet: false,
                    help: None,
                },
            })),
            debug: false,
        })
    }

    #[test]
    fn rule_level_failed_to_open_file() {
        let level_tuning_config_path = "./none.txt";
        let dummy_stored_static = create_dummy_stored_static(level_tuning_config_path);
        let res = LevelTuning::run(level_tuning_config_path, "", &dummy_stored_static);
        let expected = Result::Err("Cannot open file. [file:./none.txt]".to_string());
        assert_eq!(res, expected);
    }

    #[test]
    fn rule_level_id_error_file() {
        let level_tuning_config_path = "./test_files/config/level_tuning_error1.txt";
        let dummy_stored_static = create_dummy_stored_static(level_tuning_config_path);
        let res = LevelTuning::run(level_tuning_config_path, "", &dummy_stored_static);
        let expected = Result::Err("Failed to read level tuning file. 12345678-1234-1234-1234-12 is not correct id format, fix it.".to_string());
        assert_eq!(res, expected);
    }

    #[test]
    fn rule_level_level_error_file() {
        let level_tuning_config_path = "./test_files/config/level_tuning_error2.txt";
        let dummy_stored_static = create_dummy_stored_static(level_tuning_config_path);
        let res = LevelTuning::run(level_tuning_config_path, "", &dummy_stored_static);
        let expected = Result::Err(
            "level tuning file's level must in informational, low, medium, high, critical"
                .to_string(),
        );
        assert_eq!(res, expected);
    }

    #[test]
    fn rule_level_level_error_empty_line() {
        let level_tuning_config_path = "./test_files/config/level_tuning_error3.txt";
        let dummy_stored_static = create_dummy_stored_static(level_tuning_config_path);
        let res = LevelTuning::run(level_tuning_config_path, "", &dummy_stored_static);
        let expected = Result::Err("Failed to read level...".to_string());
        assert_eq!(res, expected);
    }

    #[test]
    fn test_level_tuning_update_rule_files() {
        let level_tuning_config_path = "./test_files/config/level_tuning.txt";
        let rule_str = r#"
id: 12345678-1234-1234-1234-123456789012
date: 2025-03-01
level: informational
status: test
author: A
title: Samurai
logsource:
    product: windows
    service: security
detection:
    selection:
        Channel: Security
        EventID: 4624
        LogonType: 0
    condition: selection
ruletype: Hayabusa
        "#;

        let expected_rule = r#"
id: 12345678-1234-1234-1234-123456789012
date: 2025-03-01
level: high
status: test
author: A
title: Samurai
logsource:
    product: windows
    service: security
detection:
    selection:
        Channel: Security
        EventID: 4624
        LogonType: 0
    condition: selection
ruletype: Hayabusa
        "#;
        let path = "test_files/rules/level_tuning_test.yml";
        let mut file = File::create(path).unwrap();
        let buf = rule_str.as_bytes();
        file.write_all(buf).unwrap();
        file.flush().unwrap();

        let mut dummy_stored_static = create_dummy_stored_static(path);
        dummy_stored_static.include_status.insert("*".into());
        let res = LevelTuning::run(level_tuning_config_path, path, &dummy_stored_static);
        assert_eq!(res, Ok(()));

        assert_eq!(fs::read_to_string(path).unwrap(), expected_rule);
        fs::remove_file(path).unwrap();
    }
}
