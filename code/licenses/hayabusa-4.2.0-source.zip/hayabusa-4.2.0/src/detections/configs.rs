use super::message::create_output_filter_config;
use super::utils::check_setting_path;
use crate::detections::field_data_map::{FieldDataMap, create_field_data_map};
use crate::detections::message::AlertMessage;
use crate::detections::utils;
use crate::level::LEVEL;
use crate::options::geoip_search::GeoIPSearch;
use crate::options::htmlreport;
use crate::options::pivot::PivotKeywordMap;
use crate::options::profile::{Profile, load_profile};
use aho_corasick::{AhoCorasick, AhoCorasickBuilder, MatchKind};
use chrono::{DateTime, Days, Duration, Local, Months, Utc};
use clap::{
    ArgAction, ArgGroup, Args, ColorChoice, Command, CommandFactory, Parser, Subcommand, ValueEnum,
};
use compact_str::CompactString;
use dashmap::{DashMap, DashSet};
use hashbrown::{HashMap, HashSet};
use itertools::Itertools;
use lazy_static::lazy_static;
use nested::Nested;
use regex::Regex;
use std::cmp::PartialEq;
use std::env::current_exe;
use std::fs::File;
use std::io::BufRead;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, RwLock};
use std::{fs, io, process};
use strum::IntoEnumIterator;
use terminal_size::{Width, terminal_size};
use yaml_rust2::{Yaml, YamlLoader};

lazy_static! {
    pub static ref CURRENT_EXE_PATH: PathBuf =
        current_exe().unwrap().parent().unwrap().to_path_buf();
    // Matches UUID-formatted ids (e.g. the "id" field of Sigma rules).
    pub static ref IDS_REGEX: Regex =
        Regex::new(r"^[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}$").unwrap();
    // Maps every C0 control character (0x00-0x1F, except line feed) to its JSON-style \u00XX escape.
    pub static ref CONTROL_CHAR_REPLACE_MAP: HashMap<char, CompactString> =
        create_control_char_replace_map();
    // All-in-one config bundle (embedded file path -> file content). When rules_config_files.txt
    // exists, its entries are used instead of the individual files under rules/config.
    pub static ref ONE_CONFIG_MAP: HashMap<String, String> =
        read_one_config_file(Path::new("rules_config_files.txt")).unwrap_or_default();
    // Dash variants (hyphen, en dash, em dash, etc.) that the Sigma "windash" modifier treats as
    // interchangeable.
    pub static ref WINDASH_CHARACTERS: Vec<char> = load_windash_characters(
        check_setting_path(
            &CURRENT_EXE_PATH.to_path_buf(),
            "rules/config/windash_characters.txt",
            true,
        )
        .unwrap()
        .to_str()
        .unwrap(),
    );
    // (OS version, build number) -> (Windows product name, release date), loaded from
    // windows_versions.csv.
    pub static ref WIN_VERSIONS: HashMap<(String, String), (String, String)> = load_win_versions();
}

/// Parses the all-in-one config bundle (rules_config_files.txt), in which multiple rule config
/// files are concatenated with `---FILE_START---` / `path: ` / `---CONTENT---` / `---FILE_END---`
/// markers. Returns a map from each embedded file path to its content.
fn read_one_config_file(file_path: &Path) -> io::Result<HashMap<String, String>> {
    let file = File::open(file_path)?;
    let reader = io::BufReader::new(file);

    let mut sections = HashMap::new();
    let mut current_path = String::new();
    let mut current_content = String::new();
    let mut in_content = false;

    for line in reader.lines() {
        let line = line?;
        if line.starts_with("---FILE_START---") {
            current_path.clear();
            current_content.clear();
            in_content = false;
        } else if let Some(path) = line.strip_prefix("path: ") {
            current_path = path.to_string();
        } else if line.starts_with("---CONTENT---") {
            in_content = true;
        } else if line.starts_with("---FILE_END---") {
            sections.insert(current_path.clone(), current_content.clone());
        } else if in_content {
            current_content.push_str(&line);
            current_content.push('\n');
        }
    }
    Ok(sections)
}

/// Holds the clap command definition (used for help output) together with the parsed CLI config.
pub struct ConfigReader {
    pub app: Command,
    pub config: Option<Config>,
}

impl Default for ConfigReader {
    fn default() -> Self {
        Self::new()
    }
}

/// Per-computer MITRE ATT&CK tactic accumulator for the HTML report: computer name -> list of
/// (tactic name, unique alert count, total alert count).
pub type ComputerMitreAttckMap = DashMap<CompactString, Vec<(CompactString, i64, i64)>>;

/// Application state resolved once at startup from the CLI options and config files, then shared
/// read-only for the rest of the run. A per-scan snapshot is wrapped in an `Arc` and cloned into
/// the per-rule parallel tasks in `Detection::execute_rules` (this replaced the former
/// `STORED_STATIC` process global).
#[derive(Debug, Clone)]
pub struct StoredStatic {
    pub config: Config,
    pub config_path: PathBuf,
    pub eventkey_alias: EventKeyAliasConfig,
    /// The loaded MaxMind GeoIP database reader, set only when `--geo-ip` is specified. Wrapped in
    /// `Arc` so `StoredStatic` stays `Clone` even though `GeoIPSearch` is not.
    pub geo_ip_search: Option<Arc<GeoIPSearch>>,
    /// The geoip field-mapping config (SrcIP/TgtIP alias lists), set only when `--geo-ip` is used.
    pub geo_ip_db_yaml: Option<HashMap<CompactString, Yaml>>,
    /// The geoip filter config (channel/EID conditions), set only when `--geo-ip` is used.
    pub geo_ip_filter: Option<Vec<Yaml>>,
    pub channel_abbr_config: HashMap<CompactString, CompactString>,
    pub generic_abbr_matcher: AhoCorasick,
    pub generic_abbr_values: Vec<CompactString>,
    pub provider_abbr_config: HashMap<CompactString, CompactString>,
    pub quiet_errors_flag: bool,
    pub verbose_flag: bool,
    pub metrics_flag: bool,
    pub logon_summary_flag: bool,
    pub search_flag: bool,
    pub computer_metrics_flag: bool,
    pub log_metrics_flag: bool,
    pub extract_base64_flag: bool,
    pub search_option: Option<SearchOption>,
    pub output_option: Option<OutputOption>,
    pub pivot_keyword_list_flag: bool,
    /// Pivot keyword accumulator for the `pivot-keywords-list` command: categories/fields are
    /// loaded up front and the keyword values are filled in from the per-record parallel tasks.
    /// `Arc<RwLock<..>>` so the per-scan snapshot cloned into the parallel tasks shares the same
    /// map (replaces the former `PIVOT_KEYWORD` process global).
    pub pivot_keyword: Arc<RwLock<PivotKeywordMap>>,
    /// Errors collected while a run is in progress, flushed to `./logs/errorlog-<timestamp>.log`
    /// by `AlertMessage::create_error_log()`. `Arc<Mutex<..>>` so the per-scan snapshot cloned into
    /// the parallel tasks shares the same stack — errors are pushed from the per-record parallel
    /// tasks too (e.g. a `count(field)` miss). Replaces the former `ERROR_LOG_STACK` process
    /// global.
    pub error_log_stack: Arc<Mutex<Nested<String>>>,
    /// Per-computer MITRE ATT&CK tactics for the HTML report. `Arc<DashMap<..>>` so the per-scan
    /// snapshot cloned into the parallel tasks shares the same map — entries are pushed from the
    /// per-record parallel tasks (`create_log_record` in `execute_rule`) and read back when the
    /// report is rendered. Replaces the former `COMPUTER_MITRE_ATTCK_MAP` process global.
    pub computer_mitre_attck_map: Arc<ComputerMitreAttckMap>,
    /// Set of `"computer|tactic|rule path"` keys already counted, distinguishing a tactic's unique
    /// alert count from its total. `Arc<DashSet<..>>` for the same reason as `computer_mitre_attck_map`;
    /// replaces the former `COMPUTER_MITRE_ATTCK_UNIQUE_KEYS` global.
    pub computer_mitre_attck_unique_keys: Arc<DashSet<CompactString>>,
    pub default_details: HashMap<CompactString, CompactString>,
    pub html_report_flag: bool,
    pub profiles: Option<Vec<(CompactString, Profile)>>,
    pub event_timeline_config: EventInfoConfig,
    pub target_eventids: TargetIds,
    pub target_ruleids: TargetIds,
    pub thread_number: Option<usize>,
    pub json_input_flag: bool,
    pub output_path: Option<PathBuf>,
    pub common_options: CommonOptions,
    pub multiline_flag: bool,
    pub tab_separator_flag: bool,
    pub include_computer: HashSet<CompactString>,
    pub exclude_computer: HashSet<CompactString>,
    pub include_eid: HashSet<CompactString>,
    pub exclude_eid: HashSet<CompactString>,
    pub include_status: HashSet<CompactString>, // Set of statuses for rules to load. * loads all statuses.
    pub field_data_map: Option<FieldDataMap>,
    pub no_pwsh_field_extraction: bool,
    pub enable_recover_records: bool,
    pub time_offset: Option<String>,
    pub is_low_memory: bool,
    pub enable_all_rules: bool,
    pub scan_all_evtx_files: bool,
    pub metrics_remove_duplication: bool,
    pub disable_abbreviation: bool,
    pub validate_checksum: bool,
}

/// Resolves a bundled config file: prefer `<config_path>/<name>`, otherwise fall back to the
/// `rules/config/<name>` copy shipped next to the executable. Collapses the config-file fallback
/// chain that was previously copy-pasted for every setting file. `config_path` is the `-c` custom
/// rules-config directory, so honoring it here is what makes `-c` apply to every config file.
pub fn resolve_config_file(config_path: &Path, name: &str) -> PathBuf {
    check_setting_path(config_path, name, false).unwrap_or_else(|| {
        check_setting_path(
            &CURRENT_EXE_PATH.to_path_buf(),
            &format!("rules/config/{name}"),
            true,
        )
        .unwrap()
    })
}

/// Returns true when `level` is one of the recognized detection levels (case-insensitive).
fn is_valid_level(level: &str) -> bool {
    LEVEL::iter().any(|l| l.eq(level.to_lowercase().as_str()))
}

/// Builds a `HashSet<CompactString>` from an optional list of computer/EID filter values.
/// Mirrors the `.as_ref().unwrap_or(&vec![]).iter().map(CompactString::from).collect()` idiom
/// that was repeated for every subcommand's include/exclude filters.
fn compact_string_set(values: Option<&Vec<String>>) -> HashSet<CompactString> {
    values
        .map(|v| v.iter().map(CompactString::from).collect())
        .unwrap_or_default()
}

impl StoredStatic {
    /// Builds the StoredStatic data set from the command-line options parsed in main.rs.
    pub fn create_static_data(config: Config) -> StoredStatic {
        let action = config.action.as_ref();
        let action_id = Action::to_usize(action);
        let quiet_errors_flag = match action {
            Some(Action::DfirTimeline(opt)) => {
                opt.output_options.detect_common_options.quiet_errors
            }
            Some(Action::LogonSummary(opt)) => opt.detect_common_options.quiet_errors,
            Some(Action::EidMetrics(opt)) => opt.detect_common_options.quiet_errors,
            Some(Action::ExpandList(opt)) => opt.common_options.quiet,
            Some(Action::ExtractBase64(opt)) => opt.detect_common_options.quiet_errors,
            Some(Action::PivotKeywordsList(opt)) => opt.detect_common_options.quiet_errors,
            Some(Action::Search(opt)) => opt.quiet_errors,
            Some(Action::ComputerMetrics(opt)) => opt.quiet_errors,
            Some(Action::LogMetrics(opt)) => opt.detect_common_options.quiet_errors,
            _ => false,
        };
        let common_options = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.common_options,
            Some(Action::LevelTuning(opt)) => opt.common_options,
            Some(Action::LogonSummary(opt)) => opt.common_options,
            Some(Action::EidMetrics(opt)) => opt.common_options,
            Some(Action::ExtractBase64(opt)) => opt.common_options,
            Some(Action::PivotKeywordsList(opt)) => opt.common_options,
            Some(Action::SetDefaultProfile(opt)) => opt.common_options,
            Some(Action::ListContributors(opt)) | Some(Action::ListProfiles(opt)) => *opt,
            Some(Action::UpdateRules(opt)) => opt.common_options,
            Some(Action::Search(opt)) => opt.common_options,
            Some(Action::ComputerMetrics(opt)) => opt.common_options,
            Some(Action::LogMetrics(opt)) => opt.common_options,
            Some(Action::ExpandList(opt)) => opt.common_options,
            Some(Action::ConfigCriticalSystems(opt)) => opt.common_options,
            Some(Action::SortCsv(opt)) => opt.common_options,
            None => CommonOptions {
                no_color: false,
                quiet: false,
                help: None,
            },
        };
        let binding = Path::new("./rules/config").to_path_buf();
        let config_path = match action {
            Some(Action::DfirTimeline(opt)) => &opt.output_options.detect_common_options.config,
            Some(Action::LogonSummary(opt)) => &opt.detect_common_options.config,
            Some(Action::EidMetrics(opt)) => &opt.detect_common_options.config,
            Some(Action::ExtractBase64(opt)) => &opt.detect_common_options.config,
            Some(Action::PivotKeywordsList(opt)) => &opt.detect_common_options.config,
            Some(Action::Search(opt)) => &opt.config,
            Some(Action::ComputerMetrics(opt)) => &opt.config,
            Some(Action::LogMetrics(opt)) => &opt.detect_common_options.config,
            _ => &binding,
        };
        let verbose_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.detect_common_options.verbose,
            Some(Action::LogonSummary(opt)) => opt.detect_common_options.verbose,
            Some(Action::EidMetrics(opt)) => opt.detect_common_options.verbose,
            Some(Action::ExtractBase64(opt)) => opt.detect_common_options.verbose,
            Some(Action::PivotKeywordsList(opt)) => opt.detect_common_options.verbose,
            Some(Action::Search(opt)) => opt.verbose,
            Some(Action::ComputerMetrics(opt)) => opt.verbose,
            Some(Action::LogMetrics(opt)) => opt.detect_common_options.verbose,
            _ => false,
        };
        let json_input_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.detect_common_options.json_input,
            Some(Action::LogonSummary(opt)) => opt.detect_common_options.json_input,
            Some(Action::EidMetrics(opt)) => opt.detect_common_options.json_input,
            Some(Action::ExtractBase64(opt)) => opt.detect_common_options.json_input,
            Some(Action::PivotKeywordsList(opt)) => opt.detect_common_options.json_input,
            Some(Action::ComputerMetrics(opt)) => opt.json_input,
            Some(Action::LogMetrics(opt)) => opt.detect_common_options.json_input,
            _ => false,
        };
        let is_valid_min_level = match action {
            Some(Action::DfirTimeline(opt)) => is_valid_level(&opt.output_options.min_level),
            Some(Action::PivotKeywordsList(opt)) => is_valid_level(&opt.min_level),
            _ => true,
        };
        let is_valid_exact_level = match action {
            Some(Action::DfirTimeline(opt)) => opt
                .output_options
                .exact_level
                .as_ref()
                .is_none_or(|level| is_valid_level(level)),
            Some(Action::PivotKeywordsList(opt)) => opt
                .exact_level
                .as_ref()
                .is_none_or(|level| is_valid_level(level)),
            _ => true,
        };
        if !is_valid_min_level || !is_valid_exact_level {
            AlertMessage::alert(" You specified an invalid level. Please specify informational, low, medium, high or critical.").ok();
            process::exit(1);
        }

        let geo_ip_db_result = match action {
            Some(Action::DfirTimeline(opt)) => GeoIPSearch::check_exist_geo_ip_files(
                &opt.geo_ip,
                vec![
                    "GeoLite2-ASN.mmdb",
                    "GeoLite2-Country.mmdb",
                    "GeoLite2-City.mmdb",
                ],
            ),
            Some(Action::LogonSummary(opt)) => GeoIPSearch::check_exist_geo_ip_files(
                &opt.geo_ip,
                vec![
                    "GeoLite2-ASN.mmdb",
                    "GeoLite2-Country.mmdb",
                    "GeoLite2-City.mmdb",
                ],
            ),
            _ => Ok(None),
        };
        if let Err(err_msg) = geo_ip_db_result {
            AlertMessage::alert(&err_msg).ok();
            process::exit(1);
        }
        let mut geo_ip_search: Option<Arc<GeoIPSearch>> = None;
        let mut geo_ip_filter: Option<Vec<Yaml>> = None;
        let mut geo_ip_db_yaml: Option<HashMap<CompactString, Yaml>> = None;
        if let Some(geo_ip_db_path) = geo_ip_db_result.unwrap() {
            geo_ip_search = Some(Arc::new(GeoIPSearch::new(
                &geo_ip_db_path,
                vec![
                    "GeoLite2-ASN.mmdb",
                    "GeoLite2-Country.mmdb",
                    "GeoLite2-City.mmdb",
                ],
            )));
            let geo_ip_file_path =
                check_setting_path(config_path, "geoip_field_mapping.yaml", false).unwrap_or_else(
                    || {
                        check_setting_path(
                            &CURRENT_EXE_PATH.to_path_buf(),
                            "rules/config/geoip_field_mapping.yaml",
                            true,
                        )
                        .unwrap()
                    },
                );
            if !geo_ip_file_path.exists()
                && !ONE_CONFIG_MAP.contains_key("geoip_field_mapping.yaml")
            {
                AlertMessage::alert(
                    "Could not find the geoip_field_mapping.yaml config file. Please run update-rules."
                )
                .ok();
                process::exit(1);
            }
            let contents = if ONE_CONFIG_MAP.contains_key("geoip_field_mapping.yaml") {
                ONE_CONFIG_MAP
                    .get("geoip_field_mapping.yaml")
                    .unwrap()
                    .as_str()
            } else {
                &fs::read_to_string(geo_ip_file_path).unwrap()
            };
            let geo_ip_mapping = if let Ok(loaded_yaml) = YamlLoader::load_from_str(contents) {
                loaded_yaml
            } else {
                AlertMessage::alert("Parse error in geoip_field_mapping.yaml.").ok();
                YamlLoader::load_from_str("").unwrap()
            };
            let target_map = &geo_ip_mapping[0];
            let empty_yaml_vec: Vec<Yaml> = vec![];
            geo_ip_filter = Some(
                target_map["Filter"]
                    .as_vec()
                    .unwrap_or(&empty_yaml_vec)
                    .to_owned(),
            );
            let mut static_geoip_conf = HashMap::new();
            let check_target_map = vec!["SrcIP", "TgtIP"];
            for check_key in check_target_map {
                if !target_map[check_key].is_badvalue()
                    && !target_map[check_key]
                        .as_vec()
                        .unwrap_or(&empty_yaml_vec)
                        .is_empty()
                {
                    static_geoip_conf.insert(
                        CompactString::from(check_key),
                        target_map[check_key].clone(),
                    );
                }
            }
            geo_ip_db_yaml = Some(static_geoip_conf);
        };
        let output_path = match action {
            Some(Action::DfirTimeline(opt)) => opt.output.as_ref(),
            Some(Action::EidMetrics(opt)) => opt.output.as_ref(),
            Some(Action::ExtractBase64(opt)) => opt.output.as_ref(),
            Some(Action::PivotKeywordsList(opt)) => opt.output.as_ref(),
            Some(Action::LogonSummary(opt)) => opt.output.as_ref(),
            Some(Action::Search(opt)) => opt.output.as_ref(),
            Some(Action::ComputerMetrics(opt)) => opt.output.as_ref(),
            Some(Action::LogMetrics(opt)) => opt.output.as_ref(),
            _ => None,
        };
        let disable_abbreviation = match action {
            Some(Action::DfirTimeline(opt)) => opt.disable_abbreviations_opt.disable_abbreviations,
            Some(Action::Search(opt)) => opt.disable_abbreviations_opt.disable_abbreviations,
            Some(Action::LogMetrics(opt)) => opt.disable_abbreviations_opt.disable_abbreviations,
            _ => false,
        };

        let generic_abbreviations = create_output_filter_config(
            resolve_config_file(config_path, "generic_abbreviations.txt")
                .to_str()
                .unwrap(),
            false,
            disable_abbreviation,
        );
        let multiline_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.multiline,
            Some(Action::Search(opt)) => opt.multiline,
            Some(Action::LogMetrics(opt)) => opt.multiline,
            _ => false,
        };
        let tab_separator_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.tab_separator,
            Some(Action::Search(opt)) => opt.tab_separator,
            Some(Action::LogMetrics(opt)) => opt.tab_separator,
            _ => false,
        };
        let proven_rule_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.proven_rules,
            _ => false,
        };
        let target_ruleids = if proven_rule_flag {
            load_target_ids(
                resolve_config_file(config_path, "proven_rules.txt")
                    .to_str()
                    .unwrap(),
            )
        } else {
            TargetIds::default()
        };
        let include_computer: HashSet<CompactString> = match action {
            Some(Action::DfirTimeline(opt)) => compact_string_set(
                opt.output_options
                    .detect_common_options
                    .include_computer
                    .as_ref(),
            ),
            Some(Action::EidMetrics(opt)) => {
                compact_string_set(opt.detect_common_options.include_computer.as_ref())
            }
            Some(Action::ExtractBase64(opt)) => {
                compact_string_set(opt.detect_common_options.include_computer.as_ref())
            }
            Some(Action::PivotKeywordsList(opt)) => {
                compact_string_set(opt.detect_common_options.include_computer.as_ref())
            }
            Some(Action::LogonSummary(opt)) => {
                compact_string_set(opt.detect_common_options.include_computer.as_ref())
            }
            Some(Action::LogMetrics(opt)) => {
                compact_string_set(opt.detect_common_options.include_computer.as_ref())
            }
            _ => HashSet::default(),
        };
        let exclude_computer: HashSet<CompactString> = match action {
            Some(Action::DfirTimeline(opt)) => compact_string_set(
                opt.output_options
                    .detect_common_options
                    .exclude_computer
                    .as_ref(),
            ),
            Some(Action::EidMetrics(opt)) => {
                compact_string_set(opt.detect_common_options.exclude_computer.as_ref())
            }
            Some(Action::ExtractBase64(opt)) => {
                compact_string_set(opt.detect_common_options.exclude_computer.as_ref())
            }
            Some(Action::PivotKeywordsList(opt)) => {
                compact_string_set(opt.detect_common_options.exclude_computer.as_ref())
            }
            Some(Action::LogonSummary(opt)) => {
                compact_string_set(opt.detect_common_options.exclude_computer.as_ref())
            }
            Some(Action::LogMetrics(opt)) => {
                compact_string_set(opt.detect_common_options.exclude_computer.as_ref())
            }
            _ => HashSet::default(),
        };
        let include_eid: HashSet<CompactString> = match action {
            Some(Action::DfirTimeline(opt)) => {
                compact_string_set(opt.output_options.include_eid.as_ref())
            }
            Some(Action::PivotKeywordsList(opt)) => compact_string_set(opt.include_eid.as_ref()),
            _ => HashSet::default(),
        };
        let exclude_eid: HashSet<CompactString> = match action {
            Some(Action::DfirTimeline(opt)) => {
                compact_string_set(opt.output_options.exclude_eid.as_ref())
            }
            Some(Action::PivotKeywordsList(opt)) => compact_string_set(opt.exclude_eid.as_ref()),
            _ => HashSet::default(),
        };
        let no_field_data_mapping_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.no_field,
            _ => false,
        };
        let field_data_map = if no_field_data_mapping_flag {
            None
        } else {
            create_field_data_map(Path::new(
                resolve_config_file(config_path, "data_mapping")
                    .to_str()
                    .unwrap(),
            ))
        };

        let no_pwsh_field_extraction_flag = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.no_pwsh_field_extraction,
            _ => false,
        };

        let enable_recover_records = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.input_args.recover_records,
            Some(Action::EidMetrics(opt)) => opt.input_args.recover_records,
            Some(Action::ExtractBase64(opt)) => opt.input_args.recover_records,
            Some(Action::LogonSummary(opt)) => opt.input_args.recover_records,
            Some(Action::PivotKeywordsList(opt)) => opt.input_args.recover_records,
            Some(Action::Search(opt)) => opt.input_args.recover_records,
            Some(Action::LogMetrics(opt)) => opt.input_args.recover_records,
            _ => false,
        };
        let time_offset = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.input_args.time_offset.clone(),
            Some(Action::EidMetrics(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::ExtractBase64(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::LogonSummary(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::PivotKeywordsList(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::Search(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::ComputerMetrics(opt)) => opt.input_args.time_offset.clone(),
            Some(Action::LogMetrics(opt)) => opt.input_args.time_offset.clone(),
            _ => None,
        };
        let include_status: HashSet<CompactString> = match action {
            Some(Action::DfirTimeline(opt)) => opt
                .output_options
                .include_status
                .as_ref()
                .unwrap_or(&vec![])
                .iter()
                .map(|x| x.into())
                .collect(),
            Some(Action::PivotKeywordsList(opt)) => opt
                .include_status
                .as_ref()
                .unwrap_or(&vec![])
                .iter()
                .map(|x| x.into())
                .collect(),
            _ => HashSet::default(),
        };
        let is_low_memory = match action {
            Some(Action::DfirTimeline(opt)) => !opt.output_options.sort_events,
            _ => false,
        };
        let enable_all_rules = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.enable_all_rules,
            _ => false,
        };
        let scan_all_evtx_files = match action {
            Some(Action::DfirTimeline(opt)) => opt.output_options.scan_all_evtx_files,
            _ => false,
        };
        let metrics_remove_duplication = match action {
            Some(Action::EidMetrics(opt)) => opt.remove_duplicate_detections,
            Some(Action::LogonSummary(opt)) => opt.remove_duplicate_detections,
            _ => false,
        };
        let validate_checksum = match action {
            Some(Action::DfirTimeline(opt)) => {
                opt.output_options.detect_common_options.validate_checksums
            }
            Some(Action::LogonSummary(opt)) => opt.detect_common_options.validate_checksums,
            Some(Action::EidMetrics(opt)) => opt.detect_common_options.validate_checksums,
            Some(Action::ExtractBase64(opt)) => opt.detect_common_options.validate_checksums,
            Some(Action::PivotKeywordsList(opt)) => opt.detect_common_options.validate_checksums,
            Some(Action::Search(opt)) => opt.validate_checksums,
            Some(Action::ComputerMetrics(opt)) => opt.validate_checksums,
            Some(Action::LogMetrics(opt)) => opt.detect_common_options.validate_checksums,
            _ => false,
        };
        let mut ret = StoredStatic {
            config: config.to_owned(),
            config_path: config_path.to_path_buf(),
            channel_abbr_config: create_output_filter_config(
                resolve_config_file(config_path, "channel_abbreviations.txt")
                    .to_str()
                    .unwrap(),
                true,
                disable_abbreviation,
            ),
            generic_abbr_matcher: AhoCorasickBuilder::new()
                .ascii_case_insensitive(true)
                .match_kind(MatchKind::LeftmostLongest)
                .build(generic_abbreviations.keys().map(|x| x.as_str()))
                .unwrap(),
            generic_abbr_values: generic_abbreviations
                .values()
                .map(|x| x.to_owned())
                .collect_vec(),
            provider_abbr_config: create_output_filter_config(
                resolve_config_file(config_path, "provider_abbreviations.txt")
                    .to_str()
                    .unwrap(),
                false,
                disable_abbreviation,
            ),
            default_details: Self::get_default_details(
                resolve_config_file(config_path, "default_details.txt")
                    .to_str()
                    .unwrap(),
                disable_abbreviation,
            ),
            eventkey_alias: load_eventkey_alias(
                resolve_config_file(config_path, "eventkey_alias.txt")
                    .to_str()
                    .unwrap(),
            ),
            geo_ip_search,
            geo_ip_db_yaml,
            geo_ip_filter,
            // The numeric ids compared below come from Action::to_usize.
            logon_summary_flag: action_id == 2,
            metrics_flag: action_id == 3,
            search_flag: action_id == 10,
            computer_metrics_flag: action_id == 11,
            log_metrics_flag: action_id == 12,
            extract_base64_flag: action_id == 13,
            search_option: extract_search_options(&config),
            output_option: extract_output_options(&config),
            pivot_keyword_list_flag: action_id == 4,
            pivot_keyword: Arc::new(RwLock::new(PivotKeywordMap::new())),
            error_log_stack: Arc::new(Mutex::new(Nested::<String>::new())),
            computer_mitre_attck_map: Arc::new(DashMap::new()),
            computer_mitre_attck_unique_keys: Arc::new(DashSet::new()),
            quiet_errors_flag,
            verbose_flag,
            html_report_flag: htmlreport::check_html_flag(&config),
            profiles: None,
            thread_number: check_thread_number(&config),
            event_timeline_config: load_eventcode_info(
                resolve_config_file(config_path, "channel_eid_info.txt")
                    .to_str()
                    .unwrap(),
            ),
            target_eventids: load_target_ids(
                resolve_config_file(config_path, "target_event_IDs.txt")
                    .to_str()
                    .unwrap(),
            ),
            target_ruleids,
            json_input_flag,
            output_path: output_path.cloned(),
            common_options,
            multiline_flag,
            tab_separator_flag,
            include_computer,
            exclude_computer,
            include_eid,
            exclude_eid,
            field_data_map,
            no_pwsh_field_extraction: no_pwsh_field_extraction_flag,
            enable_recover_records,
            time_offset,
            include_status,
            is_low_memory,
            enable_all_rules,
            scan_all_evtx_files,
            metrics_remove_duplication,
            disable_abbreviation,
            validate_checksum,
        };
        ret.profiles = load_profile(
            check_setting_path(
                &CURRENT_EXE_PATH.to_path_buf(),
                "config/default_profile.yaml",
                true,
            )
            .unwrap()
            .to_str()
            .unwrap(),
            check_setting_path(
                &CURRENT_EXE_PATH.to_path_buf(),
                "config/profiles.yaml",
                true,
            )
            .unwrap()
            .to_str()
            .unwrap(),
            Some(&ret),
        );
        ret
    }
    /// Reads the default `details` output templates (per provider and EID) from
    /// default_details.txt.
    pub fn get_default_details(
        filepath: &str,
        disable_abbreviations: bool,
    ) -> HashMap<CompactString, CompactString> {
        if disable_abbreviations {
            return HashMap::new();
        }
        let read_result = utils::read_csv(filepath);
        match read_result {
            Err(_e) => {
                AlertMessage::alert(&_e).ok();
                HashMap::new()
            }
            Ok(lines) => {
                // Each line has the following format, in order: provider name, EID, then the
                // default `details` output template, e.g.:
                // Microsoft-Windows-Sysmon, 1, Cmdline: %CommandLine% ¦ Proc: %Image% ...

                let mut ret: HashMap<CompactString, CompactString> = HashMap::new();
                lines
                    .iter()
                    .try_for_each(|line| -> Result<(), String> {
                        let provider = match line.first() {
                            Some(_provider) => _provider.trim(),
                            _ => {
                                return Err(
                                    "Failed to read provider in default_details.txt.".to_string()
                                );
                            }
                        };
                        let eid = match line.get(1) {
                            Some(eid_str) => match eid_str.trim().parse::<i64>() {
                                Ok(_eid) => _eid,
                                _ => {
                                    return Err(
                                        "EventID parsing error in default_details.txt.".to_string()
                                    );
                                }
                            },
                            _ => {
                                return Err(
                                    "Failed to read EventID in default_details.txt.".to_string()
                                );
                            }
                        };
                        let details = match line.get(2) {
                            Some(detail) => detail.trim(),
                            _ => {
                                return Err(
                                    "Failed to read details in default_details.txt.".to_string()
                                );
                            }
                        };
                        // Since the combination of Provider and EID is unique, it is used as the key.
                        ret.insert(
                            CompactString::from(format!("{provider}_{eid}")),
                            CompactString::from(details),
                        );
                        Ok(())
                    })
                    .ok();
                ret
            }
        }
    }
}

/// Function to extract thread_number information from config.
fn check_thread_number(config: &Config) -> Option<usize> {
    match config.action.as_ref()? {
        Action::DfirTimeline(opt) => opt.output_options.detect_common_options.thread_number,
        Action::LogonSummary(opt) => opt.detect_common_options.thread_number,
        Action::EidMetrics(opt) => opt.detect_common_options.thread_number,
        Action::ExtractBase64(opt) => opt.detect_common_options.thread_number,
        Action::PivotKeywordsList(opt) => opt.detect_common_options.thread_number,
        Action::LogMetrics(opt) => opt.detect_common_options.thread_number,
        Action::Search(opt) => opt.thread_number,
        _ => None,
    }
}

// Clap definitions for command generation.

/// Release name shown in the CLI help banner (e.g. "CODE BLUE Release").
/// This is the only value to update when naming a new release; the version
/// number is pulled automatically from Cargo.toml (`CARGO_PKG_VERSION`).
pub const RELEASE_NAME: &str = "Autumn Release";

/// Builds a clap `help_template` banner. The first line is
/// `Hayabusa v<version> - <RELEASE_NAME>` (version from Cargo.toml) and `body`
/// is appended verbatim, so it must start with a newline.
fn help_banner(body: &str) -> String {
    format!(
        "\nHayabusa v{} - {}{}",
        env!("CARGO_PKG_VERSION"),
        RELEASE_NAME,
        body
    )
}

#[derive(Subcommand, Clone, Debug)]
pub enum Action {
    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe dfir-timeline <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 292,
        disable_help_flag = true
    )]
    /// Create a DFIR timeline
    DfirTimeline(DfirTimelineOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe log-metrics <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 382,
        disable_help_flag = true
    )]
    /// Output evtx file metadata
    LogMetrics(LogMetricsOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe logon-summary <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 383,
        disable_help_flag = true
    )]
    /// Output a summary of successful and failed logons
    LogonSummary(LogonSummaryOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe eid-metrics <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 310,
        disable_help_flag = true
    )]
    /// Output event ID metrics
    EidMetrics(EidMetricsOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe expand-list [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 311,
        disable_help_flag = true
    )]
    /// Extract expand placeholders from the rules folder
    ExpandList(ExpandListOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe extract-base64 <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 311,
        disable_help_flag = true
    )]
    /// Extract and decode base64 strings from events
    ExtractBase64(ExtractBase64Option),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe pivot-keywords-list <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 420,
        disable_help_flag = true
    )]
    /// Create a list of pivot keywords
    PivotKeywordsList(PivotKeywordOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe search <INPUT> <--keywords \"<KEYWORDS>\" OR --regex \"<REGEX>\"> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 450,
        disable_help_flag = true
    )]
    /// Search all events by keyword(s) or regular expression
    Search(SearchOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe update-rules [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 470,
        disable_help_flag = true
    )]
    /// Update to the latest rules in the hayabusa-rules github repository
    UpdateRules(UpdateOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe level-tuning [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 380,
        disable_help_flag = true
    )]
    /// Tune alert levels for the DFIR timeline
    LevelTuning(LevelTuningOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe set-default-profile [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 451,
        disable_help_flag = true
    )]
    /// Set default output profile for the DFIR timeline
    SetDefaultProfile(DefaultProfileOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe list-contributors [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 381,
        disable_help_flag = true
    )]
    /// Print the list of contributors
    ListContributors(CommonOptions),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe list-profiles [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 382,
        disable_help_flag = true
    )]
    /// List the output profiles for the DFIR timeline
    ListProfiles(CommonOptions),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe computer-metrics <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 290,
        disable_help_flag = true
    )]
    /// Output the total number of events according to computer names
    ComputerMetrics(ComputerMetricsOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe config-critical-systems <INPUT> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 291,
        disable_help_flag = true
    )]
    /// Find critical systems like domain controllers and file servers.
    ConfigCriticalSystems(ConfigCriticalSystemsOption),

    #[clap(
        author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
        help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe sort-csv <-f FILE | -d DIR> [OPTIONS]\n\n{all-args}"),
        term_width = 400,
        display_order = 452,
        disable_help_flag = true
    )]
    /// Sort a Hayabusa CSV by timestamp and remove duplicate detections
    SortCsv(SortCsvOption),
}

impl Action {
    /// Returns a stable numeric id for the given subcommand (100 when no subcommand was given).
    /// The action_id comparisons in create_static_data refer to these values.
    pub fn to_usize(action: Option<&Action>) -> usize {
        if let Some(a) = action {
            match a {
                Action::DfirTimeline(_) => 0,
                Action::LogonSummary(_) => 2,
                Action::EidMetrics(_) => 3,
                Action::PivotKeywordsList(_) => 4,
                Action::UpdateRules(_) => 5,
                Action::LevelTuning(_) => 6,
                Action::SetDefaultProfile(_) => 7,
                Action::ListContributors(_) => 8,
                Action::ListProfiles(_) => 9,
                Action::Search(_) => 10,
                Action::ComputerMetrics(_) => 11,
                Action::LogMetrics(_) => 12,
                Action::ExtractBase64(_) => 13,
                Action::ExpandList(_) => 14,
                Action::ConfigCriticalSystems(_) => 15,
                Action::SortCsv(_) => 16,
            }
        } else {
            100
        }
    }
    /// Returns the CLI name of the given subcommand (an empty string when no subcommand was
    /// given).
    pub fn get_action_name(action: Option<&Action>) -> &str {
        if let Some(a) = action {
            match a {
                Action::DfirTimeline(_) => "dfir-timeline",
                Action::LogonSummary(_) => "logon-summary",
                Action::EidMetrics(_) => "eid-metrics",
                Action::PivotKeywordsList(_) => "pivot-keywords-list",
                Action::UpdateRules(_) => "update-rules",
                Action::LevelTuning(_) => "level-tuning",
                Action::SetDefaultProfile(_) => "set-default-profile",
                Action::ListContributors(_) => "list-contributors",
                Action::ListProfiles(_) => "list-profiles",
                Action::Search(_) => "search",
                Action::ComputerMetrics(_) => "computer-metrics",
                Action::LogMetrics(_) => "log-metrics",
                Action::ExtractBase64(_) => "extract-base64",
                Action::ExpandList(_) => "expand-list",
                Action::ConfigCriticalSystems(_) => "config-critical-systems",
                Action::SortCsv(_) => "sort-csv",
            }
        } else {
            ""
        }
    }
}

#[derive(Args, Clone, Debug, Default)]
pub struct ClobberOption {
    /// Overwrite files when saving
    #[arg(help_heading = Some("General Options"), short='C', long = "clobber", display_order = 290, requires = "output")]
    pub clobber: bool,
}

#[derive(Args, Clone, Debug, Default)]
pub struct TimeRangeOption {
    /// End time of the event logs to load (ex: "2022-02-22 23:59:59 +09:00")
    #[arg(help_heading = Some("Filtering"), long = "timeline-end", value_name = "DATE", display_order = 460)]
    pub end_timeline: Option<String>,

    /// Start time of the event logs to load (ex: "2020-02-22 00:00:00 +09:00")
    #[arg(help_heading = Some("Filtering"), long = "timeline-start", value_name = "DATE", display_order = 460)]
    pub start_timeline: Option<String>,
}

#[derive(Args, Clone, Debug, Default)]
pub struct DisableAbbreviationsOption {
    /// Disable abbreviations
    #[arg(help_heading = Some("Output"), short='b', long = "disable-abbreviations", display_order = 60)]
    pub disable_abbreviations: bool,
}

#[derive(Args, Clone, Debug, Default)]
pub struct DetectCommonOption {
    /// Scan JSON formatted logs instead of .evtx (.json or .jsonl)
    #[arg(help_heading = Some("General Options"), short = 'J', long = "json-input", conflicts_with = "live_analysis", display_order = 360)]
    pub json_input: bool,

    /// Enable checksum validation
    #[arg(help_heading = Some("General Options"), short = 'V', long = "validate-checksums", display_order = 470)]
    pub validate_checksums: bool,

    /// Specify additional evtx file extensions (ex: evtx_data)
    #[arg(help_heading = Some("General Options"), long = "target-file-ext", value_name = "FILE-EXT...", use_value_delimiter = true, value_delimiter = ',', display_order = 460)]
    pub evtx_file_ext: Option<Vec<String>>,

    /// Number of threads (default: optimal number for performance)
    #[arg(
        help_heading = Some("General Options"),
        long = "threads",
        value_name = "NUMBER",
        display_order = 460
    )]
    pub thread_number: Option<usize>,

    /// Quiet errors mode: do not save error logs
    #[arg(help_heading = Some("General Options"), short = 'Q', long = "quiet-errors", display_order = 430)]
    pub quiet_errors: bool,

    /// Specify custom rule config directory (default: ./rules/config)
    #[arg(
        help_heading = Some("General Options"),
        short = 'c',
        long = "rules-config",
        default_value = "./rules/config",
        hide_default_value = true,
        value_name = "DIR",
        display_order = 442
    )]
    pub config: PathBuf,

    /// Output verbose information
    #[arg(help_heading = Some("Display Settings"), short = 'v', long, display_order = 480)]
    pub verbose: bool,

    /// Scan only specified computer names (ex: ComputerA) (ex: ComputerA,ComputerB)
    #[arg(help_heading = Some("Filtering"), long = "include-computer", value_name = "COMPUTER...", conflicts_with = "exclude-computer", use_value_delimiter = true, value_delimiter = ',', display_order = 352)]
    pub include_computer: Option<Vec<String>>,

    /// Do not scan specified computer names (ex: ComputerA) (ex: ComputerA,ComputerB)
    #[arg(help_heading = Some("Filtering"), long = "exclude-computer", value_name = "COMPUTER...", conflicts_with = "include_computer",use_value_delimiter = true, value_delimiter = ',', display_order = 314)]
    pub exclude_computer: Option<Vec<String>>,
}

#[derive(Args, Clone, Debug, Default)]
pub struct DefaultProfileOption {
    #[clap(flatten)]
    pub common_options: CommonOptions,
    /// Specify output profile
    #[arg(help_heading = Some("General Options"), short = 'p', long = "profile", display_order = 420)]
    pub profile: Option<String>,
}

#[derive(Args, Clone, Debug, Default)]
pub struct TimeFormatOptions {
    /// Output timestamp in European time format (ex: 22-02-2022 22:00:00.123 +02:00)
    #[arg(help_heading = Some("Time Format"), long = "european-time", display_order = 50)]
    pub european_time: bool,

    /// Output timestamp in original ISO-8601 format (ex: 2022-02-22T10:10:10.1234567Z) (Always UTC)
    #[arg(help_heading = Some("Time Format"), short = 'O', long = "iso-8601", display_order = 90)]
    pub iso_8601: bool,

    /// Output timestamp in RFC 2822 format (ex: Fri, 22 Feb 2022 22:00:00 -0600)
    #[arg(help_heading = Some("Time Format"), long = "rfc-2822", display_order = 180)]
    pub rfc_2822: bool,

    /// Output timestamp in RFC 3339 format (ex: 2022-02-22 22:00:00.123456-06:00)
    #[arg(help_heading = Some("Time Format"), long = "rfc-3339", display_order = 180)]
    pub rfc_3339: bool,

    /// Output timestamp in US military time format (ex: 02-22-2022 22:00:00.123 -06:00)
    #[arg(help_heading = Some("Time Format"), long = "us-military-time", display_order = 210)]
    pub us_military_time: bool,

    /// Output timestamp in US time format (ex: 02-22-2022 10:00:00.123 PM -06:00)
    #[arg(help_heading = Some("Time Format"), long = "us-time", display_order = 210)]
    pub us_time: bool,

    /// Output time in UTC format (default: local time)
    #[arg(help_heading = Some("Time Format"), short = 'U', long = "utc", display_order = 210)]
    pub utc: bool,
}

impl TimeFormatOptions {
    /// Whether the selected format renders timestamps in UTC instead of local time; the remaining
    /// formats (RFC 2822/3339, US, US military, European) are all local. Every output path asks
    /// this one question so that adding another always-UTC format cannot leave them disagreeing.
    pub fn is_utc_output(&self) -> bool {
        self.utc || self.iso_8601
    }
}

#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("search_input_filtering").args(["keywords", "regex"]).required(true)))]
pub struct SearchOption {
    #[clap(flatten)]
    pub common_options: CommonOptions,

    #[clap(flatten)]
    pub input_args: InputOption,

    /// Search by keyword(s)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'k',
        long = "keyword",
        value_name = "KEYWORD...",
        display_order = 370,
        conflicts_with = "regex",
    )]
    pub keywords: Option<Vec<String>>,

    /// Search by regular expression
    #[arg(
        help_heading = Some("Filtering"),
        short = 'r',
        long,
        value_name = "REGEX",
        display_order = 440,
        conflicts_with = "keywords",
    )]
    pub regex: Option<String>,

    /// Case-insensitive keyword search
    #[arg(
        help_heading = Some("Filtering"),
        short,
        long = "ignore-case",
        display_order = 350,
        conflicts_with = "regex",
    )]
    pub ignore_case: bool,

    /// Search keywords with AND logic (default: OR)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'a',
        long = "and-logic",
        value_name = "KEYWORD...",
        display_order = 270,
        conflicts_with = "regex",
        requires="keywords"
    )]
    pub and_logic: bool,

    /// Filter by specific field(s)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'F',
        long = "filter",
        value_name = "FILTER...",
        display_order = 320
    )]
    pub filter: Vec<String>,

    #[clap(flatten)]
    pub time_range: TimeRangeOption,

    /// Save the search results in CSV format (ex: search.csv)
    #[arg(
        help_heading = Some("Output"),
        short = 'o',
        long, value_name = "FILE",
        display_order = 410
    )]
    pub output: Option<PathBuf>,

    /// Specify additional evtx file extensions (ex: evtx_data)
    #[arg(help_heading = Some("General Options"), long = "target-file-ext", value_name = "FILE-EXT...", use_value_delimiter = true, value_delimiter = ',', display_order = 460)]
    pub evtx_file_ext: Option<Vec<String>>,

    /// Number of threads (default: optimal number for performance)
    #[arg(
            help_heading = Some("General Options"),
            long = "threads",
            value_name = "NUMBER",
            display_order = 460
        )]
    pub thread_number: Option<usize>,

    /// Quiet errors mode: do not save error logs
    #[arg(help_heading = Some("General Options"), short = 'Q', long = "quiet-errors", display_order = 430)]
    pub quiet_errors: bool,

    /// Specify custom rule config directory (default: ./rules/config)
    #[arg(
            help_heading = Some("General Options"),
            short = 'c',
            long = "rules-config",
            default_value = "./rules/config",
            hide_default_value = true,
            value_name = "DIR",
            display_order = 442
        )]
    pub config: PathBuf,

    /// Output verbose information
    #[arg(help_heading = Some("Display Settings"), short = 'v', long, display_order = 480)]
    pub verbose: bool,

    /// Separate event field information by newline characters for CSV output
    #[arg(help_heading = Some("Output"), short = 'M', long="multiline", conflicts_with = "tab_separator", display_order = 390)]
    pub multiline: bool,

    /// Separate event field information by tabs
    #[arg(help_heading = Some("Output"), short = 'S', long="tab-separator", requires = "output", conflicts_with = "multiline", display_order = 490)]
    pub tab_separator: bool,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    /// Save the search results in JSON format (ex: -J -o results.json)
    #[arg(help_heading = Some("Output"), short = 'J', long = "json-output", conflicts_with_all = ["jsonl_output", "multiline"], requires = "output", display_order = 100)]
    pub json_output: bool,

    /// Save the search results in JSONL format (ex: -L -o results.jsonl)
    #[arg(help_heading = Some("Output"), short = 'L', long = "jsonl-output", conflicts_with_all = ["jsonl_output", "multiline"], requires = "output", display_order = 100)]
    pub jsonl_output: bool,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    #[clap(flatten)]
    pub disable_abbreviations_opt: DisableAbbreviationsOption,

    /// Sort results before saving the file (warning: this uses much more memory!)
    #[arg(help_heading = Some("General Options"), short='s', long = "sort", display_order = 600)]
    pub sort_events: bool,

    /// Enable checksum validation
    #[arg(help_heading = Some("General Options"), short = 'V', long = "validate-checksums", display_order = 600)]
    pub validate_checksums: bool,
}

#[derive(Args, Clone, Debug, Default)]
pub struct UpdateOption {
    #[clap(flatten)]
    pub common_options: CommonOptions,

    /// Specify a custom rule directory or file (default: ./rules)
    #[arg(
        help_heading = Some("General Options"),
        short = 'r',
        long,
        default_value = "./rules",
        hide_default_value = true,
        value_name = "DIR/FILE",
        requires = "no_wizard",
        display_order = 441
    )]
    pub rules: PathBuf,
}

#[derive(Args, Clone, Debug)]
pub struct LevelTuningOption {
    #[clap(flatten)]
    pub common_options: CommonOptions,

    /// Tune alert levels (default: ./rules/config/level_tuning.txt)
    #[arg(
            help_heading = Some("General Options"),
            short = 'f',
            long = "file",
            default_value = "./rules/config/level_tuning.txt",
            hide_default_value = true,
            value_name = "FILE",
            display_order = 320
        )]
    pub level_tuning: PathBuf,
}

#[derive(Args, Clone, Debug, Default)]
pub struct EidMetricsOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Save the Metrics in CSV format (ex: metrics.csv)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    /// Remove duplicate event records (default: disabled)
    #[arg(help_heading = Some("Output"), short = 'X', long = "remove-duplicate-records", alias = "remove-duplicate-detections", display_order = 409)]
    pub remove_duplicate_detections: bool,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,
}

#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("input_filtering").args(["directory", "filepath", "live_analysis"]).required(true)))]
#[clap(group(ArgGroup::new("level_rule_filtering").args(["min_level", "exact_level"]).multiple(false)))]
pub struct PivotKeywordOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Save pivot words to separate files (ex: PivotKeywords)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILENAME-PREFIX", display_order = 410)]
    pub output: Option<PathBuf>,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    /// Enable rules with a status of deprecated
    #[arg(help_heading = Some("Filtering"), short = 'D', long = "enable-deprecated-rules", requires = "no_wizard", display_order = 310)]
    pub enable_deprecated_rules: bool,

    /// Enable rules with a status of unsupported
    #[arg(help_heading = Some("Filtering"), short = 'u', long = "enable-unsupported-rules", requires = "no_wizard", display_order = 312)]
    pub enable_unsupported_rules: bool,

    /// Do not load rules according to status (ex: experimental) (ex: stable,test)
    #[arg(help_heading = Some("Filtering"), long = "exclude-status", value_name = "STATUS...", requires = "no_wizard", conflicts_with = "include_status",use_value_delimiter = true, value_delimiter = ',', display_order = 316)]
    pub exclude_status: Option<Vec<String>>,

    /// Only load rules with specific status (ex: experimental) (ex: stable,test)
    #[arg(help_heading = Some("Filtering"), long = "include-status", value_name = "STATUS...", requires = "no_wizard", conflicts_with = "exclude_status", use_value_delimiter = true, value_delimiter = ',', display_order = 353)]
    pub include_status: Option<Vec<String>>,

    /// Only load rules with specific tags (ex: attack.execution,attack.discovery)
    #[arg(help_heading = Some("Filtering"), long = "include-tag", value_name = "TAG...", requires = "no_wizard", conflicts_with = "exclude_tag", use_value_delimiter = true, value_delimiter = ',', display_order = 354)]
    pub include_tag: Option<Vec<String>>,

    /// Do not load rules with specific tags (ex: sysmon)
    #[arg(help_heading = Some("Filtering"), long = "exclude-tag", value_name = "TAG...", requires = "no_wizard", conflicts_with = "include_tag", use_value_delimiter = true, value_delimiter = ',', display_order = 316)]
    pub exclude_tag: Option<Vec<String>>,

    /// Minimum level for rules to load (default: informational)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'm',
        long = "min-level",
        default_value = "informational",
        hide_default_value = true,
        value_name = "LEVEL",
        requires = "no_wizard",
        conflicts_with = "exact_level",
        display_order = 390
    )]
    pub min_level: String,

    /// Only load rules with a specific level (informational, low, medium, high, critical)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'e',
        long = "exact-level",
        value_name = "LEVEL",
        requires = "no_wizard",
        conflicts_with = "min_level",
        display_order = 313
    )]
    pub exact_level: Option<String>,

    /// Enable rules set to noisy (./rules/config/noisy_rules.txt)
    #[arg(help_heading = Some("Filtering"), short = 'n', long = "enable-noisy-rules", requires = "no_wizard", display_order = 311)]
    pub enable_noisy_rules: bool,

    #[clap(flatten)]
    pub time_range: TimeRangeOption,

    /// Scan only common EIDs for faster speed (./rules/config/target_event_IDs.txt)
    #[arg(help_heading = Some("Filtering"), short = 'E', long = "eid-filter", display_order = 50)]
    pub eid_filter: bool,

    /// Scan only specified EIDs for faster speed (ex: 1) (ex: 1,4688)
    #[arg(help_heading = Some("Filtering"), long = "include-eid", value_name = "EID...", conflicts_with_all = ["eid_filter", "exclude_eid"], use_value_delimiter = true, value_delimiter = ',', display_order = 352)]
    pub include_eid: Option<Vec<String>>,

    /// Do not scan specific EIDs for faster speed (ex: 1) (ex: 1,4688)
    #[arg(help_heading = Some("Filtering"), long = "exclude-eid", value_name = "EID...", conflicts_with_all = ["eid_filter", "include_eid"], use_value_delimiter = true, value_delimiter = ',', display_order = 315)]
    pub exclude_eid: Option<Vec<String>>,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    /// Do not ask questions. Scan for all events and alerts.
    #[arg(help_heading = Some("General Options"), short = 'w', long = "no-wizard", display_order = 400)]
    pub no_wizard: bool,
}

#[derive(Args, Clone, Debug, Default)]
pub struct LogonSummaryOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Add GeoIP (ASN, city, country) info to source IP addresses
    #[arg(
        help_heading = Some("Output"),
        short = 'G',
        long = "geo-ip",
        value_name = "MAXMIND-DB-DIR",
        display_order = 70
    )]
    pub geo_ip: Option<PathBuf>,

    /// Save the logon summary to two CSV files (ex: -o logon-summary)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILENAME-PREFIX", display_order = 410)]
    pub output: Option<PathBuf>,

    /// Remove duplicate event records (default: disabled)
    #[arg(help_heading = Some("Output"), short = 'X', long = "remove-duplicate-records", alias = "remove-duplicate-detections", display_order = 409)]
    pub remove_duplicate_detections: bool,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    #[clap(flatten)]
    pub time_range: TimeRangeOption,
}

/// Options that can be set when outputting results (flattened into csv-timeline/json-timeline)
#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("level_rule_filtering").args(["min_level", "exact_level"]).multiple(false)))]
pub struct OutputOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Duplicate field data will be replaced with "DUP" (sort required)
    #[arg(
            help_heading = Some("Output"),
            short = 'R',
            long = "remove-duplicate-data",
            requires = "sort_events",
            display_order = 440
        )]
    pub remove_duplicate_data: bool,

    /// Specify output profile
    #[arg(help_heading = Some("Output"), short = 'p', long = "profile", display_order = 420)]
    pub profile: Option<String>,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    /// Enable rules with a status of deprecated
    #[arg(help_heading = Some("Filtering"), short = 'D', long = "enable-deprecated-rules", requires = "no_wizard", display_order = 310)]
    pub enable_deprecated_rules: bool,

    /// Enable rules with a status of unsupported
    #[arg(help_heading = Some("Filtering"), short = 'u', long = "enable-unsupported-rules", requires = "no_wizard", display_order = 312)]
    pub enable_unsupported_rules: bool,

    /// Do not load rules according to status (ex: experimental) (ex: stable,test)
    #[arg(help_heading = Some("Filtering"), long = "exclude-status", value_name = "STATUS...", requires = "no_wizard", conflicts_with = "include_status", use_value_delimiter = true, value_delimiter = ',', display_order = 316)]
    pub exclude_status: Option<Vec<String>>,

    /// Only load rules with specific status (ex: experimental) (ex: stable,test)
    #[arg(help_heading = Some("Filtering"), long = "include-status", value_name = "STATUS...", requires = "no_wizard", conflicts_with = "exclude_status", use_value_delimiter = true, value_delimiter = ',', display_order = 353)]
    pub include_status: Option<Vec<String>>,

    /// Only load rules with specific tags (ex: attack.execution,attack.discovery)
    #[arg(help_heading = Some("Filtering"), long = "include-tag", value_name = "TAG...", requires = "no_wizard", conflicts_with = "exclude_tag", use_value_delimiter = true, value_delimiter = ',', display_order = 354)]
    pub include_tag: Option<Vec<String>>,

    /// Only load rules with specified logsource categories (ex: process_creation,pipe_created)
    #[arg(help_heading = Some("Filtering"), long = "include-category", value_name = "CATEGORY...", conflicts_with = "exclude-category", requires = "no_wizard", use_value_delimiter = true, value_delimiter = ',', display_order = 351)]
    pub include_category: Option<Vec<String>>,

    /// Do not load rules with specified logsource categories (ex: process_creation,pipe_created)
    #[arg(help_heading = Some("Filtering"), long = "exclude-category", value_name = "CATEGORY...", conflicts_with = "include_category", requires = "no_wizard", use_value_delimiter = true, value_delimiter = ',', display_order = 314)]
    pub exclude_category: Option<Vec<String>>,

    /// Minimum level for rules to load (default: informational)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'm',
        long = "min-level",
        default_value = "informational",
        requires = "no_wizard",
        hide_default_value = true,
        value_name = "LEVEL",
        display_order = 390,
    )]
    pub min_level: String,

    /// Only load rules with a specific level (informational, low, medium, high, critical)
    #[arg(
        help_heading = Some("Filtering"),
        short = 'e',
        long = "exact-level",
        value_name = "LEVEL",
        requires = "no_wizard",
        conflicts_with = "min-level",
        display_order = 313
    )]
    pub exact_level: Option<String>,

    /// Enable rules set to noisy (./rules/config/noisy_rules.txt)
    #[arg(help_heading = Some("Filtering"), short = 'n', long = "enable-noisy-rules", requires = "no_wizard", display_order = 311)]
    pub enable_noisy_rules: bool,

    #[clap(flatten)]
    pub time_range: TimeRangeOption,

    /// Scan only common EIDs for faster speed (./rules/config/target_event_IDs.txt)
    #[arg(help_heading = Some("Filtering"), short = 'E', long = "eid-filter", conflicts_with_all=["include_eid","exclude_eid"], display_order = 50)]
    pub eid_filter: bool,

    /// Scan with only proven rules for faster speed (./rules/config/proven_rules.txt)
    #[arg(help_heading = Some("Filtering"), short = 'P', long = "proven-rules", display_order = 420)]
    pub proven_rules: bool,

    /// Do not load rules with specific tags (ex: sysmon)
    #[arg(help_heading = Some("Filtering"), long = "exclude-tag", value_name = "TAG...", requires = "no_wizard", conflicts_with = "include_tag", use_value_delimiter = true, value_delimiter = ',', display_order = 316)]
    pub exclude_tag: Option<Vec<String>>,

    /// Scan only specified EIDs for faster speed (ex: 1) (ex: 1,4688)
    #[arg(help_heading = Some("Filtering"), long = "include-eid", value_name = "EID...", conflicts_with_all = ["eid_filter", "exclude_eid"], use_value_delimiter = true, value_delimiter = ',', display_order = 352)]
    pub include_eid: Option<Vec<String>>,

    /// Do not scan specific EIDs for faster speed (ex: 1) (ex: 1,4688)
    #[arg(help_heading = Some("Filtering"), long = "exclude-eid", value_name = "EID...", conflicts_with_all = ["eid_filter", "include_eid"], use_value_delimiter = true, value_delimiter = ',', display_order = 315)]
    pub exclude_eid: Option<Vec<String>>,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    /// Output event frequency timeline (terminal needs to support unicode, sort required)
    #[arg(help_heading = Some("Display Settings"), short = 'T', long = "visualize-timeline", display_order = 490, requires = "sort_events")]
    pub visualize_timeline: bool,

    /// Specify a custom rule directory or file (default: ./rules)
    #[arg(
        help_heading = Some("General Options"),
        short = 'r',
        long,
        default_value = "./rules",
        hide_default_value = true,
        value_name = "DIR/FILE",
        requires = "no_wizard",
        display_order = 441
    )]
    pub rules: PathBuf,

    /// Save Results Summary details to an HTML report (ex: results.html)
    #[arg(help_heading = Some("Output"), short = 'H', long="html-report", conflicts_with = "no_summary", value_name = "FILE", display_order = 80, requires = "output")]
    pub html_report: Option<PathBuf>,

    /// Do not display Results Summary for faster speed
    #[arg(help_heading = Some("Display Settings"), short = 'N', long = "no-summary", conflicts_with = "html_report", display_order = 401)]
    pub no_summary: bool,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    /// Disable field data mapping
    #[arg(help_heading = Some("Output"), short = 'F', long = "no-field-data-mapping", display_order = 400)]
    pub no_field: bool,

    /// Disable field extraction of PowerShell classic logs
    #[arg(help_heading = Some("Output"), long = "no-pwsh-field-extraction", display_order = 410)]
    pub no_pwsh_field_extraction: bool,

    /// Remove duplicate detections (sort required)
    #[arg(help_heading = Some("Output"), short = 'X', long = "remove-duplicate-detections", requires = "sort_events", display_order = 441)]
    pub remove_duplicate_detections: bool,

    /// Do not ask questions. Scan for all events and alerts.
    #[arg(help_heading = Some("General Options"), short = 'w', long = "no-wizard", display_order = 400)]
    pub no_wizard: bool,

    /// Sort results before saving the file (warning: this uses much more memory!)
    #[arg(help_heading = Some("General Options"), short='s', long = "sort", display_order = 451)]
    pub sort_events: bool,

    /// Enable all rules regardless of loaded evtx files (disable channel filter for rules)
    #[arg(help_heading = Some("Filtering"), short='A', long = "enable-all-rules", display_order = 300)]
    pub enable_all_rules: bool,

    /// Scan all evtx files regardless of loaded rules (disable channel filter for evtx files)
    #[arg(help_heading = Some("Filtering"), short='a', long = "scan-all-evtx-files", display_order = 450)]
    pub scan_all_evtx_files: bool,
}

impl OutputOption {
    /// Whether existing output files may be overwritten (the `-C`/`--clobber` flag, now carried by
    /// the flattened `ClobberOption`).
    pub fn is_clobber_enabled(&self) -> bool {
        self.clobber_opt.clobber
    }
}

#[derive(Copy, Args, Clone, Debug, Default)]
pub struct CommonOptions {
    /// Disable color output
    #[arg(help_heading = Some("Display Settings"), short = 'K', long = "no-color", global = true, display_order = 400)]
    pub no_color: bool,

    /// Quiet mode: do not display the launch banner
    #[arg(help_heading = Some("Display Settings"), short, long, global = true, display_order = 430)]
    pub quiet: bool,

    /// Show the help menu
    #[clap(help_heading = Some("General Options"), short = 'h', long = "help", action = ArgAction::Help, display_order = 340, required = false)]
    pub help: Option<bool>,
}

#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("input_filtering").args(["directory", "filepath", "live_analysis"]).required(true)))]
pub struct InputOption {
    /// Directory of multiple .evtx files
    #[arg(help_heading = Some("Input"), short = 'd', long, value_name = "DIR", conflicts_with_all = ["filepath", "live_analysis"], display_order = 300)]
    pub directory: Option<Vec<PathBuf>>,

    /// File path to one .evtx file
    #[arg(help_heading = Some("Input"), short = 'f', long = "file", value_name = "FILE", conflicts_with_all = ["directory", "live_analysis"], display_order = 320)]
    pub filepath: Option<PathBuf>,

    /// Analyze the local C:\Windows\System32\winevt\Logs folder
    #[arg(help_heading = Some("Input"), short = 'l', long = "live-analysis", conflicts_with_all = ["filepath", "directory", "json_input"], display_order = 380)]
    pub live_analysis: bool,

    /// Carve evtx records from slack space (default: disabled)
    #[arg(help_heading = Some("General Options"), short = 'x', long = "recover-records", conflicts_with = "json_input", display_order = 440)]
    pub recover_records: bool,

    /// Scan recent events based on an offset (ex: 1y, 3M, 30d, 24h, 30m)
    #[arg(help_heading = Some("Filtering"), long = "time-offset", value_name = "OFFSET", conflicts_with = "start_timeline", display_order = 460)]
    pub time_offset: Option<String>,
}

/// Output format for `dfir-timeline`, selectable with `-t, --output-type` (case-insensitive,
/// default CSV).
#[derive(ValueEnum, Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum OutputType {
    #[default]
    Csv,
    Json,
    Jsonl,
}

#[derive(Args, Clone, Debug, Default)]
pub struct DfirTimelineOption {
    #[clap(flatten)]
    pub output_options: OutputOption,

    /// Output format: csv (default), json, or jsonl
    #[arg(
        help_heading = Some("Output"),
        short = 't',
        long = "output-type",
        value_enum,
        value_name = "OUTPUT_FORMAT",
        ignore_case = true,
        default_value = "csv",
        hide_default_value = true,
        hide_possible_values = true,
        display_order = 411
    )]
    pub output_type: OutputType,

    /// Separate event field information by newline characters (CSV output only)
    #[arg(help_heading = Some("CSV Output"), short = 'M', long="multiline", conflicts_with = "tab_separator", display_order = 390)]
    pub multiline: bool,

    /// Separate event field information by tabs (CSV output only)
    #[arg(help_heading = Some("CSV Output"), short = 'S', long="tab-separator", conflicts_with = "multiline", requires = "output", display_order = 490)]
    pub tab_separator: bool,

    // The display_order value is derived from the first letter of the long option name
    // (A=10, B=20, ..., Z=260, a=270, b=280, ..., z=520).
    /// Add GeoIP (ASN, city, country) info to IP addresses
    #[arg(
        help_heading = Some("Output"),
        short = 'G',
        long = "geo-ip",
        value_name = "MAXMIND-DB-DIR",
        display_order = 70
    )]
    pub geo_ip: Option<PathBuf>,

    /// Save the timeline to a file (ex: results.csv)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    #[clap(flatten)]
    pub disable_abbreviations_opt: DisableAbbreviationsOption,
}

#[derive(Args, Clone, Debug, Default)]
pub struct ComputerMetricsOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Save the results in CSV format (ex: computer-metrics.csv)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    /// Scan JSON formatted logs instead of .evtx (.json or .jsonl)
    #[arg(help_heading = Some("General Options"), short = 'J', long = "json-input", conflicts_with = "live_analysis", display_order = 390)]
    pub json_input: bool,

    /// Specify additional evtx file extensions (ex: evtx_data)
    #[arg(help_heading = Some("General Options"), long = "target-file-ext", value_name = "FILE-EXT...", use_value_delimiter = true, value_delimiter = ',', display_order = 450)]
    pub evtx_file_ext: Option<Vec<String>>,

    /// Quiet errors mode: do not save error logs
    #[arg(help_heading = Some("General Options"), short = 'Q', long = "quiet-errors", display_order = 430)]
    pub quiet_errors: bool,

    /// Specify custom rule config directory (default: ./rules/config)
    #[arg(
        help_heading = Some("General Options"),
        short = 'c',
        long = "rules-config",
        default_value = "./rules/config",
        hide_default_value = true,
        value_name = "DIR",
        display_order = 442
    )]
    pub config: PathBuf,

    /// Output verbose information
    #[arg(help_heading = Some("Display Settings"), short = 'v', long, display_order = 480)]
    pub verbose: bool,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    /// Enable checksum validation
    #[arg(help_heading = Some("General Options"), short = 'V', long = "validate-checksums", display_order = 480)]
    pub validate_checksums: bool,
}

#[derive(Args, Clone, Debug, Default)]
pub struct LogMetricsOption {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Save the Metrics in CSV format (ex: metrics.csv)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    /// Separate event field information by newline characters for CSV output
    #[arg(help_heading = Some("Output"), short = 'M', long="multiline", conflicts_with = "tab_separator", requires = "output", display_order = 390)]
    pub multiline: bool,

    /// Separate event field information by tabs
    #[arg(help_heading = Some("Output"), short = 'S', long="tab-separator", conflicts_with = "multiline", display_order = 490)]
    pub tab_separator: bool,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,

    #[clap(flatten)]
    pub disable_abbreviations_opt: DisableAbbreviationsOption,

    /// Only include specified channels (ex: System,Security)
    #[arg(help_heading = Some("Filtering"),long = "include-channel", value_name = "CHANNEL...", conflicts_with = "exclude_channel", use_value_delimiter = true, value_delimiter = ',',display_order = 355)]
    pub include_channel: Option<Vec<String>>,

    /// Do not scan specified channels (ex: System,Security)
    #[arg(help_heading = Some("Filtering"),long = "exclude-channel", value_name = "CHANNEL...", conflicts_with = "include_channel", use_value_delimiter = true, value_delimiter = ',',display_order = 315)]
    pub exclude_channel: Option<Vec<String>>,

    /// Only include specified evtx files (ex: Security.evtx,System.evtx)
    #[arg(help_heading = Some("Filtering"), long = "include-filename", value_name = "FILE...", conflicts_with = "exclude_filename", use_value_delimiter = true, value_delimiter = ',', display_order = 356)]
    pub include_filename: Option<Vec<String>>,

    /// Do not scan specified evtx files (ex: Security.evtx,System.evtx)
    #[arg(help_heading = Some("Filtering"), long = "exclude-filename", value_name = "FILE...", conflicts_with = "include_filename", use_value_delimiter = true, value_delimiter = ',', display_order = 316)]
    pub exclude_filename: Option<Vec<String>>,
}

#[derive(Args, Clone, Debug, Default)]
pub struct ExtractBase64Option {
    #[clap(flatten)]
    pub input_args: InputOption,

    /// Save results to a CSV file
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    #[clap(flatten)]
    pub common_options: CommonOptions,

    #[clap(flatten)]
    pub detect_common_options: DetectCommonOption,

    #[clap(flatten)]
    pub time_format_options: TimeFormatOptions,

    #[clap(flatten)]
    pub clobber_opt: ClobberOption,
}

#[derive(Args, Clone, Debug, Default)]
pub struct ExpandListOption {
    /// Specify rule directory (default: ./rules)
    #[arg(
        help_heading = Some("General Options"),
        short = 'r',
        long,
        default_value = "./rules",
        hide_default_value = true,
        value_name = "DIR/FILE",
        requires = "no_wizard",
        display_order = 441
    )]
    pub rules: PathBuf,

    #[clap(flatten)]
    pub common_options: CommonOptions,
}

#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("input_filtering").args(["directory", "filepath"]).required(true)))]
pub struct ConfigCriticalSystemsOption {
    /// Directory of multiple .evtx files
    #[arg(help_heading = Some("Input"), short = 'd', long, value_name = "DIR", conflicts_with_all = ["filepath"], display_order = 300)]
    pub directory: Option<Vec<PathBuf>>,

    /// File path to one .evtx file
    #[arg(help_heading = Some("Input"), short = 'f', long = "file", value_name = "FILE", conflicts_with_all = ["directory"], display_order = 320)]
    pub filepath: Option<PathBuf>,

    #[clap(flatten)]
    pub common_options: CommonOptions,
}

#[derive(Args, Clone, Debug, Default)]
#[clap(group(ArgGroup::new("sort_csv_input").args(["directory", "filepath"]).required(true)))]
pub struct SortCsvOption {
    /// CSV file to sort
    #[arg(help_heading = Some("Input"), short = 'f', long = "file", value_name = "FILE", conflicts_with_all = ["directory"], display_order = 320)]
    pub filepath: Option<PathBuf>,

    /// Directory of CSV files to sort together
    #[arg(help_heading = Some("Input"), short = 'd', long, value_name = "DIR", conflicts_with_all = ["filepath"], display_order = 300)]
    pub directory: Option<PathBuf>,

    /// Save the sorted CSV to the given file (default: print to screen)
    #[arg(help_heading = Some("Output"), short = 'o', long, value_name = "FILE", display_order = 410)]
    pub output: Option<PathBuf>,

    /// Overwrite the output file if it already exists
    #[arg(help_heading = Some("Output"), short = 'C', long = "clobber", display_order = 411)]
    pub clobber: bool,

    #[clap(flatten)]
    pub common_options: CommonOptions,
}

#[derive(Parser, Clone, Debug, Default)]
#[clap(
    author = "Yamato Security (https://github.com/Yamato-Security/hayabusa - @SecurityYamato)",
    help_template = help_banner("\n{author-with-newline}\n{usage-heading}\n  hayabusa.exe <COMMAND> [OPTIONS]\n  hayabusa.exe help <COMMAND> or hayabusa.exe <COMMAND> -h\n\n{all-args}{options}"),
    term_width = 400,
    disable_help_flag = true
)]
pub struct Config {
    #[command(subcommand)]
    pub action: Option<Action>,

    /// Print debug information (memory usage, etc...)
    #[clap(long = "debug", global = true, hide = true)]
    pub debug: bool,
}

impl ConfigReader {
    pub fn new() -> Self {
        // `Config::parse()` reads std::env::args() and clap hard-exits the process
        // on any argument it doesn't recognize. Under `cargo test` the process args
        // belong to the test harness (e.g. `--test-threads=1` or a test-name
        // filter), which would abort the whole test binary. `cfg!(test)` is no help
        // here because the binary's tests link this library compiled *without* the
        // test cfg, so detect the test binary at runtime instead: it lives under
        // `target/.../deps/`. See https://github.com/Yamato-Security/hayabusa/issues/1170
        let parse = Config::try_parse().unwrap_or_else(|e| {
            let under_test = std::env::current_exe()
                .map(|path| {
                    path.components()
                        .any(|component| component.as_os_str() == "deps")
                })
                .unwrap_or(false);
            // Only swallow the error kinds the harness itself produces: its flags
            // (`--test-threads`, `--nocapture`, ...) parse as `UnknownArgument`, and
            // a test-name filter parses as `InvalidSubcommand`. Genuine validation
            // errors (bad values, conflicts, ...) still exit normally even here, so a
            // real run is never silently swallowed.
            let harness_arg = matches!(
                e.kind(),
                clap::error::ErrorKind::UnknownArgument | clap::error::ErrorKind::InvalidSubcommand
            );
            if under_test && harness_arg {
                Config::parse_from(["hayabusa"])
            } else {
                e.exit()
            }
        });
        let help_term_width = if let Some((Width(width), _)) = terminal_size() {
            width as usize
        } else {
            400
        };
        let build_cmd = Config::command()
            .disable_version_flag(true)
            .color(ColorChoice::Auto)
            .term_width(help_term_width);
        ConfigReader {
            app: build_cmd,
            config: Some(parse),
        }
    }
}

/// A set of event IDs (target_event_IDs.txt) or rule IDs (proven_rules.txt) used as a filter.
#[derive(Debug, Clone)]
pub struct TargetIds {
    ids: HashSet<String>,
}

impl Default for TargetIds {
    fn default() -> Self {
        Self::new()
    }
}

impl TargetIds {
    pub fn new() -> TargetIds {
        TargetIds {
            ids: HashSet::new(),
        }
    }

    pub fn is_target(&self, id: &str, flag_in_case_empty: bool) -> bool {
        // An empty set means the filter is disabled, so return the caller-supplied default:
        // for event IDs every event ID is targeted, and for rule IDs no rule is filtered out.
        if self.ids.is_empty() {
            return flag_in_case_empty;
        }
        self.ids.contains(id)
    }
}

fn load_target_ids(path: &str) -> TargetIds {
    let mut ret = TargetIds::default();
    let lines = match utils::read_txt(path) {
        Ok(lines) => lines,
        Err(e) => {
            // A missing file is treated as an error: report it and return an empty
            // (disabled) filter.
            AlertMessage::alert(&e).ok();
            return ret;
        }
    };

    for line in lines.iter() {
        if line.is_empty() {
            continue;
        }
        ret.ids.insert(line.to_string());
    }

    ret
}

/// Event timestamp filter built from --timeline-start / --timeline-end / --time-offset.
/// Events outside the [start_time, end_time] range are excluded from the scan.
#[derive(Debug, Clone)]
pub struct TargetEventTime {
    parse_success_flag: bool,
    start_time: Option<DateTime<Utc>>,
    end_time: Option<DateTime<Utc>>,
}

impl TargetEventTime {
    pub fn new(stored_static: &StoredStatic) -> Self {
        // Parses an absolute timestamp into UTC; on failure, prints error_contents and clears
        // parse_success_flag.
        let get_time =
            |input_time: Option<&String>, error_contents: &str, parse_success_flag: &mut bool| {
                if let Some(time) = input_time {
                    match DateTime::parse_from_str(time, "%Y-%m-%d %H:%M:%S %z") // 2014-11-28 21:00:09 +09:00
                    .or_else(|_| DateTime::parse_from_str(time, "%Y/%m/%d %H:%M:%S %z")) // 2014/11/28 21:00:09 +09:00
                {
                    Ok(dt) => Some(dt.with_timezone(&Utc)),
                    Err(_) => {
                        AlertMessage::alert(error_contents)
                        .ok();
                        *parse_success_flag = false;
                        None
                    }
                }
                } else {
                    None
                }
            };

        // Converts a relative offset such as "1y3M30d24h30m10s" into an absolute start time
        // (now minus the offset), returned as a "%Y-%m-%d %H:%M:%S %z" string for get_time.
        let get_time_offset = |time_offset: &Option<String>, parse_success_flag: &mut bool| {
            if let Some(timeline_offset) = time_offset {
                // Supported unit suffixes; note that 'M' is months while 'm' is minutes.
                let time_units = ['y', 'M', 'd', 'h', 'm', 's'];
                let mut time_num = [0, 0, 0, 0, 0, 0];
                for (idx, key) in time_units.iter().enumerate() {
                    // Extract the digits belonging to this unit: take the text before the unit
                    // character and strip everything up to the last other unit character
                    // (e.g. for 'M' in "1y3M": "1y3" -> "3"). Both splits always yield at least one
                    // element, so `.next()`/`.next_back()` are guaranteed to be `Some`.
                    let before_unit = timeline_offset.split(*key).next().unwrap_or_default();
                    let target_num = before_unit
                        .split(time_units)
                        .next_back()
                        .unwrap_or_default();
                    if target_num.is_empty() {
                        continue;
                    }
                    if let Ok(num) = target_num.parse::<u32>() {
                        time_num[idx] = num;
                    } else {
                        AlertMessage::alert(
                            "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        )
                        .ok();
                        *parse_success_flag = false;
                        return None;
                    }
                }
                if time_num.iter().all(|&x| x == 0) {
                    AlertMessage::alert(
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                    )
                    .ok();
                    *parse_success_flag = false;
                    return None;
                }
                // Subtract each component from the current time; years are folded into months.
                let target_start_time = Local::now()
                    .checked_sub_months(Months::new(time_num[0] * 12))
                    .and_then(|dt| dt.checked_sub_months(Months::new(time_num[1])))
                    .and_then(|dt| dt.checked_sub_days(Days::new(time_num[2].into())))
                    .and_then(|dt| {
                        dt.checked_sub_signed(
                            Duration::try_hours(time_num[3].into()).unwrap_or_default(),
                        )
                    })
                    .and_then(|dt| {
                        dt.checked_sub_signed(
                            Duration::try_minutes(time_num[4].into()).unwrap_or_default(),
                        )
                    })
                    .and_then(|dt| {
                        dt.checked_sub_signed(
                            Duration::try_seconds(time_num[5].into()).unwrap_or_default(),
                        )
                    });
                if let Some(start_time) = target_start_time {
                    Some(start_time.format("%Y-%m-%d %H:%M:%S %z").to_string())
                } else {
                    AlertMessage::alert("timeline-offset field: the timestamp value is too large.")
                        .ok();
                    *parse_success_flag = false;
                    None
                }
            } else {
                None
            }
        };

        let mut parse_success_flag = true;
        let time_offset = get_time_offset(&stored_static.time_offset, &mut parse_success_flag);
        match &stored_static.config.action.as_ref().unwrap() {
            Action::DfirTimeline(option) => {
                let start_time = if time_offset.is_some() {
                    get_time(
                        time_offset.as_ref(),
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        &mut parse_success_flag,
                    )
                } else {
                    get_time(
                        option.output_options.time_range.start_timeline.as_ref(),
                        "start-timeline field: the timestamp format is not correct.",
                        &mut parse_success_flag,
                    )
                };
                let end_time = get_time(
                    option.output_options.time_range.end_timeline.as_ref(),
                    "end-timeline field: the timestamp format is not correct.",
                    &mut parse_success_flag,
                );
                Self::set(parse_success_flag, start_time, end_time)
            }
            Action::PivotKeywordsList(option) => {
                let start_time = if time_offset.is_some() {
                    get_time(
                        time_offset.as_ref(),
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        &mut parse_success_flag,
                    )
                } else {
                    get_time(
                        option.time_range.start_timeline.as_ref(),
                        "start-timeline field: the timestamp format is not correct.",
                        &mut parse_success_flag,
                    )
                };
                let end_time = get_time(
                    option.time_range.end_timeline.as_ref(),
                    "end-timeline field: the timestamp format is not correct.",
                    &mut parse_success_flag,
                );
                Self::set(parse_success_flag, start_time, end_time)
            }
            Action::LogonSummary(option) => {
                let start_time = if time_offset.is_some() {
                    get_time(
                        time_offset.as_ref(),
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        &mut parse_success_flag,
                    )
                } else {
                    get_time(
                        option.time_range.start_timeline.as_ref(),
                        "start-timeline field: the timestamp format is not correct.",
                        &mut parse_success_flag,
                    )
                };
                let end_time = get_time(
                    option.time_range.end_timeline.as_ref(),
                    "end-timeline field: the timestamp format is not correct.",
                    &mut parse_success_flag,
                );
                Self::set(parse_success_flag, start_time, end_time)
            }
            Action::Search(option) => {
                let start_time = if time_offset.is_some() {
                    get_time(
                        time_offset.as_ref(),
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        &mut parse_success_flag,
                    )
                } else {
                    get_time(
                        option.time_range.start_timeline.as_ref(),
                        "start-timeline field: the timestamp format is not correct.",
                        &mut parse_success_flag,
                    )
                };
                let end_time = get_time(
                    option.time_range.end_timeline.as_ref(),
                    "end-timeline field: the timestamp format is not correct.",
                    &mut parse_success_flag,
                );
                Self::set(parse_success_flag, start_time, end_time)
            }
            Action::LogMetrics(_)
            | Action::EidMetrics(_)
            | Action::ComputerMetrics(_)
            | Action::ExtractBase64(_) => {
                let start_time = if time_offset.is_some() {
                    get_time(
                        time_offset.as_ref(),
                        "Invalid timeline offset. Please use one of the following formats: 1y, 3M, 30d, 24h, 30m",
                        &mut parse_success_flag,
                    )
                } else {
                    None
                };
                Self::set(parse_success_flag, start_time, None)
            }
            _ => Self::set(parse_success_flag, None, None),
        }
    }

    pub fn set(
        input_parse_success_flag: bool,
        input_start_time: Option<DateTime<Utc>>,
        input_end_time: Option<DateTime<Utc>>,
    ) -> Self {
        Self {
            parse_success_flag: input_parse_success_flag,
            start_time: input_start_time,
            end_time: input_end_time,
        }
    }

    pub fn is_parse_success(&self) -> bool {
        self.parse_success_flag
    }

    pub fn is_target(&self, eventtime: &Option<DateTime<Utc>>) -> bool {
        // Records without a timestamp are never filtered out.
        if eventtime.is_none() {
            return true;
        }
        if let Some(starttime) = self.start_time
            && eventtime.unwrap() < starttime
        {
            return false;
        }
        if let Some(endtime) = self.end_time
            && eventtime.unwrap() > endtime
        {
            return false;
        }
        true
    }
}

/// Lookup table built from eventkey_alias.txt that maps the short field aliases used in rules
/// and config files (e.g. "Computer") to the full dot-separated JSON path of the event record
/// (e.g. "Event.System.Computer").
#[derive(Debug, Clone)]
pub struct EventKeyAliasConfig {
    // alias -> full event key (e.g. "Computer" -> "Event.System.Computer")
    key_to_eventkey: HashMap<String, String>,
    // alias -> length of each dot-separated segment of the event key, so that callers can slice
    // the key string without re-splitting it (see utils::get_event_value)
    key_to_split_eventkey: HashMap<String, Vec<usize>>,
}

impl EventKeyAliasConfig {
    pub fn new() -> EventKeyAliasConfig {
        EventKeyAliasConfig {
            key_to_eventkey: HashMap::new(),
            key_to_split_eventkey: HashMap::new(),
        }
    }

    pub fn get_event_key(&self, alias: &str) -> Option<&String> {
        self.key_to_eventkey.get(alias)
    }

    pub fn get_event_key_split(&self, alias: &str) -> Option<&Vec<usize>> {
        self.key_to_split_eventkey.get(alias)
    }
}

impl Default for EventKeyAliasConfig {
    fn default() -> Self {
        Self::new()
    }
}

pub fn load_eventkey_alias(path: &str) -> EventKeyAliasConfig {
    let mut config = EventKeyAliasConfig::new();

    // If eventkey_alias.txt cannot be read, report an error and return an empty config.
    let read_result = utils::read_csv(path);
    if let Err(e) = read_result {
        AlertMessage::alert(&e).ok();
        return config;
    }

    read_result.unwrap().iter().for_each(|line| {
        if line.len() != 2 {
            return;
        }

        let empty = &"".to_string();
        let alias = line.first().unwrap_or(empty);
        let event_key = line.get(1).unwrap_or(empty);
        if alias.is_empty() || event_key.is_empty() {
            return;
        }

        config
            .key_to_eventkey
            .insert(alias.to_owned(), event_key.to_owned());
        config.key_to_split_eventkey.insert(
            alias.to_owned(),
            event_key.split('.').map(|s| s.len()).collect(),
        );
    });
    config.key_to_eventkey.shrink_to_fit();
    config
}

/// Loads the pivot keyword config file and registers each "keyword.field" line into the given
/// pivot keyword map.
pub fn load_pivot_keywords(path: &str, pivot_keyword: &RwLock<PivotKeywordMap>) {
    let read_result = match utils::read_txt(path) {
        Ok(lines) => lines,
        Err(e) => {
            AlertMessage::alert(&e).ok();
            return;
        }
    };

    read_result.iter().for_each(|line| {
        let mut map = line.split('.').take(2);
        if let Some(size) = map.size_hint().1 {
            if size < 2 {
                return;
            }
        } else {
            return;
        }
        let key = map.next().unwrap();
        let value = map.next().unwrap();

        // Create an empty entry for this keyword if it is not registered yet, then add the field.
        let mut pivots = pivot_keyword.write().unwrap();
        pivots
            .entry(key.to_string())
            .or_default()
            .fields
            .insert(value.to_string());
    });
}

/// Returns the set of file extensions to scan: the extra extensions added with
/// --target-file-ext plus the default extension (evtx, or json/jsonl when --json-input is set).
pub fn get_target_extensions(arg: Option<&Vec<String>>, json_input_flag: bool) -> HashSet<String> {
    let mut target_file_extensions: HashSet<String> = convert_option_vecs_to_hs(arg);
    if json_input_flag {
        target_file_extensions.insert(String::from("json"));
        target_file_extensions.insert(String::from("jsonl"));
    } else {
        target_file_extensions.insert(String::from("evtx"));
    }
    target_file_extensions
}

/// Function to convert the contents of Option<Vec<String>> to a HashSet.
pub fn convert_option_vecs_to_hs(arg: Option<&Vec<String>>) -> HashSet<String> {
    let ret: HashSet<String> = arg.unwrap_or(&Vec::new()).iter().cloned().collect();
    ret
}

/// Returns a copy of the search options when the search subcommand was invoked, None otherwise.
fn extract_search_options(config: &Config) -> Option<SearchOption> {
    match &config.action.as_ref()? {
        Action::Search(option) => Some(SearchOption {
            input_args: option.input_args.clone(),
            keywords: option.keywords.clone(),
            regex: option.regex.clone(),
            ignore_case: option.ignore_case,
            filter: option.filter.clone(),
            output: option.output.clone(),
            common_options: option.common_options,
            evtx_file_ext: option.evtx_file_ext.clone(),
            thread_number: option.thread_number,
            quiet_errors: option.quiet_errors,
            config: option.config.clone(),
            verbose: option.verbose,
            multiline: option.multiline,
            clobber_opt: option.clobber_opt.clone(),
            json_output: option.json_output,
            jsonl_output: option.jsonl_output,
            time_format_options: option.time_format_options.clone(),
            and_logic: option.and_logic,
            disable_abbreviations_opt: option.disable_abbreviations_opt.clone(),
            time_range: option.time_range.clone(),
            sort_events: option.sort_events,
            tab_separator: option.tab_separator,
            validate_checksums: option.validate_checksums,
        }),
        _ => None,
    }
}

/// Function to extract a struct containing option values related to output from the config.
/// For actions other than csv-timeline/json-timeline, an equivalent OutputOption is synthesized
/// from the action's own options so that downstream code can handle every action uniformly.
fn extract_output_options(config: &Config) -> Option<OutputOption> {
    match &config.action.as_ref()? {
        Action::DfirTimeline(option) => Some(option.output_options.clone()),
        Action::PivotKeywordsList(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            enable_deprecated_rules: option.enable_deprecated_rules,
            enable_noisy_rules: option.enable_noisy_rules,
            exclude_status: option.exclude_status.clone(),
            min_level: option.min_level.clone(),
            exact_level: option.exact_level.clone(),
            time_range: option.time_range.clone(),
            eid_filter: option.eid_filter,
            time_format_options: TimeFormatOptions::default(),
            rules: Path::new("./rules").to_path_buf(),
            common_options: option.common_options,
            detect_common_options: option.detect_common_options.clone(),
            enable_unsupported_rules: option.enable_unsupported_rules,
            clobber_opt: option.clobber_opt.clone(),
            include_tag: option.include_tag.clone(),
            exclude_tag: option.exclude_tag.clone(),
            include_eid: option.include_eid.clone(),
            exclude_eid: option.exclude_eid.clone(),
            no_wizard: option.no_wizard,
            include_status: option.include_status.clone(),
            ..Default::default()
        }),
        Action::EidMetrics(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            time_format_options: option.time_format_options.clone(),
            common_options: option.common_options,
            detect_common_options: option.detect_common_options.clone(),
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::ExtractBase64(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            time_format_options: option.time_format_options.clone(),
            rules: Path::new("./rules").to_path_buf(),
            common_options: option.common_options,
            detect_common_options: option.detect_common_options.clone(),
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::LogonSummary(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            time_format_options: option.time_format_options.clone(),
            common_options: option.common_options,
            detect_common_options: option.detect_common_options.clone(),
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::ComputerMetrics(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            common_options: option.common_options,
            detect_common_options: DetectCommonOption {
                json_input: option.json_input,
                validate_checksums: option.validate_checksums,
                evtx_file_ext: option.evtx_file_ext.clone(),
                thread_number: None,
                quiet_errors: option.quiet_errors,
                config: option.config.clone(),
                verbose: option.verbose,
                include_computer: None,
                exclude_computer: None,
            },
            time_format_options: TimeFormatOptions::default(),
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::LogMetrics(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            common_options: option.common_options,
            detect_common_options: option.detect_common_options.clone(),
            time_format_options: option.time_format_options.clone(),
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::Search(option) => Some(OutputOption {
            input_args: option.input_args.clone(),
            time_format_options: option.time_format_options.clone(),
            common_options: option.common_options,
            detect_common_options: DetectCommonOption {
                json_input: false,
                validate_checksums: option.validate_checksums,
                evtx_file_ext: option.evtx_file_ext.clone(),
                thread_number: option.thread_number,
                quiet_errors: option.quiet_errors,
                config: option.config.clone(),
                verbose: option.verbose,
                include_computer: None,
                exclude_computer: None,
            },
            clobber_opt: option.clobber_opt.clone(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::SetDefaultProfile(option) => Some(OutputOption {
            input_args: InputOption::default(),
            time_format_options: TimeFormatOptions::default(),
            common_options: option.common_options,
            detect_common_options: DetectCommonOption::default(),
            no_wizard: true,
            ..Default::default()
        }),
        Action::UpdateRules(option) => Some(OutputOption {
            input_args: InputOption::default(),
            enable_deprecated_rules: true,
            enable_noisy_rules: true,
            time_format_options: TimeFormatOptions::default(),
            common_options: option.common_options,
            detect_common_options: DetectCommonOption::default(),
            enable_unsupported_rules: true,
            no_wizard: true,
            ..Default::default()
        }),
        Action::ConfigCriticalSystems(option) => Some(OutputOption {
            input_args: InputOption {
                directory: option.directory.clone(),
                filepath: option.filepath.clone(),
                live_analysis: false,
                recover_records: false,
                time_offset: None,
            },
            time_format_options: TimeFormatOptions::default(),
            common_options: option.common_options,
            detect_common_options: DetectCommonOption::default(),
            no_wizard: true,
            ..Default::default()
        }),
        _ => None,
    }
}

/// Human-readable title of an event (defaults to "Unknown").
#[derive(Debug, Clone)]
pub struct EventInfo {
    pub event_title: String,
}

impl Default for EventInfo {
    fn default() -> Self {
        Self::new()
    }
}

impl EventInfo {
    pub fn new() -> EventInfo {
        let event_title = "Unknown".to_string();
        EventInfo { event_title }
    }
}
/// Lookup of (channel (lowercased), event id) -> event title, loaded from channel_eid_info.txt.
#[derive(Debug, Clone)]
pub struct EventInfoConfig {
    eventinfo: HashMap<(String, String), EventInfo>,
}

impl Default for EventInfoConfig {
    fn default() -> Self {
        Self::new()
    }
}

impl EventInfoConfig {
    pub fn new() -> EventInfoConfig {
        EventInfoConfig {
            eventinfo: HashMap::new(),
        }
    }
    pub fn get_event_id(&self, channel: &str, eventid: &str) -> Option<&EventInfo> {
        self.eventinfo
            .get(&(channel.to_string(), eventid.to_string()))
    }
}

fn load_eventcode_info(path: &str) -> EventInfoConfig {
    let mut event_info = EventInfo::new();
    let mut config = EventInfoConfig::new();
    // If channel_eid_info.txt cannot be read, report an error and return an empty config.
    let read_result = match utils::read_csv(path) {
        Ok(lines) => lines,
        Err(e) => {
            AlertMessage::alert(&e).ok();
            return config;
        }
    };

    // Each line is expected to contain: channel, event ID, event title.
    read_result.iter().for_each(|line| {
        if line.len() != 3 {
            return;
        }

        let empty = &"".to_string();
        let channel = line.first().unwrap_or(empty);
        let eventcode = line.get(1).unwrap_or(empty);
        let event_title = line.get(2).unwrap_or(empty);
        event_info = EventInfo {
            event_title: event_title.to_string(),
        };
        config.eventinfo.insert(
            (channel.to_lowercase(), eventcode.to_owned()),
            event_info.to_owned(),
        );
    });
    config
}

/// Builds a map from each ASCII control character (except line feed) to its JSON-style
/// uppercase escape sequence (`\u0000` through `\u001F`).
fn create_control_char_replace_map() -> HashMap<char, CompactString> {
    let mut ret = HashMap::new();
    let replace_char = '\0'..='\x1F';
    for control_char in replace_char.into_iter().filter(|x| x != &'\x0A') {
        ret.insert(
            control_char,
            CompactString::from(format!(
                "\\u00{}",
                format!("{:02x}", control_char as u8).to_uppercase()
            )),
        );
    }
    ret
}

/// Loads the dash variant characters recognized by the Sigma "windash" modifier. The all-in-one
/// config bundle takes precedence; otherwise the given file is read, and if it cannot be opened
/// a built-in default set is used.
pub fn load_windash_characters(file_path: &str) -> Vec<char> {
    if let Some(contents) = ONE_CONFIG_MAP.get("windash_characters.txt") {
        return contents
            .lines()
            .map(|line| line.chars().next().unwrap())
            .collect();
    }
    let mut characters = Vec::from(['-', '–', '—', '―']);
    let file = File::open(file_path);
    match file {
        Ok(opened_file) => {
            characters = Vec::new();
            let reader = io::BufReader::new(opened_file);
            for line in reader.lines() {
                let line = line.unwrap();
                if let Some(ch) = line.chars().next() {
                    characters.push(ch);
                }
            }
            characters
        }
        Err(_) => characters,
    }
}

/// Loads windows_versions.csv into a map of (OS version, build number) -> (Windows product
/// name, release date), used to resolve Windows OS names in computer-metrics.
pub fn load_win_versions() -> HashMap<(String, String), (String, String)> {
    fn parse_csv<R: std::io::Read>(reader: R) -> HashMap<(String, String), (String, String)> {
        let mut map = HashMap::new();
        let mut rdr = csv::Reader::from_reader(reader);
        for rec in rdr.records().flatten() {
            let ver = rec.get(0).unwrap_or_default().to_string();
            let build = rec.get(1).unwrap_or_default().to_string();
            let win = rec.get(2).unwrap_or_default().to_string();
            let date = rec.get(3).unwrap_or_default().to_string();
            map.insert((ver, build), (win, date));
        }
        map
    }

    if let Ok(file) = File::open(Path::new("rules/config/windows_versions.csv")) {
        parse_csv(file)
    } else if let Some(contents) = ONE_CONFIG_MAP.get("windows_versions.csv") {
        parse_csv(contents.as_bytes())
    } else {
        HashMap::new()
    }
}

#[cfg(test)]
mod tests {
    use std::default::Default;

    use super::{
        Action, ClobberOption, CommonOptions, Config, DetectCommonOption, DfirTimelineOption,
        InputOption, OutputOption, StoredStatic, TargetEventTime, create_control_char_replace_map,
    };
    use crate::detections::configs::{
        self, EidMetricsOption, LogonSummaryOption, PivotKeywordOption, SearchOption,
    };
    use chrono::{DateTime, Utc};
    use compact_str::CompactString;
    use hashbrown::{HashMap, HashSet};

    #[test]
    fn target_event_time_filter() {
        let start_time = Some("2018-02-20T12:00:09Z".parse::<DateTime<Utc>>().unwrap());
        let end_time = Some("2020-03-30T12:00:09Z".parse::<DateTime<Utc>>().unwrap());
        let time_filter = TargetEventTime::set(true, start_time, end_time);

        let out_of_range1 = Some("1999-01-01T12:00:09Z".parse::<DateTime<Utc>>().unwrap());
        let within_range = Some("2019-02-27T01:05:01Z".parse::<DateTime<Utc>>().unwrap());
        let out_of_range2 = Some("2021-02-27T01:05:01Z".parse::<DateTime<Utc>>().unwrap());

        assert!(!time_filter.is_target(&out_of_range1));
        assert!(time_filter.is_target(&within_range));
        assert!(!time_filter.is_target(&out_of_range2));
    }

    #[test]
    fn target_event_time_filter_contains_on_time() {
        let start_time = Some("2018-02-20T12:00:09Z".parse::<DateTime<Utc>>().unwrap());
        let end_time = Some("2020-03-30T12:00:09Z".parse::<DateTime<Utc>>().unwrap());
        let time_filter = TargetEventTime::set(true, start_time, end_time);

        // Timestamps exactly on the start/end boundary must be treated as in range.
        assert!(time_filter.is_target(&start_time));
        assert!(time_filter.is_target(&end_time));
    }

    #[test]
    fn test_get_target_extensions() {
        let data = vec!["evtx_data".to_string(), "evtx_stars".to_string()];
        let arg = Some(&data);
        let ret = configs::get_target_extensions(arg, false);
        let expect: HashSet<&str> = HashSet::from(["evtx", "evtx_data", "evtx_stars"]);
        assert_eq!(ret.len(), expect.len());
        for contents in expect.iter() {
            assert!(ret.contains(&contents.to_string()));
        }
    }

    #[test]
    fn no_target_extensions() {
        let ret = configs::get_target_extensions(None, false);
        let expect: HashSet<&str> = HashSet::from(["evtx"]);
        assert_eq!(ret.len(), expect.len());
        for contents in expect.iter() {
            assert!(ret.contains(&contents.to_string()));
        }
    }

    #[test]
    fn test_create_control_char_replace_map() {
        let mut expect: HashMap<char, CompactString> =
            HashMap::from_iter(('\0'..='\x1F').map(|control_char| {
                (
                    control_char as u8 as char,
                    CompactString::from(format!(
                        "\\u00{}",
                        format!("{:02x}", control_char as u8).to_uppercase()
                    )),
                )
            }));
        expect.remove(&'\x0A');
        let actual = create_control_char_replace_map();
        assert_eq!(expect, actual);
    }

    #[test]
    fn test_time_offset_csv() {
        let csv_timeline = StoredStatic::create_static_data(Config {
            action: Some(Action::DfirTimeline(DfirTimelineOption {
                output_options: OutputOption {
                    input_args: InputOption {
                        time_offset: Some("1d".to_string()),
                        ..Default::default()
                    },
                    min_level: "informational".to_string(),
                    detect_common_options: DetectCommonOption {
                        json_input: true,
                        ..Default::default()
                    },
                    no_wizard: true,
                    ..Default::default()
                },
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&csv_timeline);
        let actual_diff = now - actual.start_time.unwrap();
        assert!(actual_diff.num_days() == 1);
    }

    #[test]
    fn test_time_offset_json() {
        let json_timeline = StoredStatic::create_static_data(Config {
            action: Some(Action::DfirTimeline(DfirTimelineOption {
                output_options: OutputOption {
                    input_args: InputOption {
                        time_offset: Some("1y".to_string()),
                        ..Default::default()
                    },
                    min_level: "informational".to_string(),
                    detect_common_options: DetectCommonOption {
                        json_input: true,
                        ..Default::default()
                    },
                    no_wizard: true,
                    ..Default::default()
                },
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&json_timeline);
        let actual_diff = now - actual.start_time.unwrap();
        assert!(actual_diff.num_days() == 365 || actual_diff.num_days() == 366);
    }

    #[test]
    fn test_time_offset_search() {
        let json_timeline = StoredStatic::create_static_data(Config {
            action: Some(Action::Search(SearchOption {
                common_options: CommonOptions::default(),
                input_args: InputOption {
                    time_offset: Some("1h".to_string()),
                    ..Default::default()
                },
                keywords: Some(vec!["mimikatz".to_string()]),
                ignore_case: true,
                clobber_opt: ClobberOption { clobber: true },
                sort_events: true,
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&json_timeline);
        let actual_diff = now - actual.start_time.unwrap();
        assert!(actual_diff.num_hours() == 1);
    }

    #[test]
    fn test_time_offset_eid_metrics() {
        let eid_metrics = StoredStatic::create_static_data(Config {
            action: Some(Action::EidMetrics(EidMetricsOption {
                common_options: CommonOptions::default(),
                input_args: InputOption {
                    time_offset: Some("1h1m".to_string()),
                    ..Default::default()
                },
                clobber_opt: ClobberOption { clobber: true },
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&eid_metrics);
        let actual_diff = now - actual.start_time.unwrap();
        assert!(actual_diff.num_hours() == 1 && actual_diff.num_minutes() == 61);
    }

    #[test]
    fn test_time_offset_logon_summary() {
        let logon_summary = StoredStatic::create_static_data(Config {
            action: Some(Action::LogonSummary(LogonSummaryOption {
                input_args: InputOption {
                    time_offset: Some("1y1d1h".to_string()),
                    ..Default::default()
                },
                clobber_opt: ClobberOption { clobber: true },
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&logon_summary);
        let actual_diff = now - actual.start_time.unwrap();
        let days = actual_diff.num_days();
        assert!(
            (days == 366 && actual_diff.num_hours() == days * 24 + 1)
                || (days == 367 && actual_diff.num_hours() == days * 24 + 1)
        );
    }

    #[test]
    fn test_time_offset_pivot() {
        let pivot_keywords_list = StoredStatic::create_static_data(Config {
            action: Some(Action::PivotKeywordsList(PivotKeywordOption {
                input_args: InputOption {
                    time_offset: Some("1y1M1s".to_string()),
                    ..Default::default()
                },
                clobber_opt: ClobberOption { clobber: true },
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                no_wizard: true,
                ..Default::default()
            })),
            debug: false,
        });
        let now = Utc::now();
        let actual = TargetEventTime::new(&pivot_keywords_list);
        let actual_diff = now - actual.start_time.unwrap();
        let actual_diff_day = actual_diff.num_days();
        assert!(
            (393..=397).contains(&actual_diff_day)
                && actual_diff.num_seconds() - (actual_diff_day * 24 * 60 * 60) == 1
        );
    }

    // Regression guard for the #[clap(flatten)] de-duplication: the shared args must stay exposed
    // on the same subcommands. Introspect the clap Command rather than parsing.
    #[test]
    fn test_flattened_clap_args_present() {
        use clap::CommandFactory;
        let cmd = Config::command();
        let sub = |name: &str| {
            cmd.get_subcommands()
                .find(|subcommand| subcommand.get_name() == name)
                .unwrap_or_else(|| panic!("subcommand {name} missing"))
                .clone()
        };
        let has = |command: &clap::Command, long: &str| {
            command
                .get_arguments()
                .any(|arg| arg.get_long() == Some(long))
        };
        let dfir = sub("dfir-timeline");
        assert!(has(&dfir, "clobber"));
        assert!(has(&dfir, "timeline-start"));
        assert!(has(&dfir, "timeline-end"));
        assert!(has(&dfir, "output-type"));
        assert!(has(&dfir, "multiline"));
        assert!(has(&sub("eid-metrics"), "clobber"));
        assert!(has(&sub("search"), "disable-abbreviations"));
    }

    /// #1046: `resolve_config_file` — used for `pivot_keywords.txt` and every other config file —
    /// must honor the `-c` custom config directory, preferring `<config_path>/<name>` when present
    /// (rather than always reading the bundled copy next to the executable).
    #[test]
    fn resolve_config_file_honors_custom_config_dir() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            dir.path().join("pivot_keywords.txt"),
            "Custom Users.SubjectUserName\n",
        )
        .unwrap();
        assert_eq!(
            super::resolve_config_file(dir.path(), "pivot_keywords.txt"),
            dir.path().join("pivot_keywords.txt")
        );
    }
}
