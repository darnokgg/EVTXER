# 変更点

## 4.2.0 [2026/10/12] - Autumn Release

**改善:**

- `-d, --directory` および `-l, --live-analysis` で見つかったログファイル（evtxファイル、または `-J` 指定時のJSON/JSONLファイル）を、ファイルシステムが列挙する順序ではなく、パスのソート順でスキャンするようにした。ソートなしのタイムラインはスキャン順に出力されるため、これまでは同じログでもOSやファイルシステムが異なる場合や、ディレクトリをコピーした場合に、タイムラインの順序が変わることがあった。検知結果は同じで、順序のみが異なっていた。 (#1929) (@YamatoSecurity)
- ルールディレクトリ（`rules/` または `-r <dir>`）から読み込むルールファイルを、ファイルシステムが列挙する順序ではなく、パスのソート順で読み込むようにした。同じレコードのバッチで見つかった検知結果はルールの読み込み順に出力されるため、これまでは同じルールとログでも、OSやファイルシステムが異なる場合や、ルールディレクトリをコピーした場合に、ソートなしのタイムラインの順序が変わることがあった。検知結果は同じで、順序のみが異なっていた。`encoded_rules.yml` から読み込むルールは元々順序が固定されており、変更はない。 (#1929) (@YamatoSecurity)

**バグ修正:**

- Sigmaのバックスラッシュとワイルドカードのエスケープが左から順に組み合わされず、高速マッチ経路と正規表現経路で異なる解釈になる問題を修正した。このため、同梱のSecurity EID 5145ルール（例:「Suspicious PsExec Execution」）が実際のPsExecの `ShareName`（先頭の2つのバックスラッシュ、リテラルの `*`、続く `\IPC$`）を見逃し、余分なバックスラッシュを持つ値やリテラルのアスタリスクを含まない値に誤検知することがあった。両経路でSigma仕様に準拠した共通のエスケープ解析を使用するようにし、`startswith`、`endswith`、`contains` にも適用した。エスケープされたワイルドカード、UNCパス、および公開PsExec EVTXサンプルの回帰テストを追加した。 (#1933) (@Shirofune-Security)
- スキャン終了時に表示される `Elapsed time`（および `--debug` の各処理時間）で、ミリ秒が秒に繰り上がらない問題を修正した。タイマーは各処理のミリ秒を足し合わせており、フォーマッタがその合計をそのまま表示していたため、114.393秒かかったスキャンが `00:01:53.1393` と表示されることがあった。秒とミリ秒を合算してからフォーマットするようにしたため、同じスキャンは `00:01:54.393` と表示される。 (#1930) (@YamatoSecurity)
- ソートなしの `dfir-timeline`（`-s` を指定しない既定の動作）で、集計（`count() by ...`）ルールの検知結果が実行のたびに異なる順序で出力され、同じログをスキャンした結果同士をハッシュや差分で比較できない問題を修正した。これらの検知結果は最後のレコードの後に出力され、グループごとの結果はプロセスごとに再シードされる `HashMap` から読み出されていたため、反復順が一定しなかった。グループキーをソート順に処理するようにした。これらの結果を元にする時間相関（temporal correlation）ルールも同じく順序が固定される。変わるのは順序だけで、検知結果とその内容は同じである。順序が変わるのは `count() by X` ルールが2つ以上の異なる X の値に一致した場合のみのため、小規模なスキャンでは現れなかった。 (#1929) (@YamatoSecurity)

**その他:**

- Rustのクレート依存関係を更新し、同梱の `hayabusa-evtx` のリビジョンを更新した。これにはBinXMLのアロケーションと名前長の検証強化（hayabusa-evtx#96）、およびメンテナンスされていない `encoding` クレートの `encoding_rs` への置き換え（hayabusa-evtx#97）が含まれる。 (@YamatoSecurity)

## 4.1.0 [2026/09/12] - Suzumushi Release

**新機能:**

- HayabusaのCSVを後処理する `sort-csv` コマンドを追加した。ヘッダーを保持し、`Timestamp` 列で行を並べ替え、重複した検知を削除する（`EvtxFile` 以外のすべての列を比較するため、内容が重複する `.evtx` ファイルやバックアップから収集された同じイベントは1件にまとめられる）。`-f, --file` で単一のファイル、または `-d, --directory` でCSVを格納したディレクトリ全体を指定できる（多数のエンドポイントから収集したCSVに便利）。`-o, --output` で指定したファイル、または標準出力に書き出し、`-C, --clobber` で上書きできる。`--low-memory-mode` ではスキャン中にできない処理を、スキャン後に行える。 (#1295) (@ChrisJr404)

**改善:**

- Windows版の実行ファイルに、製品名、ファイルの説明、会社名、著作権、元のファイル名などのバージョン情報（`VERSIONINFO`）を埋め込むようにした。ファイル/製品バージョンは `Cargo.toml` のパッケージバージョンから自動生成し、リリースワークフローでパッケージ化前にメタデータを検証する。 (#1926) (@YamatoSecurity)
- `logon-summary` コマンドに `-G, --geo-ip` オプションを追加した。集計された各ログオンの送信元IPアドレスに対して `Source ASN`、`Source Country`、`Source City` 列を追加する。 (#1920) (@fukusuket)

**バグ修正:**

- `-T, --visualize-timeline` のヒストグラムが、選択した時刻フォーマットに関わらず軸のマーカーを常に UTC で表示し、同じ出力内の他のタイムスタンプとホストの UTC オフセット分ずれる問題を修正した。同一のサマリー内で、軸の `2026-05-06 12:49:03` の10行ほど下に `First timestamp: 2026-05-06 15:49:03.364 +03:00` が表示され、どちらが UTC なのかを示すものが画面上に何もなかった。`calc_statistic_info` が UTC のエポック秒をそのまま収集しており、krapslog は各マーカーを `DateTime::from_timestamp`（常に UTC）で描画して末尾の `" UTC"` を取り除くため、マーカーはタイムゾーン表記のない UTC になっていた。krapslog に値が渡る前にオフセットを加算していたヘルパーは、2024年2月に最後の呼び出し元を失い、以降デッドコードになっていた。再びオフセットを適用するようにし、その際 Unix エポック時点ではなく変換対象の時刻におけるオフセットを用いるようにした（旧ヘルパーは `Local.timestamp_opt(0, 0)`、すなわち1970年のオフセットを読んでおり、サマータイムを採用している地域やその後ルールが変更された地域では誤った値になる）。オフセットの適用は描画時の軸マーカーに対してのみ行う。krapslog はマーカーをインデックスで選ぶ一方、スパークラインは値でビン分けするため、収集したタイムスタンプ自体をずらすと、サマータイム終了時には異なる2時間が1つのビンにまとめられ、開始時には描画される期間が1時間伸びてしまう。また、`format_time` とヒストグラムがそれぞれ個別に記述していた「出力が UTC かどうか」の判定を `TimeFormatOptions::is_utc_output` に共通化し、将来 UTC 固定のフォーマットが追加されても両者が食い違わないようにした。マーカー自体はオフセットを持たないため、ヒストグラムのタイトルにタイムゾーンを表示するようにした（`Detection Frequency Timeline (local time)`、`-U`/`--iso-8601` 指定時は `(UTC)`）。 (#1914) (@kotru21)

**その他:**

- Rustのクレート依存関係を更新し、同梱の `hayabusa-evtx` クレートを `0.9.12` に更新した（hayabusa-evtx#94）。このバージョンには `quick-xml` 0.42への互換対応が含まれる。 (@YamatoSecurity)

## 4.0.0 [2026/07/29] - Black Hat Arsenal USA Release

**改善:**

- Linux aarch64（ARM64）の musl リリースバイナリ（`hayabusa-<ver>-lin-aarch64-musl`）を追加した。正しく動作するよう、適切な aarch64 musl クロスツールチェインでビルドしている。（これまで報告されていた実行失敗は、musl ターゲットを glibc の `aarch64-linux-gnu-gcc` でリンクしていたためで、起動時に kill されるバイナリが生成されていた。） (#1332) (@YamatoSecurity)
- `logon-summary` コマンドが、RDP のセッションイベントも集計するようにした。既存の LocalSessionManager `21` と Gateway `302` に加えて、Security `4778`/`4779`（セッションの再接続/切断。RDP クライアントのワークステーション名とIPを含む）と、Terminal Services の運用ログの RemoteConnectionManager/Operational `1149`（ネットワークレベル認証）・LocalSessionManager/Operational `25`（セッション再接続）を対象に追加した。これにより、対応する Security `4624` がログからあふれて消えている場合でも RDP ログオンを集計でき、再接続/切断では接続元クライアントのホスト名も表示される。 (#1893) (@YamatoSecurity)
- `extract-base64` コマンドに、PowerShellのイベントID `4100`/`4102`（Microsoft-Windows-PowerShell/Operational および PowerShellCore/Operational）と、クラシックの `403`/`600`（Windows PowerShell）を追加した。`4100`/`4102` は `ContextInfo`（`Host Application = powershell -encodedcommand ...`）と `Payload` フィールドを、`403`/`600` は既存の `400` と同様に `EventData.Data` の詳細ブロックをスキャンする。 (#1889) (@YamatoSecurity)
- `logon-summary` の成功ログオンテーブルに `First Logon`/`Last Logon` 列を、失敗ログオンテーブルに `First Attempt`/`Last Attempt` 列を追加した。各アカウント/ソースの組み合わせがログオン（または試行）した時間の範囲を表示する。 (#1883) (@YamatoSecurity)

**バグ修正:**

- `eid-metrics`・`logon-summary`・`pivot-keywords-list` の出力順が実行のたびに変わり、同じログをスキャンした結果同士を差分比較できない問題を修正した。`eid-metrics` と `logon-summary` は件数のみでソートしていたため、件数が同じ行はプロセスごとに再シードされる `HashMap` の反復順のままになっていた。同数の場合はチャンネルとイベントID、およびログオンのグルーピングキーで順序を決めるようにした。`pivot-keywords-list` は各カテゴリのキーワードを `IndexSet` の挿入順で書き出していたが、値はレコードごとの並列タスクから挿入されるため順序が変動していた。ソートしてから出力するようにした。変わるのは順序だけで、行やキーワードの内容は同じである。 (#1912) (@YamatoSecurity)
- 結果サマリのテーブルで、上位5件のルールタイトルや作成者名にマルチバイト UTF-8（例: 日本語のルールタイトル）が含まれる場合にパニックする問題を修正した。タイトル/作成者をバイト単位のスライス（`&title[..32]`・`&author[0..24]`）で切り詰めていたため、バイト位置がマルチバイト文字の途中に来るとパニックしていた。出力をパイプ/リダイレクトした場合（幅の既定値により32バイトを超えるタイトルが切り詰められる）、スキャン完了後に実行全体がクラッシュし、サマリが失われていた。切り詰めを文字境界で行うようにし、幅の上限計算にも飽和減算を用いて、極端に狭いターミナルでもアンダーフローしないようにした。 (#1904) (@YamatoSecurity)
- `ComplexData` のイベントフィールド（例: Kernel-Processor-Power EID `26` の `IdleState`/`PerfState` の値）が正しく抽出されない問題を修正した。2つの `Name` 属性が `Name` の配列にまとめられ、フィールドの値が失われていた。通常の `<Data>` フィールドと同様に、`Name` 属性をキーとして展開するようにした（同梱の `hayabusa-evtx` を `0.9.10` に更新して修正）。 (#1520) (@YamatoSecurity)
- `pivot-keywords-list` で `-c`（カスタムのルール設定ディレクトリ）が無視され、常に実行ファイル同梱の `pivot_keywords.txt` を読み込んでいた問題を修正した。他の設定ファイルと同様に、`pivot_keywords.txt` を `-c` ディレクトリ経由で解決するようにした（存在しない場合は同梱コピーにフォールバック）。 (#1902) (@YamatoSecurity)
- `read_jsonl_to_value`/`read_json_to_value` のファイルオープンエラーが、ファイルパスの代わりにプレースホルダー `{path}` をそのまま出力していた問題を修正した（エラー文字列が `format!` ではなく通常の文字列リテラルだった）。 (#1897) (@YamatoSecurity)
- `eid-metrics` テーブルの「Event」列の幅計算で、55桁未満のターミナルで `u16` のアンダーフローが発生する問題を修正した。`terminal_width - 55` が45文字の下限を適用する前にアンダーフローし、オーバーフローチェック有効のビルドではパニックし、リリースビルドでは巨大な値にラップしていた（列の上限が実質無効になっていた）。飽和減算を使うようにした。 (#1897) (@YamatoSecurity)
- 明示的な UTC オフセット（例: `+09:00`）を持つ Splunk-JSON のタイムスタンプが `NaiveDateTime` で解析されてオフセットが破棄され、ローカルの時計時刻がそのまま UTC として保存されていた問題を修正した。これにより `log-metrics` の First/Last Timestamp 列に加えて `eid-metrics`/`logon-summary` の時刻範囲（`EventMetrics::stats_time_cnt` と `parse_evtx_datetime`）もずれていた。タイムラインの集計処理は、オフセットを適用する共通のパーサー（`utils::parse_evtx_timestamp`）を使うようにした。 (#1897) (@YamatoSecurity)
- カスタムのルール設定ディレクトリ（`-c`）を指定した `-G`（GeoIP エンリッチメント）が、そのディレクトリの `geoip_field_mapping.yaml` を無視する問題を修正した。ルックアップが拡張子なしの `geoip_field_mapping` を使っていたため実ファイルに一致せず、常にデフォルトのバンドルされたマッピングにフォールバックしていた。 (#1897) (@YamatoSecurity)
- `count(field)` 相関ルールがルールの `timeframe` より長い範囲にまたがる誤検知アラートを生成する問題を修正した。`judge_timeframe` のスライディングウィンドウで、条件を満たさなかったウィンドウを処理する分岐が左端を外す前にチェックなしの `add_data(right)` を行っていたため、ウィンドウの左端からタイムフレーム外であるとすでに判明している `records[right]` を次のウィンドウに取り込んでいた。そのレコードのフィールド値が新規の場合、タイムフレームより長い範囲でユニーク値のカウントがしきい値を超えることがあった。スライド時は左端を外すだけにして、内側のループが `right` をタイムフレームチェック付きで再度伸ばすようにしたため、タイムフレーム外のレコードはカウントされない。フィールド指定なしの `count()` は影響を受けない。 (#1896) (@YamatoSecurity)
- 結果サマリーの狭いターミナルでの表示に関する問題を修正した: `_print_timeline_hist` が `usize` の減算をチェックせずに行っていたため、極端に狭いターミナルでアンダーフローして巨大なメモリ確保やハングを引き起こす可能性があった（描画スペースが無い場合はヒストグラムをスキップし、`saturating_sub` を使うようにした）。ルール作者テーブルの行数を実際の列数ではなくハードコードされた `is_multiple_of(4)` で計算していたため多くの幅で不揃いなテーブルになっていた（`authors_num.div_ceil(table_column_num)` に変更）。また、ルール作者テーブルが非常に狭いターミナル（72文字以下）ではみ出す/折り返す代わりに1列にフォールバックするようにした。タイムライン出力には影響しない。 (#1858) (@YamatoSecurity)
- `update-rules` 実行後に表示される文法的に誤ったメッセージ「Successed submodule update」を「Submodule update succeeded」に修正した。 (#1840) (@YamatoSecurity)
- `temporal`/`temporal_ordered` 相関が、参照ルールのマッチを結合する際にルールの `group-by` 値を検証していなかった問題を修正した。各参照ルールは group-by 値ごとに集計されるものの、タイムスタンプがタイムフレームに収まってさえいれば異なるグループ（例: 異なる Computer）のマッチ同士が相関してしまい、誤検知を生んでいた。参照ルールのマッチは、ベースとなるマッチと同じ group-by 値を持つことを要求するようにした。 (#1841) (@YamatoSecurity)
- `temporal_ordered` 相関が最初の参照ルール以降のイベント順序を検証できていなかった問題を修正した。無意味な代入（`last_base = base`）により、以降のすべてのルールがベースイベントのウィンドウとしか照合されず、順序が入れ替わった攻撃チェーンのイベント（例: A→B→C を要求するルールに対する A→C→B）がマッチしてしまっていた。各参照ルールは、ベースイベントを起点とするタイムフレームウィンドウ内に収まりつつ、直前のルールがマッチしたイベント以降にマッチすることを要求するようにした。 (#1841) (@YamatoSecurity)

**その他:**

- Rustのクレート依存関係をすべて最新版に更新した。同梱の `hayabusa-evtx` クレートも `0.9.11` に更新している（hayabusa-evtx#93）。このリリースは依存関係の更新のみで `.rs` の変更を含まないため、evtxの解析挙動は変わらない。60個のevtxファイルからなるコーパスで、`dfir-timeline` の CSV/JSON/JSONL 出力（`-x, --recover-records` 併用時を含む）と `log-metrics` の出力がバイト単位で同一であることを確認した。 (#1912) (@YamatoSecurity)
- `DefaultMatcher` のパイプ修飾子の処理を、`src/detections/rule/matchers/modifiers/` 配下のカテゴリ別モジュール（`string`・`regex`・`numeric`・`cidr`・`fieldref`・`encoding`）に再編した。各修飾子のロジック（パターンのラップ/ワイルドカード変換、正規表現フラグ、数値比較、cidr、フィールド参照、base64/utf16 エンコード）は、これまで `pipe_element.rs` と `default_matcher.rs` に散らばった手書きの `match` 分岐にあったが、グループごとに1つのカテゴリモジュールにまとめ、値を直接マッチする修飾子（cidr/numeric/fieldref）は小さな `ValueMatcher` トレイトの背後に置いたため、`DefaultMatcher::is_match_inner` は `value_match` の1回の呼び出しになった。`PipeElement` 列挙型と #1862 の `MatchPlan` による正規化は変更していないため、Sigma 修飾子の追加は複数のディスパッチ箇所ではなく1つのカテゴリモジュールの編集で済む。純粋な再編で、157個のマッチャーテストがパスし、検知結果の出力はバイト単位で同一（サンプルevtxの CSV/JSON/search と、2,838個のevtxに対する `csv-timeline` コーパス）。 (#1895) (@YamatoSecurity)
- `src/detections/rule/mod.rs`（モジュール宣言と、コアとなるルール型や大きなテストモジュールが混在した約1,200行）を、`RuleNode`・`DetectionNode`・`CorrelationType`・`create_rule`/`get_detection_keys`・テストを収めた新しい `rulenode.rs` に分離し、`AggResult` は（それを生成する集計ロジックと、依存先の `AggRecordTimeInfo` の隣である）`count.rs` に移動した。`mod.rs` はモジュールの取りまとめと再エクスポートのみになり、既存のインポートパスはすべて変更なしで動作する。純粋なコード移動で、検知結果の出力はバイト単位で同一。 (#1890) (@YamatoSecurity)
- `src/main.rs` の約860行に及ぶ `App::analysis_files` 関数をリファクタリングした。この関数は対話式のルールセットウィザード全体、可読性の低い5つの位置引数を取るカウント用クロージャ、アドホックなチャンネルフィルタ、プログレスバーの構築をインラインで抱え込んでいた。4つの名前付きユニットを抽出した: `run_scan_wizard()`（対話式ウィザード全体。選択されたルールセットのラベルを返す）、`calculate_wizard_rule_count()`（先頭の `bool` と3つの `Vec<&str>` という位置引数の代わりに `WizardCountFilter` 構造体を取る自由関数に昇格したクロージャ。ユニットテスト付き）、`apply_channel_filters()`（`logon-summary`/`config-critical-systems`/`log-metrics` のアドホックなチャンネルフィルタ）、`build_progress_bar()`。`analysis_files` は、合計の表示・ウィザード・ルール読み込み・フィルタ・スキャンループ・出力、という流れで読めるようになった。挙動に変更はない — 影響を受けるすべてのサブコマンドで出力はバイト単位で同一であり、対話式ウィザードの経路（`--no-wizard` のスキャンでは通らない）は敵対的レビューによって忠実な行単位の移動であることを確認した。 (#1885) (@YamatoSecurity)
- `src/detections/configs.rs` の約700行に及ぶ `StoredStatic::create_static_data` 関数をリファクタリングした。この関数は実際には決して `None` にならない `Option<Config>` を受け取り、それを33回 `.unwrap()` していた。シグネチャを `Config` を受け取るように変更し、アクションを一度だけ束縛する（`let action = config.action.as_ref()`）ようにして、繰り返しの unwrap と `None` でパニックする危険を取り除いた（すべての呼び出し側を更新）。また、コピペを解消するために3つのヘルパーを抽出した: 9個の設定ファイルで重複していた12行の設定ファイルフォールバックチェーンのための `resolve_config_file()`、繰り返されていた `LEVEL::iter().any(...)` のレベル検証のための `is_valid_level()`、include/exclude の computer・EID の `.iter().map(CompactString::from).collect()` という約120行のコピペのための `compact_string_set()`。`configs.rs` を正味 −250 行削減し、挙動に変更はない — 影響を受けるすべてのサブコマンド（`csv-timeline`、`json-timeline`、`logon-summary`、`computer-metrics`、`log-metrics`、`search`）で出力はバイト単位で同一（`eid-metrics` と `logon-summary` の成功テーブルも一致する。ただし未改変のバイナリにも存在するグループ内の同点時の並び順の非決定性を除く）。 (#1884) (@YamatoSecurity)
- `search` コマンドのヒット処理ロジックの重複を解消した。`search_keyword` と `search_regex` は、マッチ判定の後に完全に同一な約65行の末尾処理（イベント情報の抽出、`Provider_EventID` によるフィールド略称テーブルの参照、AllFieldInfo の空白の正規化、そしてソート用にヒットを収集するか逐次書き出すかの分岐）を重複して持っており、ヒット処理への修正を2箇所に適用する必要があって、2つのコピーが乖離する恐れがあった。両方のループがマッチ判定の後に呼び出す単一の `emit_hit` メソッドに抽出した。出力は、キーワード検索・正規表現検索それぞれのソートあり/逐次出力の両方でバイト単位で同一。 (#1881) (@YamatoSecurity)
- グローバルミュータブルな `PIVOT_KEYWORD`（`lazy_static RwLock<IndexMap<String, PivotKeyword>>` で、`pivot-keywords-list` のキーワードアキュムレータ）を廃止し、`StoredStatic` の `pivot_keyword: Arc<RwLock<PivotKeywordMap>>` フィールドにした。キーワードの値はレコードごとの並列タスク（`execute_rule` 内の `insert_pivot_keyword`。`STORED_STATIC` グローバルクローンから `stored_static` を読み取る）で埋められ、`App::exec`（別インスタンス）で読み戻されるため、`Arc` により `StoredStatic::clone()` が両者で単一のマップを共有できる（既存の `geo_ip_search` フィールドと同様）。`load_pivot_keywords`/`insert_pivot_keyword` はマップを明示的に受け取るようになり、`main.rs` の読み取り箇所は `stored_static.pivot_keyword` を使用する。`PIVOT_KEYWORD_TEST_LOCK`（テストがグローバルを共有していたためにのみ必要だった）は削除された。各pivotテストは独自のローカルマップを構築し、完全な並列実行下でもパスする。挙動は保存される。`pivot-keywords-list` はサンプルevtxコーパスで同一のカテゴリファイルをバイト単位で同一のソート済み内容とともに生成する（カテゴリ内の行順は実行ごとに本質的に非決定的であり、これは `main` でも同様で、キーワードが並列タスクから挿入されるためである）。 (#1873) (@YamatoSecurity)
- グローバルミュータブルな `ERROR_LOG_STACK`（`lazy_static Mutex<Nested<String>>` で、`./logs/errorlog-<timestamp>.log` にフラッシュされる実行全体のエラーログ蓄積用）を廃止し、`StoredStatic` の `error_log_stack: Arc<Mutex<Nested<String>>>` フィールドにした。`Arc` により `StoredStatic::clone()` が `STORED_STATIC` のグローバルクローンと単一のスタックを共有できる。これはエラーがレコードごとの並列タスクからもpushされるためである（`count(field)` のミスは `RuleNode::select` 内で発生し、これは `execute_rule` からルールごとに呼び出される）。既に `stored_static` がスコープ内にあった約28箇所のpush箇所は `stored_static.error_log_stack` を使うようにし、`quiet_errors_flag` のみを受け取っていた4つの関数（`create_error_log`、`get_file_size`、`peek_channel_from_evtx_first_record`/`create_channel_filter`、および `count`→`create_count_key`→`get_alias_value_in_record` のチェーン）は、呼び出し元から引き渡される明示的な `&Mutex<Nested<String>>` を受け取るようにした。これには `filter_evtx_files`→`apply_channel_filter` 経由も含まれ、`log-metrics` のチャンネルフィルタリングが引き続きevtxオープンエラーを報告できるようにした。挙動は保存される。collect-and-flush のセマンティクスは同一で、エンドツーエンドで検証済み（破損したevtxは引き続き `Failed to open evtx file` エントリを含むエラーログを書き出す）。 (#1875) (@YamatoSecurity)
- グローバルミュータブルな `STORED_STATIC`（`lazy_static RwLock<Option<StoredStatic>>`、巨大構造体そのものであり、プロセスグローバルの最後の1つ）を廃止した。`Detection::execute_rule` は各ルールを自身の spawn したタスク内で実行し、共有される `StoredStatic` をこのグローバルから読み戻していた。これはスキャン前に `analysis_files` が一度だけ公開したものである。プロダクションでの読み手はちょうど1つ（`execute_rule`）、書き手も1つだけであり、純粋に `'static` な spawn したタスクへ `stored_static` を渡すためのフォールバックにすぎなかった。現在は `analysis_files` が `stored_static` を一度だけ `Arc<StoredStatic>` にスナップショットし（グローバルが保持していたのと同じ単一のクローンであり、`Arc` でラップされた内部フィールド（`error_log_stack`、`pivot_keyword`）は生きている `stored_static` と共有されたままなので、並列パスでの蓄積は引き続き可視である）、それを `analysis_file`/`analysis_json_file`/`process_detection_batch` 経由で `Detection::start`/`execute_rules` に通し、各 spawn したタスクには自身の安価な `Arc::clone` を渡す（既存の `records_arc` と同様）。`execute_rule` は自身の `stored_static` 引数を読む。唯一のプロダクションでの書き込み、グローバル定義、および冗長なテスト専用の初期化は削除された。挙動は保存される。検知出力はサンプルevtxコーパスでバイト単位で同一（CSV、super-verbose プロファイル）。 (#1876) (@YamatoSecurity)
- 最後の共有ミュータブルなプロセスグローバル、`COMPUTER_MITRE_ATTCK_MAP`（`DashMap`）と `COMPUTER_MITRE_ATTCK_UNIQUE_KEYS`（`DashSet`）——HTMLレポート用のコンピュータごとのMITRE ATT&CKタクティクのアキュムレータ——を廃止した。これらは（`pivot_keyword`/`error_log_stack` に倣って）`StoredStatic` の `computer_mitre_attck_map: Arc<DashMap<..>>` / `computer_mitre_attck_unique_keys: Arc<DashSet<..>>` フィールドにした。レコードごとの並列タスク（`execute_rule` 内の `create_log_record`、共有 `Arc` 経由）から書き込まれ、レポートのレンダリング時に読み取り／クリアされる（`_output_html_computer_by_mitre_attck` は `stored_static` を受け取るようになった）。`STORED_STATIC` が既に廃止されたことで、テストの直列化を強制する共有ミュータブルな状態がなくなったため、`rust.yml` と `coverage.yml` ワークフローから `RUST_TEST_THREADS: 1` を削除した——lib + bin のテストスイートは完全な並列実行でパスする。挙動は保存される——`csv-timeline` の出力とHTMLレポートのMITRE ATT&CK Tacticsテーブル（コンピュータごとのunique|total件数）はサンプルevtxコーパスでバイト単位で同一。 (#1878) (@YamatoSecurity)
- HTMLレポートのMITRE ATT&CKタクティクの集計用グローバル変数（`COMPUTER_MITRE_ATTCK_MAP` と `COMPUTER_MITRE_ATTCK_UNIQUE_KEYS`）を、テーブル出力後にクリアすることで単一レポートの範囲に限定した。これにより、同一プロセス内で後続のレポートを生成してもキーが残留してタクティクごとのユニーク数が過少カウントされることがなくなった。あわせて、タクティクのセルを結合する際の中間 `Vec` を削除した。通常の（単一レポートの）実行では挙動に変更はない。 (#1840) (@YamatoSecurity)
- 3つのほぼ同一な検知セレクションノード型（`AndSelectionNode`、`AllSelectionNode`、`OrSelectionNode`）を、論理演算子 `All`/`Any` でパラメータ化した単一の `NarySelectionNode` に統合し、重複コード約105行を削除した。純粋なリファクタリングで、出力がバイト単位で同一であることを確認済み。 (#1843) (@YamatoSecurity)
- `afterfact.rs` の手書きのJSON文字列エスケープ（`_convert_valid_json_str` の `.replace('🛂', "\\").replace('\\', "\\\\").replace('"', "\\\"")` の連鎖）を `serde_json` ベースのヘルパーに置き換え、バックスラッシュ・引用符・制御文字のエスケープを手作業ではなくシリアライザに任せるようにした。`csv-timeline` と `json-timeline` の出力はバイト単位で同一（サンプルevtxコーパスで検証、新しいリグレッションテストと既存の文字列一致テストで担保）。#1845 の最初のステップ。 (#1850) (@YamatoSecurity)
- #1845 で追跡しているJSONシリアライズのリファクタリングの第2段階として、`json-timeline` のレコード生成を `serde_json` ベースに書き換えた: 各レコードを順序を保持した `serde_json` の値として組み立て、ライブラリにシリアライズさせるようにし、手書きの文字列連結（`_create_json_output_format`、`_convert_valid_json_str`、`json_escape_body`、`process_target_stock`）を削除した。`csv-timeline` の出力はバイト単位で同一。`json-timeline` のデータも同一（サンプルevtxコーパスに対する順序保持のカノニカル比較で検証済み）だが、繰り返し出現する `Details` の配列が複数行で出力されるようになり、JSONLは標準的なコンパクト形式（`"k":v`）になった。さらに、旧JSONL経路が値の中の連続スペースを除去して（著者一覧や `EvtxFile` のパスを壊して）いたデータ破損バグを修正し、値をそのまま保持するようにした。 (#1851) (@YamatoSecurity)
- JSONシリアライズのリファクタリング（#1845）の第3段階として、`json-timeline` の出力をテキストシンクとして流用していた `csv::Writer` を経由せず、JSON/JSONLのレコードを（`ResultWriter` enum を介して）出力先へ直接書き込むようにした。`csv-timeline` は引き続き `csv::Writer` を使用する。`csv-timeline`・`json-timeline`（`-o`）・`json-timeline`（`-L`）の出力はバイト単位で同一（サンプルevtxコーパスで検証済み）。 (#1852) (@YamatoSecurity)
- 分かりにくい `afterfact` モジュールとその識別子を、内容を表す結果出力向けの名前にリネームした: `src/afterfact.rs`→`src/results.rs`、`AfterfactInfo`→`ResultOutputState`、`AfterfactWriter`→`OutputWriter`、`output_afterfact`→`output_results`、`output_additional_afterfact`→`output_result_summary`、ローカル変数の `afterfact_info`/`afterfact_writer`→`result_state`/`output_writer`。純粋なリネームで挙動に変更はない（全テストがパス）。 (#1853) (@YamatoSecurity)
- `remove_sp_char` が制御文字の除去から `\n`/`\r`/`\t` を守るために使っていた `🛂` 絵文字のセンチネル（プレースホルダ）を削除した（#1845 リファクタリングの最終段階）。実際の文字をそのまま保持し、出力形式ごとに処理するようにした（JSONは `serde_json` がエスケープ、CSV/`search` はスペースに畳み込む）。**`csv-timeline` の出力はバイト単位で同一**。**`json-timeline` の出力は変化する**: 値の内部の改行/タブ/CRが従来の可視テキスト `\\n` ではなく本来の `\n`/`\t`/`\r` エスケープとしてシリアライズされ、`Details` 値の先頭・末尾の改行はトリムされるようになった。サンプルevtxコーパスで検証済み（JSONの差分はこの2点のみで、内部の内容は失われない）。 (#1849) (@YamatoSecurity)
- 約4,092行の `src/results.rs` を `src/results/` モジュールディレクトリ（`mod.rs` と `csv.rs`・`json.rs`・`display.rs`・`summary.rs`・`html_stock.rs`）に分割し、ライターの構築、CSV/JSON/ターミナル表示の出力、サマリーレンダラーと統計、HTMLストックの組み立てを分離した。純粋なコードの移動で、出力はバイト単位で同一（サンプルevtxコーパスで検証済み）、全テストがパスする。 (#1856) (@YamatoSecurity)
- 最後に残っていた `🛂` 絵文字センチネルマーカー（`--multiline`/`--tab-separator` のCSV（およびターミナル表示）で複数のルール作者 `RuleAuthor` を結合するために使っていた `🛂🛂` 区切り）を削除した。作者文字列をそのまま保持し、マーカーを経由する代わりに出力の段階で出力モードごとに分割・結合するようにした。出力はバイト単位で同一（サンプルevtxコーパスの default/multiline/tab CSV・JSON・ターミナル表示で検証済み）。#1849 で始めた絵文字センチネルの削除を完了した。 (#1860) (@YamatoSecurity)
- `DefaultMatcher` のパイプ修飾子の処理を正規化した: 高速マッチャーはパイプ数・パイプの組み合わせを手作業で列挙し、順序とインデックスに依存したテーブル（`pipes[0] == Base64 && pipes[1] == Contains`、`utf16|base64offset|contains`、`|contains|all|windash` など）で構築していたが、パイプのリストを1回の O(n) パスで正規の `MatchPlan { wrap, encoding, utf16, cased, windash, all }` にまとめ、そこからマッチャーを構築するようにした。不要になった `create_fast_match` ヘルパーは削除した。157個のマッチャーテストと全ライブラリテストがパスし、検出結果はサンプルevtxコーパス（CSV・JSON）でバイト単位で同一。新しいディスパッチは順序・パイプ数に依存しない: 正規の順序のルール（実在するすべての Sigma ルール）は変わらず、旧テーブルが正規表現フォールバックに落として修飾子を無視していた非正規の順序（例: `|cased|contains` は大文字小文字を区別せずにマッチしていた）は、正規の順序と同じように正規化されるようになった。#1861 のパート1で、`matchers.rs` のモジュール分割は今後の対応。 (#1862) (@YamatoSecurity)
- 約4,900行の `src/detections/rule/matchers.rs` を `src/detections/rule/matchers/` モジュールディレクトリ（`mod.rs` と `leaf_matchers.rs`・`default_matcher.rs`・`pipe_element.rs`・`tests.rs`）に分割し、`LeafMatcher` トレイト、ファイルベースのマッチャー、`DefaultMatcher`/`MatchPlan`、`PipeElement` 列挙型、ユニットテストを分離した。純粋なコードの移動で、出力はバイト単位で同一（サンプルevtxコーパスの CSV・JSON で検証済み）、全テストがパスする。#1861 のパート2で、修飾子ごとのトレイト化は今後の対応。 (#1863) (@YamatoSecurity)
- `main.rs` の検出バッチループの重複を解消した: evtx と JSON のスキャンループにコピー＆ペーストされた末尾処理（レコード構築 → タイムライン → ルール実行 → 結果のストリーム出力またはバッファリング）があり、「バッチごとに出力するか最終的にソート出力するためにバッファするか」の分岐が3箇所に重複していた。単一の `emit_or_buffer` ポリシーヘルパーと、末尾処理を共通化した `process_detection_batch`（ループ間で異なる2点を名前付きの `BatchPolicy` でパラメータ化）を抽出した。動作は不変で、ソートされた出力はサンプルevtxコーパスの CSV・JSON でバイト単位で同一、ライブラリとバイナリの全テストがパスする。 (#1865) (@YamatoSecurity)
- `main.rs` の約1,030行の巨大な関数 `App::exec` をサブコマンドごとのメソッドに分割し、ディスパッチャとして読めるようにした：`run_update_rules`、`run_level_tuning`、`run_set_default_profile`、`run_list_profiles`、`run_expand_list`（早期リターンする5つの match アーム）、`run_pivot_keywords_output`（pivot-keywords-list の出力ブロック）、`prompt_critical_systems_config`（config-critical-systems の対話プロンプト。37行の `ColorfulTheme` リテラルを含むが、抽出後も同じ位置で呼び出しており、"Start time:" の前にプロンプトが表示される挙動を維持）、`print_closing_summary`（経過時間／レポートリンク／HTMLレンダリング／エラーログ／デバッグ統計の末尾処理）。各メソッドの本体は元のコードをそのまま移したもので、`stored_static` を自由に借用できるよう、ディスパッチは借用ではなく所有された `stored_static.config.action.clone()` に対して match するようにした。挙動は保存され、`csv-timeline`／`json-timeline`／`pivot-keywords-list` の出力はサンプルevtxコーパスでバイト単位で同一であることを確認済み。 (#1877) (@YamatoSecurity)
- `src/detections/configs.rs` の重複した clap 引数を解消した: `--clobber`（8個のサブコマンド構造体で宣言）、`--timeline-start`/`--timeline-end`（各4個）、`--disable-abbreviations`（4個）を、共有の `ClobberOption`/`TimeRangeOption`/`DisableAbbreviationsOption` 構造体に抽出し、各サブコマンドに `#[clap(flatten)]` した。これにより、新しいサブコマンドはこれらの引数を再宣言する代わりに共有構造体をフラット化するだけでよくなった。CLI の変更はなく、各サブコマンドの `--help` はバイト単位で同一、検出結果もサンプルevtxコーパス（CSV・JSON）でバイト単位で同一。 (#1867) (@YamatoSecurity)
- `STORED_EKEY_ALIAS` グローバル可変状態（`lazy_static RwLock<Option<EventKeyAliasConfig>>`）を廃止し、エイリアス設定を明示的に渡すようにした: `create_log_record`/`create_agg_log_record` は `&stored_static.eventkey_alias` を直接読み、`count`/`countup`/`create_rec_info` は明示的な `&EventKeyAliasConfig` を受け取る（ルールキーとともに `RecordBuildContext` にまとめ、ファイルごとに一度だけ構築して各レコードの並列タスクへ `Arc` で共有）。約33箇所の `*STORED_EKEY_ALIAS.write() = Some(...)` のテスト用初期化を削除した。動作は不変で、検出結果はサンプルevtxコーパス（CSV・JSON）でバイト単位で同一。プロセスグローバルな可変状態を廃止する最初の段階（残りのグローバルは今後の対応）。 (#1869) (@YamatoSecurity)
- ジオIP関連の4つのグローバル可変状態（`GEOIP_DB_PARSER`/`GEOIP_DB_YAML`/`GEOIP_FILTER` と ルックアップキャッシュ `IP_MAP`）を廃止した: キャッシュは `GeoIPSearch` の `Mutex` フィールドになり（`convert_ip_to_geo` で使用）、3つのDB/設定グローバルは `StoredStatic` のフィールド（`geo_ip_search: Option<Arc<GeoIPSearch>>`、`geo_ip_db_yaml`、`geo_ip_filter`）になり、各箇所（`create_log_record`、`emit_csv_inner`、`load_profile`）で `stored_static.geo_ip_*` として読むようにした。動作は不変で、`--GeoIP`（ジオIP経路を実行）で検出結果はサンプルevtxコーパス（CSV・JSON）でバイト単位で同一。プロセスグローバルな可変状態を廃止する2番目の段階。 (#1870) (@YamatoSecurity)
- `CHECKPOINT` グローバル可変状態（`lazy_static Mutex<CheckPointProcessTimer>`、フェーズ計測用のストップウォッチ）を廃止した: `App::exec`/`App::analysis_files`（どちらも `&mut self`）からのみ使われ、並列タスクからは使われないため、`App` の素の `checkpoint` フィールドにした（グローバルも `Mutex` も不要）。11箇所の `CHECKPOINT.lock()...` を `self.checkpoint` に置き換えた。動作は不変で、タイマーはフェーズのラップを記録し `--debug` 時に出力するだけであり、`--debug` 実行では引き続き Rule Parse / Analysis / Output の処理時間と合計経過時間が表示される。プロセスグローバルな可変状態を廃止する3番目の段階。 (#1871) (@YamatoSecurity)
- `HTML_REPORTER` グローバル可変状態（`lazy_static RwLock<HtmlReporter>`、HTMLレポートのアキュムレータ）を廃止した: `add_md_data` を `HtmlReporter` のメソッドにし、`create_html` は `&self` を取るようにした。`App::exec` が単一の `HtmlReporter` を所有し、レポートのセクション（ルール読み込み情報、結果サマリー、プロファイル/概要）を記録する各経路に `&mut` で渡してから描画するようにした（グローバルへの書き込みと最後の `read().to_owned().create_html()` を置き換え）。テストがグローバルを共有するためだけに存在していた `HTML_REPORTER_TEST_LOCK` も削除し、レポートセクションのキーはすべて `GENERAL_OVERVIEW_SECTION`/`RESULTS_SUMMARY_SECTION` 定数を使うようにした。動作は不変で、`--html-report` で生成されるHTMLはサンプルevtxコーパスでバイト単位で同一（非決定的な経過時間を除く）。プロセスグローバルな可変状態を廃止する4番目の段階。 (#1872) (@YamatoSecurity)

## 3.10.0 [2026/07/04] - Independence Day Release

**改善:**

Sigma 2.1仕様の `|neq` および `|fieldref|neq` フィールド修飾子のサポートを追加した。`|neq` は比較を否定するもので、他の修飾子（`|contains|neq`、`|startswith|neq`、`|endswith|neq`、`|fieldref|neq` など）と組み合わせて使用できる。 (#1684) (@YamatoSecurity)
検出されたMITRE ATT&CK戦術について、一意の件数と合計件数を追加した。 (#1753) (@fukusuket)

**バグ修正:**

- MITRE ATT&CK Tacticsの項目が、HTMLレポートで適切に改行されていなかった。 (#1751) (@fukusuket)
- 大量のファイルをスキャンする際に、スキャンのプログレスバーがその場で再描画されず、更新ごとに新しい行に表示される問題を修正した。プログレスバーのテンプレートにリテラルの改行コード（`\r\n`）が含まれていたことが原因。 (#1760) (@YamatoSecurity)
- ピボットキーワードリスト機能のレベル除外判定にあったタイポ（`infomational` → `informational`）を修正した。この誤字により `informational` レベルのレコードが除外されず、そのフィールド値がピボットキーワードリストに混入していた。 (#1804) (@YamatoSecurity)
- HTMLレポートのMarkdownインジェクションの問題を修正した。ユーザー由来の値（コンピュータ名など）はHTMLエスケープされていたがMarkdownエスケープはされておらず、`[x](javascript:alert(1))` のような値がクリック可能な `javascript:` リンクとして描画される可能性があった。ユーザー値内のMarkdownメタ文字もエスケープするようにした。 (#1806) (@YamatoSecurity)
- null-UUIDのテストルールを除外ルール・ノイジールールの件数から除くための判定が、ルールIDではなく除外リストファイルのパスと比較していたため機能しておらず、テストルールが`Excluded rules`の件数を水増ししていた問題を修正した。 (#1821) (@YamatoSecurity)
- Results Summary（およびHTMLレポート）のユニーク検知のパーセンテージがレベル間で鏡写しに入れ替わっていた問題を修正した。逆順ループのインデックスでパーセンテージを計算していたため、例えば`critical`の行に`informational`のパーセンテージが表示されていた（正しかったのは中央の`medium`のみ）。 (#1812) (@YamatoSecurity)
- `logon-summary`コマンドで、RDSゲートウェイのログオン（`Microsoft-Windows-TerminalServices-Gateway/Operational`のEID 302）のTarget Domain列が常に`-`になっていた問題を修正した。`dst_domain`の抽出がイベントキーエイリアス`RdsGtwUsername`をスペルミスの`RdsGtwUserName`で参照していたため、`DOMAIN\user`形式の値からドメインが取得されていなかった。 (#1809) (@YamatoSecurity)
- GeoIP機能がすべてのパブリックIPv6アドレスを`Private`として扱い、GeoIP検索を行っていなかった問題を修正した。IPv6のプライベート範囲リストにグローバルユニキャスト空間全体である`2000::/3`が含まれていたことが原因。あわせて冗長な`FD00::/8`（`FC00::/7`に包含される）も削除し、パブリックIPv6アドレスにASN・国・都市の情報が付与されるようにした。 (#1819) (@YamatoSecurity)
- 正規表現マッチにフォールバックするワイルドカードのフィールドパターン（`?` を含む、途中に `*` がある、または非ASCII文字と `*` を含むパターン）が、アンカーなしの正規表現にコンパイルされ `Regex::is_match()`（部分一致検索）で照合されていた問題を修正した。このためフィールド値全体ではなくパターンを単に「含む」値にも一致し、誤検知が発生していた（例: `Channel: Sec?rity` が `MySec1rityLog` に、`net*user` が `mynetXuserZ` に一致）。これらのワイルドカード正規表現を値全体にアンカーするようにし、Sigmaの完全一致セマンティクスおよびHayabusaの高速マッチ経路（`Exact`/`StartsWith`/`EndsWith`）と整合させた。キーワード（grep）検索と `|re` 正規表現は意図的にアンカーなしのままとした。 (#1826) (@YamatoSecurity)
- HTMLレポートのGeneral Overviewセクションから、解析したイベントファイル数・合計ファイルサイズ・選択した検知ルールセット・除外タグの各行が抜け落ちていた問題を修正した。これらがスペルミスのセクションキー（`{#general_overview}` ではなく `#` が波括弧の外にある `General Overview #{general_overview}`）で登録されており、レンダラーが描画しないキーだったため、データが黙って破棄されていた。キー（今後ずれないよう共通のセクション名定数に統一）と、あわせて合計ファイルサイズ行・ルールセット行のラベルの誤りを修正した。 (#1827) (@YamatoSecurity)
- `-X`/`--remove-duplicate-detections` で、重複した検知の2件目が、それらがタイムスタンプグループの先頭レコードだった場合に除去されない問題を修正した。`get_duplicate_indices()` が各グループの先頭レコードを比較用のセットに追加していなかった（初回レコードの分岐とタイムスタンプ境界の分岐の両方で挿入をスキップしていた）ため、2件目が一意とみなされ、3件目以降しか除去されていなかった。この結果、`csv-timeline`/`json-timeline` の出力に重複行が残り、検知件数が水増しされていた。タイムスタンプグループ内の同一なN件の検知のうち、ちょうど1件だけが残るように修正した。 (#1828) (@YamatoSecurity)
- `read_encoded_file` が、エンコード済みルール（`encoded_rules.yml`）の読み込み時にI/O読み込みエラーを黙って無視し（切り詰められた・空のルールセットを返す）、不正なUTF-8に対して `.expect()` でパニックしていた問題を修正した。どちらも `Result` を通じてエラーとして返すようにした。 (#1834) (@YamatoSecurity)

**その他:**

- 可読性向上のため、`src/` 内の分かりにくい・誤解を招く・Hayabusa固有の変数・引数・構造体フィールド名76個を、より明確で慣用的なRustの名前にリネームした（例: `datas`→`records`、`con_cal`→`joined_value`、`name_2_node`→`name_to_node`、`hlch`→`horizontal_line_char`、`rulepath`→`rule_path`、`ext_field`→`output_fields`、および実際にはAND条件の`AllSelectionNode`を保持していた誤名の`or_node`→`all_node`）。内部識別子のみの変更で、挙動・出力に変化はない。 (#1830) (@YamatoSecurity)
- `hayabusa-evtx` クレートを `0.9.9` に更新し、その依存クレート（特に `thiserror` 1→2、`criterion` 0.5→0.8）をすべて最新版に更新した。挙動に変更はない。 (#1835) (@YamatoSecurity)
- レビューで判明した2箇所のデッドコードを削除した。JSON文字列エスケープ処理の常に空になる `addition_header` 分岐と、相対時刻オフセット解析における到達しない分岐および単位ごとの `Vec` 割り当て。挙動に変更はない。 (#1834) (@YamatoSecurity)

## 3.9.0 [2026/04/29] - Showa Day Release

**改善:**

MITRE ATT&CK v19に対応した。(@fukusuket)

**その他:**

ユニットテストの追加。 (#1746) (@Fuzzdkk)

## 3.8.1 [2026/02/24] - Spring Hayfever Release

**バグ修正:**

複数のプログレスバーの問題を修正した。 (#1740) (@fukusuket)

## 3.8.0 [2026/01/31] - Winter Release

**バグ修正:**

- MaxMindのコンパイルエラーを直した。 (#1722) (@fukusuket)
- `-GeoIP`が指定された場合、GeoIPフィールドはJSONタイムラインの`Details`と`ExtraFieldInfo`の両方に出力されていた。 (#1724) (@fukusuket)
- 破損したログによるパニックの可能性を修正した。 (#1732) (@fukusuket)

**脆弱性修正:**

- HTMLレポートにおけるXSS脆弱性を修正した。ユーザが（標準の`.evtx`ファイルではなく）JSON形式でエクスポートされたログをスキャンし、攻撃者がそれらのログの`Computer`フィールドに悪意のあるJavaScriptを注入できる場合に発生する問題。 (@fukusuket)
  - この問題を発見し報告してくれた[Mobasi](https://mobasi.ai/)チームに深く感謝します！

## 3.7.0 [2025/11/15] - CODE BLUE Release

**新機能:**

- `csv-timeline`および`json-timeline`コマンドでチャンクヘッダーのチェックサムを確認する`-V, --validate-checksums`オプションを追加した。 (#1709) (@fukusuket)

**改善:**

- `log-metrics`コマンドに、4つの新しいコマンドラインオプション `--include-channel`、`--exclude-channel`、`--include-filename`、`--exclude-filename` を追加した。 (#1715) (@fukusuket)
- Timesketchのインストール用Readmeを更新し、ARMベースのMacでのTimesketchサポートを追加した。 (#1719) (@fukusuket)

**バグ修正:**

- `validate_checksum`が無効（デフォルト設定）になっている場合、イベントの`data_size`がゼロに設定されていると、無限ループとメモリリークが発生する問題が修正された。 (omerbenamram/evtx#264)
- `-t, --threads`オプションが`computer-metrics`および`search`コマンドで機能していなかった。(#1563) (@hach1yon)
- 複数のコンピュータからのログをスキャンした際、`log-metrics`が誤った結果を返していた。 (#1713) (@fukusuket)

## 3.6.0 [2025/09/25] - 寝覚月リリース

**改善:**

- 相関ルールにより複数の可能性を持つイベントIDおよびレコードIDは、パースしやすくするため、`-`ではなく空文字列として出力されるようになった。 (#1694) (@fukusuket)
- `csv-timeline`および`json-timeline`コマンドの`Results Summary`に表示される最初のタイムスタンプと最後のタイムスタンプの後に、最初と最後の検出のタイムスタンプも出力するようにした。 (#1688) (@fukusuket)
- SOF-ELK（Elastic Stack）へのHayabusa JSONL結果のインポート方法に関するガイドが更新された。 (#1091) (@yamatosecurity)
- ルールの変更日時が定義されていない場合、SIEMへのインポートを容易にするため、`-`の代わりに空文字列を出力する。 (#1702) (@yamatosecurity)
- ルールメタデータ内の`RuleModifiedDate`等の空フィールドは、パースを容易にしファイルサイズを削減するため、JSONに出力されない。 (#1702) (@fukusuket)

**バグ修正:**

- `-T, --visualize-timeline`は、`-s, --sort`が指定されていない場合、正しくない結果を出力するため、`-T`を使用する際には`-s`の指定を必須とした。 (#1690) (@yamatosecurity)
- レコード自体のタイムスタンプではなく、レコードヘッダー内のタイムスタンプでフィルタリングしていたため、タイムレンジオプション（--timeline-start / --timeline-end）で指定した範囲外のレコードが表示されていた。 (#1689) (@fukusuket)
- GeoIP検索が`json-timeline`で機能していなかった。 (#1693) (@fukusuket)
- `search`コマンドにおける省略形処理は一貫していなかった。(#1697) (@fukusuket)

## 3.5.0 [2025/08/16] - お盆リリース

**改善*:**

- `base64`フィールド修飾子に対応した。 (#1677) (@fukusuket)

## 3.4.0 [2025/08/01] - Black Hat Arsenal USA 2025 Release

**改善:**

- `search`コマンドでフィールド名が省略されるようになった。`-b, --disable-abbreviations`で無効にできる。 (#1627) (@hitenkoku)
- 32ビット版のHayabusaが64ビットOSでも動作するようになった。 (#1665) (@akkuman)
- Filebeatが最後のイベントを見逃さないように、JSON/Lファイルの最終行の後にリターン文字を置くようにした。 (#1666) (@fukusuket)

**バグ修正:**

- レベルは、`--disable-abbreviations`オプションが有効であっても省略されていた。(#1672) (@fukusuket)

## 3.3.0 [2025/03/22] - AUSCERT/SINCON Release

**改善:**

- ファイルサイズを1024ベースで出力するようにした。（例:`KiB`, `MiB`, `GiB`等） (#1648) (@fukusuket)
- `computer-metrics`コマンドのアップタイムの計算を改善した。 (#1656) (@fukusuket)

**バグ修正:**

- Windowsのライブレスポンスパッケージでは、`computer-metrics`コマンドが正しく動作しなかった。 (#1654) (@fukusuket)
- `ruletype`フィールドは任意フィールドに戻された。 (#1660) (@fukusuket)

## 3.2.0 [2025/04/02] - Vegemite Release

**改善:**

- `computer-metrics`コマンドにアップタイムとタイムゾーン情報を追加した。 (#1638) (@fukusuket)
- 無効なルールのチェックとロギングを改善した。 (#1601) (@fukusuket)
- デフォルトの出力に最初と最後のタイムスタンプを追加した。 (#1616) (@fukusuket)

**バグ修正:**

- `.evtx`ファイルが開けない場合、スキャンは失敗していた。 (#1634) (@fukusuket)
- 経過時間と保存されたファイル情報がHTMLレポートに出力されていなかった。 (#1643) (@fukusuket)

## 3.1.1 [2025/03/12] - Laksa Release

**改善:**

- Rustエディションを2024に更新した。(@fukusuket)
- `computer-metrics`コマンドにOS情報を追加した。 (#1629) (@fukusuket)

**バグ修正:**

- `expand`ルールの数がターミナルに正しく表示されていなかった。 (#1598) (@fukusuket)
- `status`フィールドが定義されていないルールは、スキャンウィザードで `status: test, stable` などを指定しても読み込まれた。(#1602) (@fukusuket)
- `expand`ルールが設定なしでロードされていた。 (#1606) (@fukusuket)
- `extract-base64`コマンドでダブルBase64エンコーディングの検出が正しく動作していなかった。 (#1607) (@fukusuket)
- エラーメッセージの後、端末の文字が赤くなることがあった。 (#1610) (@fukusuket)
- いくつかのコマンドで`-d`オプションが使用され、`-o`オプションが使用されなかった場合、プログレスバーが表示されなかった。 (#1617) (@fukusuket)
- `pivot-keywords-list`コマンドが壊れていた。(#1619) (@fukusuket)
- `details`が未定義の場合、フィールドデータマッピングが正常に機能しなかった。 (#1614) (@fukusuket)
- `details`フィールドが設定されていない場合、`Details`列と`ExtraFieldInfo`列の両方に重複したデータが出力されていた。現在は`Details`列だけに出力される。 (#1623) (@fukusuket)

## 3.1.0 [2025/02/22] - Ninja Day Release

**新機能:**

- `eid-metrics`と`logon-summary`コマンドに`-X, --remove-duplicate-detections`オプションを追加した。 (#1552) (@fukusuket)
- 新しい「緊急アラート 」と重要なシステムに基づく重大度レベルの調整。`config/critical_systems.txt`に重要なシステム（例: ドメインコントローラ、ファイルサーバ等々）のコンピュータ名のリストを追加すると、`low`以上のすべてのアラートが1つ高く調整される。つまり、`low`は`medium`に、`medium`は`high`に、`critical`アラートは新しい`emergency`アラートになる。 (#1551) (@fukusuket)
- `./config/critical_systems.txt`ファイルに追加するドメインコントローラーとファイルサーバーを自動的に見つける`config-critical-systems`コマンドを追加した。 (#1570) (@fukusuket)
- `csv-timeline`、`search`、`log-metrics`コマンドに、フィールド情報をタブで区切る`-S, --tab-separator`オプションを追加した。 (#1587) (@fukusuket)

**改善:**

- `search`コマンドに`--timeline-start/--timeline-end`オプションを追加した。 (#1543) (@fukuseket)
- チャンネルフィルタリングで `logon-summary` コマンドの速度を大幅に改善した。 (#1544) (@fukusuket)
- `extract-base64`コマンドが`PowerShell Classic EID 400`イベントも対象するようになった。 (#1549) (@fukusuket)
- `extract-base64`コマンドがPowerShell Coreログにも対応した。 (#1558) (@fukusuket)
- `extract-base64`コマンドが`System 7045` (サービス作成)イベントにも対応した。 (#1583) (@fukusuket)
- `search`コマンドは、デフォルトでは結果をソートしないので、メモリ使用量が大幅に減り、より高速になった。新しい`-s, --sort`オプションを使えば、以前と同じように結果をソートできる。(#1475) (@hach1yon)

**バグ修正:**

- `logon-summary`と`pivot-keywords-list`コマンドが不要なファイルを出力していた。 (#1553) (@fukusuket)
-  JSON出力では、いくつかのルールでMITRE戦術の一貫性がなかった。 (#1573) (@fukusuket)
- バージョンv3.0.x`ではルール作者情報がHTMLレポートに出力されていなかった。 (#1571) (@fukusuket)
- ライブ調査用のエンコードされたルールが使用されている場合、相関ルールのルールファイル名がJSONタイムラインに出力されていなかった。 (#1572) (@fukusuket)
- `level-tuning`コマンドが正しく動いていなかった。 (#1584) (@fukusuket)

**その他:**

- `-s, --sort-events`オプションが`-s, --sort`に名前変更された。 (@YamatoSecurity)
- `minimal`以外のプロファイルに`RuleID`を追加した。 (@YamatoSecurity)
- コードのリファクタリング: StoredStaticの不要な初期化コードを減らすためにデフォルトのtraitを使用することにした。 (#1588) (@fukusuket)

## 3.0.1 [2024/12/29] - 3rd Year Anniversary Release

**バグ修正:**

- Hayabusaはバックエンドで`expand`ルールのパースチェックに失敗していた。 (#1537) (@fukusuket)

## 3.0.0 [2024/12/25] - 3rd Year Anniversary Release

**新機能:**

- Base64文字列を抽出して、デコードする`extract-base64`コマンドを追加した。(#1512) (@fukusuket)
- `expand`修飾子が入っているルールで使用されるプレースホルダー名を出力する`expand-list`コマンドを追加した。(#1513) (@fukuseket)
- `expand`フィールド修飾子に対応した。 (#1434) (@fukusuket)
- Temporal Proximity（`temporal`）の相関ルールに対応した。 (#1446) (@fukusuket)
- Temporal Ordered Proximity (`temporal_ordered`) の相関ルールに対応した。 (#1447) (@fukusuket)

**改善:**

- `log-metrics`コマンドにファイルサイズを追加した。 (#1528) (@fukusuket)

**バグ修正:**

- レコードIDが出力されるとき、`csv-timeline`によるソートが完璧に行われなかった。 (#1519) (@fukusuket)
- `J, --JSON-input`は、`.json`ファイルしか対応していなかったので、`.jsonl`ファイルにも対応した。 (#1530) (@fukusuket)

## 2.19.0 [2024/11/26] - "Every Day Is A Good Day" Release

**新機能:**

- `gt`、`gte`、`lt`、`lte`のフィールド修飾子に対応した。(#1433) (@fukusuket)
- 新しい`log-metrics`コマンドで`.evtx`ファイルの情報を取得できるようになった。(コンピュータ名、イベント数、最初のタイムスタンプ、最後のタイムスタンプ、チャネル、プロバイダ) (#1474) (@fukusuket)
- 以下のコマンドに`Channel`と`Provider`の略称を無効にする`-b, --disable-abbreviations`オプションを追加した。元の値を確認したい時に便利。 (#1485) (@fukusuket)
  * `csv-timeline`
  * `json-timeline`
  * `eid-metrics`
  * `log-metrics`
  * `search`
- `utf16/utf16be/utf16le/wide`フィールド修飾子が`base64offset|contains`フィールド修飾子と一緒に使えるようになった。 (#1432) (@fukusuket)
  * `utf16|base64offset|contains`
  * `utf16be|base64offset|contains`
  * `utf16le|base64offset|contains`
  * `wide|base64offset|contains`

**改善:**

- `yaml-rust`クレートを`yaml-rust2`に更新した。(#461) (@yamatosecurity)
- `windash`文字が、`rules/config/windash_characters.txt`から動的に読み込まれるようになった。(#1440) (@fukusuket)
- `logon-summary`コマンドがRDPイベントからのログオン情報を表示するようになった。注意: ファイルに保存する場合、Hayabusaはより詳細な情報を出力する。(#1468) (@fukusuket)
- 見やすくなるように色を更新した。 (#1480) (@yamatosecurity)
- 実行開始と終了のメッセージを出力するようにした。 (#1492) (@fukusuket)
- 出力に新しい配色を追加した。 (#1491) (@fukusuket)
- ファイルサイズがプログレスバーの下のファイル名の横に表示されるようになった。 (#1471) (@fukusuket)

**バグ修正:**

- logon-summary`コマンドが破損したログでクラッシュすることがあった。(#1477) (@fukusuket)
- `csv-timeline`と`json-timeline`コマンドで、結果をターミナルに出力すると、プログレスバーの後にいくつかの結果が表示されていた。(#1459) (@fukusuket)
- 集計ルールのアラートの詳細フィールド値の結果がソートされていないため、`csv-timeline`と`json-timeline`は、毎回完全に正確な結果を出力しなかった。 (#1466) (@fukusuket)
- `hayabusa-evtx`クレートをバージョン`0.8.12`に更新した。(@yamatosecurity)
  - JSONフィールドの出力順序が元のXMLに従って保持されるようになった。(omerbenamram/evtx #241)
  - 属性と同じ名前を持つ複数のサブノードは上書きされ、最後の1つだけが出力されていた。(omerbenamram/evtx #245)
- `logon-summary`と`eid-metrics`が複数のプログレスバーを出力することがあった。 #1479 (@fukusuket)
- ターミナルに出力し、イベントをソートしない場合、プログレスバーは不要なため削除された。 #1508 (@fukusuket)

**その他:**

- `timeline-offset`オプションは、`--time-offset`に名前変更された。 (#1490) (@yamatosecurity)

## 2.18.0 [2024/10/23] - SecTor Release

**新機能:**

- `fieldref`修飾子(`equalsfield`修飾子のエリアス)に対応した。(#1409) (@hitenkoku)
- `fieldref|startswith`と`fieldref|contains`修飾子に対応した。 (#1439) (@fukusuket)
- `fieldref|endswith`修飾子は、`endswithfield`をリプレースするためのエイリアスとして作成された。(#1437) (@fukusuket)
- XORエンコードされたルールをサポートし、端末に置かれるファイルを最小限に抑えるとともに、ルールに過検知するアンチウイルス製品を回避する。(#1419) (@fukusuket)
  - リリースページで、この機能を設定済みのパッケージを含める予定。手動で設定したい場合は、[encoded_rules.yml](https://github.com/Yamato-Security/hayabusa-encoded-rules/raw/refs/heads/main/encoded_rules.yml)をダウンロードして、Hayabusaのルートフォルダに置いてください。このファイルは、hayabusa-rulesリポジトリ内のルールから作成されており、ルールが更新されるたびに自動的にアップデートされる。configディレクトリ以外のrulesフォルダ内のファイルは、まだ単一ファイルに含まれていないので削除してください。
  - 注意: -Hオプションで生成されるレポートは、ルールへのリンクを作成せず、ルール名だけが出力される。
- `rules/config`の設定ファイルが単一のファイル[rules_config_files.txt](https://github.com/Yamato-Security/hayabusa-encoded-rules/raw/refs/heads/main/rules_config_files.txt)からロードされるようになり、ライブ調査のためにターゲットシステムに保存する必要があるファイル数が減った。(#1420) (@fukusuket)

**バグ修正:**

- `search`コマンドの`-o`オプションを使用した際に不要な改行が出力されていた。(#1425) (@fukusuket)
- Sigma相関ルールの`group-by`フィールドは、必須だったが任意に変えた。(#1442) (@fukusuket)
- Hayabusaは、相関ルールで参照されているルールが見つからない場合、エラーメッセージを表示するようにした。 (#1444) (@fukusuket)
- `all-field-info`プロファイルを使用した場合、フィールド情報が出力されなかった。 (#1450) (@fukusuket)

**その他:**

- ライセンスをGPL-3.0からAGPL-3.0に変えた。(@yamatosecurity)

## 2.17.0 [2024/08/23] "HITCON Community Release"

**新機能:**

- Sigma V2の`|re:`のサブ修飾子に対応した。 submodifers. (#1399) (@fukusuket)
  - 参考: https://github.com/SigmaHQ/sigma-specification/blob/main/appendix/sigma-modifiers-appendix.md
    * `|re|i:`: (insensitive) 大文字小文字を区別しないマッチングを無効にする。
    * `|re|m:`: (multi-line) 複数行にまたがってマッチする。`^` /`$` は行頭/行末にマッチする。
    * `|re|s:`: (single-line) ドット文字 (`.`) は改行文字を含むすべての文字にマッチする。
- Sigma V2の`|exists:`修飾子に対応した。 (#1400) (@hitenkoku)
- Sigma V2の`|cased:`修飾子に対応した。 (#1401) (@hitenkoku)

**改善:**

- `cidr-utils`クレートを新バージョン0.6.xに対応した。 (#1366) (@hitenkoku)
- Sigma相関ルールの`name`ルックアップに対応した。 (#1363) (@fukusuket)
- デフォルトで低メモリモードを有効にした。`-s, --low-memory-mode`は、`-s, --sort-events` - 出力/保存する前に結果をソートする。(注意: より多くのメモリを消費する。）(#1361) (@hitenkoku)
  - 注意: `-R, --remove-duplicate-data`または`-X, --remove-duplicate-detections`を使用するには、ソートを有効にする必要がある。
- Sigma相関ルールが参照しているルールは、デフォルトで結果を出力しないようにした。ルールに`generate: true`を指定すると、出力される。 (#1367) (@fukusuket)
- `Data`フィールドは、すべて`Data`フィールドとして、またはJSONの配列としてではなく、インデックス化された文字列として表示されるようになった。(#1371) (@fukusuket)
  - 前: `"Data": ["17514", "Multiprocessor Free", "Service Pack 1"]`
  - 後: `"Data[3]": "17514", "Data[4]": "Multiprocessor Free", "Data[5]": "Service Pack 1"`
- リリースパッケージのファイル数を減らすために、`config`フォルダ内の設定ファイルもバイナリに埋め込まれるようにした。 (#1370) (@hitenkoku)
  - 注意: `set-default-profile`コマンドは、`config/default_profile.yaml`に依存しているので、`config`ディレクトリファイルがないと実行できない。
- 集計ルールのアラートに、複数の結果がある場合でも`Channel`と`EventID`の情報が表示されるようにした。 (#1342) (@fukusuket)
- JSONタイムラインで`Details`フィールドに情報がない場合、JSONがパースしやすくなるように、デフォルトで出力される`"-"`を`{}`に変更した。(#1386) (@hitenkoku)
- シグネチャーバイパスを防ぐため、`-` (エンダッシュ)、`-` (エムダッシュ)、`―` (水平バー) 文字を `windash` 修飾子でサポートするようにした。(#1392) (@hitenkoku)
- MITRE ATT&CKタグをSigmaバージョン2の形式に対応させた。(例: `defense_evasion` => `defense-evasion`) (@fukusuket)
- `evtx`クレートを最新のものに更新し、機能改善とバグ修正を行った。

**バグ修正:**
- Sigmaの相関ルールのカウントが`Events with hits`に表示されていなかった。(#1373) (@fukusuket)
- 相関ルールのカウントが`Events with hits`に表示されていなかった。(#1374) (@fukusuket)
- 集計ルールのカウントが`Events with hits`に表示されていなかった。(#1375) (@fukusuket)
- まれに、ルール作成者の一覧が表示されないことがあった。 (#1383) (@fukusuket)

## 2.16.0 [2024/06/11]

**新機能:**

- デフォルトでは、`.evtx`ファイルに適用可能なルールのみ有効になる。これは、`.evtx`ファイルと`.yml`ルールの`Channel`フィールドに基づく。例えば、`Security.evtx`がスキャンされている場合、`Channel: Security`が定義されているルールのみがこのファイルに対して使用される。ベンチマークでは、単一の`evtx`ファイルをスキャンする場合、パフォーマンスが約20％向上される。1つの`.evtx`ファイルで複数のチャネルが使用されている場合や、チャネルが定義されていないルールを使用して、チャネルに関係なくすべての`.evtx`ファイルをスキャンしたい場合は、`csv-timeline` と `json-timeline` の `-A、--enable-all-rules` オプションでこのフィルタリングをオフにすることができる。（#1317）(@fukusuket)
  - 現在のところ、`Channel`が定義されておらず、すべての`.evtx`ファイルをスキャンすることを意図している検知ルールは以下の2つだけ:
    - [Possible Hidden Shellcode](https://github.com/Yamato-Security/hayabusa-rules/blob/main/hayabusa/builtin/UnkwnChannEID_Med_PossibleHiddenShellcode.yml)
    - [Mimikatz Use](https://github.com/SigmaHQ/sigma/blob/master/rules/windows/builtin/win_alert_mimikatz_keywords.yml)
- デフォルトでは、適用可能なルールを持つ`.evtx`ファイルのみ読み込む。たとえば、さまざまなイベントログのディレクトリをスキャンしている場合でも、 `Channel: Security` を探すルールのみを有効にした場合、Hayabusaは`Security`以外のすべてのイベントログを無視します。ベンチマークでは、通常のスキャンで約10％、単一のルールでスキャンする場合は最大60％以上のパフォーマンス向上が得られる。チャネルに関係なくすべての`.evtx`ファイルを読み込みたい場合は、`csv-timeline` と `json-timeline` の `-a、--scan-all-evtx-files` オプションでこのフィルタリングをオフにすることができる。(#1318) (@fukusuket)
- 注意: チャンネルフィルタリングは .evtx ファイルにのみ適用され、`-J, --json-input`オプションを使用してイベントログをJSONファイルから読み込む際に`-A`または`-a`を指定するとエラーが発生する。(#1345) (@fukusuket)
- Sigma相関ルールのEvent Countに対応した。 (#1337) (@fukusuket)
- Sigma相関ルールのValue Countに対応した。 (#1338) (@fukusuket)

**改善:**

- `-d, --directory`オプションで複数のフォルダを指定できるようにした。 (#1335) (@hitenkoku)
- REST APIからエクスポートされたSplunkログを分析できるようになった。 (#1083) (@hitenkoku)
- `count`で複数のグループを指定できるようにした。例: `count() by IpAddress,SubStatus,LogonType >= 2`。また、出力される結果を更新した。例: `[condition] count(TargetUserName) by IpAddress > 3 in timeframe [result] count: 4 TargetUserName:tanaka/Administrator/adsyncadmin/suzuki IpAddress:- timeframe:5m` -> `Count: 4 ¦ TargetUserName: tanaka/Administrator/adsyncadmin/suzuki ¦ IpAddress: -` (#1339) (@fukusuket)
- フィールドデータマッピングファイル(`rules/config/data_mapping/*.yaml`)で任意の`Provider_Name`フィールドを指定できるようにし、`Data[x]`表記に対応した。(#1350) (@fukusuket)
- カウントルールのJSON出力で、フィールド情報が分離されるようになった。 (#1342) (@fukusuket)
  - 以前: `"Details": "[condition] count() by IpAddress >= 5 in timeframe [result] count:3558 IpAddress:192.168.198.149 timeframe:5m"`
  - 現在: `"Details": { "Count": 3558, "IpAddress": "192.168.198.149" }`

## 2.15.0 [2024/04/20] "Sonic Release"

**改善:**

- Sigmaルールの `windash`フィールド修飾子 (例: `|contains|windash:`と`|contains|all|windash:`)に対応した。 (#1319) (@hitenkoku)
  - https://sigmahq.io/docs/basics/modifiers.html#windash
  - 注意: 現在、バックエンドでは、以前のバージョンのHayabusaと互換性があるようにルール内の`windash`の使用を変換しているが、5月末ごろには、`windash`の使用をそのままにする予定なので、それまでにこのバージョンにアップデートしてください。

**バグ修正:**

- バージョン2.14.0では、`-T`の検知頻度タイムライン出力は使用できなかった。 (#1322) (@fukusuket)
- `windash` でワイルドカードが利用できない問題を修正した。 (#1327) (@hitenkoku)

## 2.14.0 [2024/03/30] "BSides Tokyo Release"

**新機能:**

- 指定した`status`のルールのみを利用する`--include-status`オプションを追加した。 (#1193) (@hitenkoku)
- メモリ使用量を最大95%削減する`-s, --low-memory-mode`(低メモリモード)オプションを追加した。ただし、そのためには結果をソートしたり、`-R, --remove-duplicate-data`または`-X, --remove-duplicate-detections`を併用したりすることはできない。(#1254) (@hach1yon @hitenkoku)

**改善:**

- 未使用のクレートを削除した。(@YamatoSecurity)
- SplunkからエクスポートしたJSONファイルの入力に対応した。 (#1083) (@hitenkoku)
- パフォーマンスの改善 (#1277, #1278) (@fukusuket)
- `csv-timeline`コマンドの結果と同様になるようにするために、`search`コマンドの結果の表示順番を変更した。 (#1297) (@hitenkoku)
- イースターエッグに最強のキャラクターを追加した。 (#1304) (@hitenkoku)
- `computer-metrics`コマンドのhelpオプションの表示をほかのコマンドの形式に合わせた。 (#1314) (@hitenkoku)

**バグ修正:**

- `search` コマンドのJSON出力で`AllFieldInfo`フィールドの情報が出力されなくなっていたのを修正した。 (#1251) (@hitenkoku)
- ウィザードのオプション選択の時間が処理時間の中に含まれていたため除外した。 (#1291) (@hitenkoku)
- `-h, --help`オプションが重複して複数回表示されていた問題を修正した。 (#1309) (@hitenkoku)

## 2.13.0 [2024/02/11] "Year Of The Dragon Release"

**改善:**

- `search` コマンドのフィルタオプションを完全一致にするようにした。加えてフィルタオプションはワイルドカード対応をするようにした。 (#1240) (@hitenkoku)
- `update-rules`コマンドを実行したときに、検知ルールが変更された場合にルール名を出力するようにした。以前は`modified`フィールドを更新したルールだけが表示されていた。(#1243) (@hitenkoku)
- `json-timeline`コマンドの標準出力でJSONフォーマットを出力するように修正した。 (#1197) (@hitenkoku)
- JSON入力でデータが配列内にある場合に解析できるようにした。 (#1248) (@hitenkoku)
- 古いターミナルでも正しく表示されるように、また読みやすくするために、`‖`区切り文字を`·`区切り文字に変更した。(#1258) (@YamatoSecurity)
- General Optionsに`-h, --help`オプションを追加した。 (#1255) (@hitenkoku)
- `json-timeline`コマンドの`Details`の出力で、要素がアルファベット順に並んでいたのをルールに記載されているオリジナルの順番に変更した。 (#1264) (@hitenkoku)
- ルールをロードする必要のないコマンドを実行した場合、検出ルールのロードをスキップするようにした。 (#1263) (@hitenkoku)
- `csv-timeline`コマンドの標準出力のカラー出力ルールを変更した。 (#1271) (@hitenkoku)
- リファクタリングとパフォーマンスの改善。(#1268, #1260) (@hach1yon)

**バグ修正:**

- `search`コマンドの出力に入っている不要な改行文字を削除した。 (#1253) (@hitenkoku)
- `no-color`オプション使用時のプログレスバーとウィザードのカラー出力を修正した。 (#1256) (@hitenkoku)
- ローカルのタイムゾーンを特定できない場合にパニックが発生する問題を修正した。`chrono`クレートのバージョン0.4.32で修正された。(#1273)

## 2.12.0 [2023/12/24] "SECCON Christmas Release"

**改善:**

- JSON出力において、MitreTactics、MitreTags, OtherTagsの出力を要素ごとに文字列で出力させるように修正した。 (#1230) (@hitenkoku)
- 検知した端末に対してMITRE ATT&CKの戦術をHTMLレポートに出力できるようにした。この機能を利用するためには利用したプロファイルに`%MitreTactics%`が存在する必要がある。 (#1226) (@hitenkoku)
- `csv-timeline`または`json-timeline`コマンドが利用されたときにissueやpull-requestの連絡先についてのメッセージを追加した。 (#1236) (@hitenkoku)

**バグ修正:**

- JSON出力において、同じ名前の複数のフィールド名が配列として出力されないため、`jq`でパースすると1つの結果しか返されなかった。同じフィールド名を持つ複数のフィールドデータを配列内に出力することで修正した。 (#1202) (@hitenkoku)
- `csv-timeline`、`json-timeline`、`eid-metrics`、`logon-summary`、`pivot-keywords-list`、`search`コマンドで調査対象ファイルの指定オプション(`-l`、 `-f`、 `-d`)が存在しないときに処理が実行されないように修正した。 (#1235) (@hitenkoku)

## 2.11.0 [2023/12/03] "Nasi Lemak Release"

**新機能:**

- PowerShell classicログのフィールドを抽出するようにした。(`--no-pwsh-field-extraction`で無効化できる) (#1220) (@fukusuket)

**改善:**

- スキャンウィザードにルール数を追加した. (#1206) (@hitenkoku)

## 2.10.1 [2023/11/12] "Kamemushi Release"

**改善:**

- スキャンウィザードに質問を追加した。 (#1207) (@hitenkoku)

**バグ修正:**

- バージョン`2.10.0`の`update-rules`コマンドでは、新しいルールがダウンロードされても、`You currently have the latest rules`というメッセージを出力していた。 (#1209) (@fukusuket)
- 正規表現が正しく処理されない場合があった。 (#1212) (@fukusuket)
- JSON入力等に`Data`フィールドが存在しない場合、パニックが発生していた。(#1215) (@fukusuket)

## 2.10.0 [2023/10/31] "Halloween Release"

**改善:**

- 初心者のユーザのために有効にしたいルールを選択するようにスキャンウィザードを追加した。`-w, --no-wizard`オプションを追加すると、従来の形式でHayabusaを実行できる。(すべてのイベントとアラートをスキャンし、オプションを手動でカスタマイズする） (#1188) (@hitenkoku)
- `pivot-keywords-list`コマンドに`--include-tag`オプションを追加し、指定した`tags`フィールドを持つルールのみをロードするようにした。(#1195) (@hitenkoku)
- `pivot-keywords-list`コマンドに`--exclude-tag`オプションを追加し、指定した`tags`フィールドを持つルールをロードしないようにした。(#1195) (@hitenkoku)

**バグ修正:**

- まれにJSONフィールドが正しくパースされない状態を修正した。(#1145) (@hitenkoku)
- JSON出力で、`AllFieldInfo`は改行文字とタブ文字を除去していたが、出力するように修正した。 (#1189) (@hitenkoku)
- 標準出力のいくつかのフィールドでスペースが削除されて見づらくなっていたのを修正した。 (#1192) (@hitenkoku)

## 2.9.0 [2023/09/22] "Autumn Rain Release"

**改善:**

- ディレクトリパスの指定にバックスラッシュを使用すべきではないことを示すエラーメッセージを追加した。 (#1166) (@hitenkoku, 提案者: @joswr1ght)
- 一度に読み込むレコード数の最適化。(#1175) (@yamatosecurity)
- プログレスバー内にあるバックスラッシュの表示をスラッシュに変更した。 (#1172) (@hitenkoku)
- JSON形式で出力する際に、`count`ルールの`Details`フィールドを文字列にし、パースしやすくした。(#1179) (@hitenkoku)
- デフォルトのスレッド数をCPU数から、プログラムが使用すべきデフォルトの並列度の推定値(`std::thread::available_parallelism`)に変更した。(#1182) (@hitenkoku)

**バグ修正:**

- まれにJSONフィールドが正しくパースされない状態を修正した。(#1145) (@hitenkoku)

**その他:**

- CIを通すために`time`クレートを利用している更新されていない`hhmmss`クレートを除外した。 (#1181) (@hitenkoku)

## 2.8.0 [2023/09/01] "Double X Release"

**新機能:**

- フィールドマッピング設定に16進数値を10進数に変換する`HexToDecimal`機能に対応した。 (元の16進数のプロセスIDを変換するのに便利。) (#1133) (@fukusuket)
- `csv-timeline`と`json-timeline`に`-x, --recover-records`オプションを追加し、evtxのスラックスペースのファイルカービングによってevtxレコードを復元できるようにした。(#952) (@hitenkoku) (Evtxカービング機能は@forensicmattに実装された。)
- `csv-timeline`と`json-timeline`に`-X, --remove-duplicate-detections`オプションを追加した。(`-x`を使用する場合、重複データのあるバックアップログを含める場合などに便利。) (#1157) (@fukusuket)
- `csv-timeline`、`json-timeline`、`logon-summary`、`eid-metrics`、`pivot-keywords-list`、`search`コマンドに、直近のイベントだけをスキャンするための`--timeline-offset`オプションを追加した。 (#1159) (@hitenkoku)
- `search`コマンドに`-a, --and-logic`オプションを追加し、複数のキーワードをAND条件で検索できるようにした。 (#1162) (@hitenkoku)

**その他:**

- 出力プロファイルに、回復されたかどうかを示す `%RecoveredRecord%` フィールドを追加した。 (#1170) (@hitenkoku)

## 2.7.0 [2023/08/03] "SANS DFIR Summit Release"

**新機能:**

- `./rules/config/data_mapping`にある`.yaml`設定ファイルに基づいて、特定のコード番号が人間が読めるメッセージにマッピングされるようになった。(例:`%%2307`は、`ACCOUNT LOCKOUT`に変換される)。この動作は`-F, --no-field-data-mapping`オプションで無効にできる。(#177) (@fukusuket)
- `csv-timeline`コマンドに`-R, --remove-duplicate-data`オプションを追加し、`%Details%`、`%AllFieldInfo%`、`%ExtraFieldInfo%`列の重複フィールドデータを`DUP`という文字列に変換し、ファイルサイズの削減を行う。(#1056) (@hitenkoku)
- `csv-timeline`と`json-timeline`コマンドに`-P, --proven-rules`オプションを追加した。有効にすると、検知が証明されたルールしかロードされない。ロードされるルールは、`./rules/config/proven_rules.txt`の設定ファイルにルールIDで定義されている。 (#1115) (@hitenkoku)
- `csv-timeline`と`json-timeline`コマンドに`--include-tag`オプションを追加し、指定した`tags`フィールドを持つルールのみをロードするようにした。(#1108) (@hitenkoku)
- `csv-timeline`と`json-timeline`コマンドに`--exclude-tag`オプションを追加し、指定した`tags`フィールドを持つルールをロードしないようにした。(#1118) (@hitenkoku)
- `csv-timeline`と`json-timeline`コマンドに`--include-category`と`--exclude-category`オプションを追加した。`include-category`は、指定された`category`フィールドのルールのみをロードする。`--exclude-category`は、指定された`category`フィールドを持つルールをロードしない。 (#1119) (@hitenkoku)
- コンピュータ名に基づくイベント数をリストアップする`computer-metrics`コマンドを追加した。(#1116) (@hitenkoku)
- `csv-timeline`、`json-timeline`、`metrics`、`logon-summary`、`pivot-keywords-list`コマンドに`--include-computer`と`--exclude-computer`オプションを追加した。`include-computer`は、指定された`computer`の検知のみを出力する。`--exclude-computer`は、指定された`computer`の検知を除外する。 (#1117) (@hitenkoku)
- `csv-timeline`、`json-timeline`、`pivot-keywords-list`コマンドに`--include-eid`と`--exclude-eid`オプションを追加した。`include-eid`は、指定された`EventID`のみを検知対象とする。`--exclude-eid`は、指定された`EventID`を検知対象から除外する。 (#1130) (@hitenkoku)
- `json-timeline`コマンドに`-R, --remove-duplicate-data`オプションを追加し、`%Details%`、`%AllFieldInfo%`、`%ExtraFieldInfo%`フィールドの重複フィールドデータを`DUP`という文字列に変換し、ファイルサイズの削減を行う。(#1134) (@hitenkoku)

**改善:**

- 新しいログ形式の`.evtx`を使用するWindows Vistaがリリースされた2007年1月31日以前のタイムスタンプを持つ破損されたイベントレコードを無視するようにした。(#1102) (@fukusuket)
- `metrics`コマンドで`--output`オプションを指定した時に標準出力に結果を表示しないように変更した。 (#1099) (@hitenkoku)
- `csv-timeline` コマンドと `json-timeline` コマンドに `--tags` オプションを追加し、指定した `tags` フィールドを持つルールのみでスキャンできるようにした。(#1108) (@hitenkoku)
- `pivot-keywords-list`コマンドに対して、出力ファイルを上書きするための`-C, --clobber`オプションを追加した。 (#1125) (@hitenkoku)
- `metrics`コマンドを`eid-metrics`に変更した。 (#1128) (@hitenkoku)
- 端末の調整に余裕を持たせるため、プログレスバーの幅を減らした。 (#1135) (@hitenkoku)
- `search`コマンドで出力時間フォーマットのオプションをサポートした。(`--European-time`, `--ISO-8601`, `--RFC-2822`, `--RFC-3339`, `--US-time`, `--US-military-time`, `-U, --UTC`) (#1040) (@hitenkoku)
- プログレスバーのETA時間が正確でなかったため、経過時間に置き換えた。 (#1143) (@YamatoSecurity)
- `logon-summary`コマンドで`--timeline-start`と`--timeline-end`オプションを追加した。 (#1152) (@hitenkoku)

**バグ修正:**

- `metrics`と`logon-summary`コマンドのレコード数の表示が`csv-timeline`のコマンドでのレコード数の表示と異なっている状態を修正した。 (#1105) (@hitenkoku)
- パスの代わりにルールIDでルール数を数えるように変更した。 (#1113) (@hitenkoku)
- JSON出力で`CommandLine`フィールド内で誤ったフィールドの分割が行われてしまう問題を修正した。 (#1145) (@hitenkoku)
- `json-timeline`コマンドで`--timeline-start`と`--timeline-end`オプションが動作しなかったのを修正した。 (#1148) (@hitenkoku)
- `pivot-keywords-list`コマンドで`--timeline-start`と`--timeline-end`オプションが動作しなかったのを修正した。 (#1150) (@hitenkoku)

**その他:**

- ルールのIDベースでユニークな検出数をカウントするように修正した。 (#1111) (@hitenkoku)
- `--live_analysis`オプションを`--live-analysis`に変更した。 (#1139) (@hitenkoku)
- `metrics`コマンドを`eid-metrics`に変更した。 (#1128) (@hitenkoku)

## 2.6.0 [2023/06/16] "Ajisai Release"

**新機能:**

- Sigmaルールの`'|all':`キーワードに対応した。 (#1038) (@kazuminn)

**改善:**

- プロファイルに`%ExtraFieldInfo%`エイリアスを追加した。デフォルトの`standard`出力プロファイルに含まれるようになった。(#900) (@hitenkoku)
- 互換性のない引数に対するエラーメッセージを追加した。 (#1054) (@YamatoSecurity)
- 標準出力とHTML出力にプロファイル名を出力する機能を追加した。 (#1055) (@hitenkoku)
- HTML出力のルールアラートにルール作者名を表示するように修正した。 (#1065) (@hitenkoku)
- 端末サイズが小さくてもテーブルが壊れないように、テーブル幅を短くした。 (#1071) (@hitenkoku)
- `csv-timeline`、`json-timeline`、`metrics`、`logon-summary`、`search`コマンドに対して、出力ファイルを上書きするための`-C, --clobber`オプションを追加した。 (#1063) (@YamatoSecurity, @hitenkoku)
- HTML内にCSSと画像を組み込んだ。 (#1078) (@hitenkoku, 提案者: @joswr1ght)
- 出力時の速度向上。 (#1088) (@hitenkoku, @fukusuket)
- `metrics`コマンドは、テーブルが正しくレンダリングされるように、ワードラップを行うようになった。 (#1067) (@garigariganzy)
- `search`コマンドでJSON/JSONLの出力できるようにした。 (#1041) (@hitenkoku)

**バグ修正:**

- `json-timeline`コマンドを利用した出力で、`MitreTactics`、`MitreTags`、`OtherTags`フィールドが出力されていない問題を修正した。 (#1062) (@hitenkoku)
- `no-summary`オプションを使用した時にイベント頻度のタイムラインが出力されない問題を修正した。 (#1072) (@hitenkoku)
- `json-timline`コマンドの出力に制御文字が含まれる問題を修正した。 (#1068) (@hitenkoku)
- `metrics`コマンドでは、チャンネル名が小文字の場合、省略されなかった。 (#1066) (@garigariganzy)
- JSON出力内でいくつかのフィールドがずれてしまっていた問題を修正した。 (#1086) (@hitenkoku)

## 2.5.1 [2023/05/14] "Mothers Day Release"

**改善:**

- 新たに変換されたルールを使用する際のメモリ使用量を半分に削減した。(#1047) (@fukusuket)

**バグ修正:**

- `AccessMask`等のフィールド内の情報が空白で区切られていなかった状態を修正した。 (#1035) (@hitenkoku)
- JSON形式に出力時に複数の空白が一つの空白に変換されていた。 (#1048) (@hitenkoku)
- `pivot-keywords-list`コマンドで`--no-color`を使用した場合でも、結果がカラーで出力された。 (#1044) (@kazuminn)

## 2.5.0 [2023/05/07] "Golden Week Release"

**改善:**

- `search`コマンドに`-M, --multiline`オプションを追加した。 (#1017) (@hitenkoku)
- `search`コマンドの出力での不要な改行やタブを削除した。 (#1003) (@hitenkoku)
- 正規表現の不要なエスケープを許容し、パースエラーを減らす`regex`クレートを1.8に更新した。(#1018) (@YamatoSecurity)
- `csv-timeline`コマンドの出力で不要な空白文字の削除を行った。 (#1019) (@hitenkoku)
- `update-rules`コマンド使用時にハヤブサのバージョン番号の詳細を確認するようにした (#1028) (@hitenkoku)
- `search`コマンドの結果を時刻順にソートした。 (#1033) (@hitenkoku)
- `pivot-keywords-list`のターミナル出力の改善。 (#1022) (@kazuminn)

**バグ修正:**

- ruleで指定された値で`\`が最後の文字のときに、検知ができない問題を修正した。 (#1025) (@fukusuket)
- results summary内のInformationalレベルアラートの結果が同じ内容が2つ表示されている状態を修正した。 (#1031) (@hitenkoku)

## 2.4.0 [2023/04/19] "SANS Secure Korea Release"

**新機能:**

- 指定されたキーワードに合致したレコードを検索する`search`コマンドを追加した。 (#617) (@itiB, @hitenkoku)
- 指定された正規表現に合致したレコードを検索する`-r, --regex`オプションを`search`コマンドに追加した。 (#992) (@itiB)
- Aho-Corasickクレートをversino1.0に更新した。 (#1013) (@hitenkoku)

**改善:**

- コマンドの表示順を辞書順に並べ替えた。 (#991) (@hitenkoku)
- `csv-timeline`, `json-timeline`, `search`コマンドの `AllFieldInfo`の出力に`Event.UserData`の属性情報を追加した。 (#1006) (@hitenkoku)

**バグ修正:**

- v2.3.3にて`-T, --visualize-timeline`データの中に存在していないタイムスタンプがイベント頻度のタイムラインに出力するバグを修正した。 (#977) (@hitenkoku)

## 2.3.3 [2023/04/07] "Sakura Release"

**改善:**

- ファイル(CSV, JSON, JSONL)出力の際にルールの`level`の余分なスペースを削除した。 (#979) (@hitenkoku)
- `-M, --multiline`オプション利用時にルール作者名の出力を複数行出力対応をした。 (#980) (@hitenkoku)
- Stringの代わりにCoWを利用することで、約5%の速度向上を実現した。 (#984) (@hitenkoku)
- Clapの新バージョンでロゴ後のメッセージとUsageテキストの出力色が緑にならないように修正した。 (#989) (@hitenkoku)

**バグ修正:**

- v2.3.0にて`level-tuning`コマンド実行時にクラッシュする問題を修正した。 (#977) (@hitenkoku)

## 2.3.2 [2023/03/22] "TMCIT Release-3"

**改善:**

- `csv-timeline`コマンドに`-M, --multiline`オプションを追加した。 (#972) (@hitenkoku)

## 2.3.1 [2023/03/18] "TMCIT Release-2"

**改善:**

- `csv-timeline`の出力のフィールドでダブルクォートを追加した。 (#965) (@hitenkoku)
- `logon-summary`の見出しを更新した。 (#964) (@yamatosecurity)
- `--enable-deprecated-rules`の`-D`ショートオプションと`--enable-unsupported-rules`の`-u`ショートオプションを追加した。(@yamatosecurity)
- Filteringセクションのオプションの表示順とヘルプの表示内容を修正した。 (#969) (@hitenkoku)

**バグ修正:**

- v2.3.0にて`update-rules`コマンド実行時にクラッシュする問題を修正した。 (#965) (@hitenkoku)
- コマンドプロンプトとPowerShellプロンプトではヘルプメニューのタイトルに長いアンダーバーが表示されていた問題が修正された。 (#911) (@yamatosecurity)

## 2.3.0 [2023/03/16] "TMCIT Release"

**新機能:**

- 新たなパイプキーワードの`|cidr`に対応した。 (#961) (@fukusuket)
- 新たなキーワードの`1 of selection*`と`all of selection*`に対応した。 (#957) (@fukusuket)
- 新たなパイプキーワードの`|contains|all`に対応した。 (#945) (@hitenkoku)
- ステータスが`unsupported`となっているルールの件数を表示した。ステータス`unsupported`のルールも検知対象とするオプションとして`--enable-supported-rules`オプションを追加した。 (#949) (@hitenkoku)

**改善:**

- 文字列が含まれているかの確認処理を改善することで約2-3%の速度改善をした。(#947) (@hitenkoku)

**バグ修正:**

- 一部のイベントタイトルが定義されていても、`metrics`コマンドで`Unknown`と表示されることがあった。 (#943) (@hitenkoku)

## 2.2.2 [2023/2/22] "Ninja Day Release"

**新機能:**

- 新たなパイプキーワード(`|base64offset|contains`)に対応した。 (#705) (@hitenkoku)

**改善:**

- オプションのグループ分けを再修正した。(#918)(@hitenkoku)
- JSONL形式のログを読み込む際のメモリ使用量を約75%削減した。 (#921) (@fukusuket)
- `rules/config/generic_abbreviations.txt`によってチャンネル名の一般的な単語名を省略する機能をmetrics、json-timeline、csv-timelineに追加した。 (#923) (@hitenkoku)
- evtxクレートを更新することにより、パースエラーを減少させた。 (@YamatoSecurity)
- Provider名(`%Provider%`)のフィールドに対する出力文字の省略機能を追加した。 (#932) (@hitenkoku)
- `metrics`コマンドで`-d`オプションが指定されたときに最初と最後のイベントのタイムスタンプを表示する機能を追加した。 (#935) (@hitenkoku)
- 結果概要に最初と最後のイベントのタイムスタンプを表示した。 (#938) (@hitenkoku)
- `logon-summary`と`metrics`コマンドに時刻表示のオプションを追加した. (#938) (@hitenkoku)
- `json-output`コマンドで`--output`で出力される結果に`\r`、`\n`、`\t`を出力するようにした。 (#940) (@hitenkoku)

**バグ修正:**

- `logon-summary`と`metrics`コマンドで、最初と最後のタイムスタンプが出力されない不具合を修正した。 (#920) (@hitenkoku)
- `metrics`コマンドで全てのイベントのタイトルが表示されない問題を修正した。 (#933) (@hitenkoku)

## 2.2.0 [2022/2/12] "SECCON Release"

**新機能:**

- JSON形式のイベントログファイルの入力(`-J, --JSON-input`)に対応した。 (#386) (@hitenkoku)
- MaxMindのGeoIPデータベースに基づき、送信元および送信先IPアドレスのASN組織、都市、国を出力することによるログエンリッチメント(`-G, --GeoIP`)を実現した。 (#879) (@hitenkoku)
- `-e, --exact-level`オプションで指定したレベルに対する結果のみを取得する機能を追加した。 (#899) (@hitenkoku)

**改善:**

- HTMLレポートの出力に実行したコマンドラインを追加した。 (#877) (@hitenkoku)
- イベントIDの完全比較を行うことで、約3%の速度向上とメモリ使用量の削減を実現した。 (#882) (@fukusuket)
- 正規表現使用前のフィルタリングにより、約14%の速度向上とメモリ使用量の削減を実現した。 (#883) (@fukusuket)
- 正規表現ではなく大文字小文字を区別しない比較により、約8%の速度向上とメモリ使用量の削減を実現した。 (#884) (@fukusuket)
- ワイルドカード表現における正規表現の使用量を削減することで、約5%の速度向上とメモリ使用量の削減を実現した。 (#890) (@fukusuket)
- 正規表現の使用を避けることで、さらなる高速化とメモリ使用量の削減を実現した。 (#894) (@fukusuket)
- 正規表現の使用量を減らすことで、約3%の速度向上と約10%のメモリ使用量削減を実現した。 (#898) (@fukuseket)
- ライブラリの更新によって`-T, --visualize-timeline`の出力を複数行にするように変更した。 (#902) (@hitenkoku)
- JSON/L形式のログを読み込む際のメモリ使用量を約50%削減した。 (#906) (@fukusuket)
- Longオプションを基にしたオプションの並べ替えを行った。 (#904) (@hitenkoku)
- `-J, --JSON-input`オプションを`logon-summary`, `metrics`, `pivot-keywords-list`コマンドに対応させた。 (#908) (@hitenkoku)

**バグ修正:**

- ルールの条件にバックスラッシュが4つある場合、ルールがマッチしない不具合を修正した。 (#897) (@fukuseket)
- JSON出力では、PowerShell EID 4103をパースする際に`Payload`フィールドが複数のフィールドに分離されるバグを修正した。(#895) (@hitenkoku)
- ファイルサイズ取得の際にpanicが発生するのを修正した。 (#914) (@hitenkoku)

**脆弱性修正:**

- ルールや設定ファイルを更新する際に起こりうるSSH MITM攻撃(CVE-2023-22742)を防ぐため、git2およびgitlib2クレートを更新した。 (#888) (@YamatoSecurity)

## 2.1.0 [2023/01/10] "Happy Year of the Rabbit Release"

**改善:**

- 速度の改善。 (#847) (@hitenkoku)
- 出力の改善を行うことによる速度の改善。 (#858) (@fukusuket)
- 実行ごとに同じ時間の検知の出力の順番のソートを行っていないのを修正した。 (#827) (@hitenkoku)

**バグ修正:**

- ログオン情報の出力機能で`--output`を指定したときにログオン成功のcsv出力ができない問題を修正した。 (#849) (@hitenkoku)
- `-J, --jsonl`を指定したときに不要な改行が含まれていたため修正した。 (#852) (@hitenkoku)

## 2.0.0 [2022/12/24] "Merry Christmas Release"

**新機能:**

- コマンドの使用方法とヘルプメニューはサブコマンドで行うようにした。 (#656) (@hitenkoku)

## 1.9.0 [2022/12/24] "Merry Christmas Release"

**新機能:**

- 新たなパイプキーワード(`|endswithfield`)に対応した。 (#740) (@hach1yon)
- 実行時のメモリ利用率を表示する機能を追加した。`--debug`オプションで利用可能。 (#788) (@fukusuket)

**改善:**

- Clap Crateパッケージの更新。更新の関係で`--visualize-timeline` のショートオプションの`-V`を`-T`に変更した。 (#725) (@hitenkoku)
- ログオン情報の出力でログオンタイプ、送信元の端末名とIPアドレス等を出力できるようにした。また、ログオンに失敗の一覧も出力するようにした。 (#835) (@garigariganzy @hitenkoku)
- 速度とメモリ使用の最適化。 (#787) (@fukusuket)
- イースターエッグのASCIIアートをカラー出力するようにした。 (#839) (@hitenkoku)
- `--debug`オプションをオプションの一覧から非表示にした。 (#841) (@hitenkoku)

**バグ修正:**

- コマンドプロンプトで`-d`オプションを設定した際にダブルクォーテーションで囲んだときにevtxファイルの収集ができていないバグを修正した。 (#828) (@hitenkoku)
- ルールのパースエラーが発生した際に不必要な改行が出力されていたのを修正した。 (#829) (@hitenkoku)

## 1.8.1 [2022/11/21]

**改善:**

- インポートしているcrateのRustバージョンによるビルドエラーを回避するためにCargo.tomlに`rust-version`を追加した。(#802) (@hitenkoku)
- メモリ使用の削減。 (#806) (@fukusuket)
- WEC機能を利用したevtxファイルのレンダーされたメッセージを出力するための`%RenderedMessage%`フィールドを追加した。 (#760) (@hitenkoku)

**バグ修正:**

- `Data`フィールドを使ったルールが検知できていない問題を修正した。 (#775) (@hitenkoku)
- プロファイルの出力で`%MitreTags%` と`%MitreTactics%` の出力が抜け落ちてしまう問題を修正した。 (#780) (@fukusuket)

## 1.8.0 [2022/11/07]

**新機能:**

- 新たな時刻表示のオプションとして`--ISO-8601`を追加した。 (#574) (@hitenkoku)

**改善:**

- イベントIDによるフィルタリングをデフォルトでは動作しないようにした。イベントIDフィルタを利用するためのオプション`-e, --eid-filter`を追加した。 (#759) (@hitenkoku)
- 異なるユーザアカウントで新しいルールをダウンロードしようとしたときに、分かりやすいエラーメッセージを表示する。 (#758) (@fukusuket)
- 合計およびユニークな検知数の情報をHTMLレポートに追加した。 (#762) (@hitenkoku)
- JSONの出力の中にある各検知内容のオブジェクトを持つ不要な配列の構造を削除した。 (#766)(@hitenkoku)
- プロファイルで出力できる情報にルール作成者(`%RuleAuthor%`)、 ルール作成日(`%RuleCreationDate%`)、 ルール修正日(`%RuleModifiedDate%`)、ルールステータス(`%Status%`)を追加した。 (#761) (@hitenkoku)
- JSON出力のDetailsフィールドをオブジェクト形式で出力するように変更した。 (#773) (@hitenkoku)
- `build.rs`を削除し、メモリアロケータをmimallocに変更した。Intel系OSでは20-30%の速度向上が見込める。 (#657) (@fukusuket)
- プロファイルの`%RecordInformation%` エイリアスを `%AllFieldInfo%` に変更した。 AllFieldInfoフィールドをJSONオブジェクト形式で出力するように変更した。 (#750) (@hitenkoku)
- AllFieldInfoフィールドのJSONオブジェクト内で利用していたHBFI-プレフィックスを廃止した。 (#791) (@hitenkoku)
- `--no-summary`  オプションを使用したときに、表示しないルール作者および検知回数の集計を省略した。(Velociraptorエージェントを利用するときに有用です。10%はこのオプションの付与により高速化します) (#780) (@hitenkoku)
- メモリ使用量を少なくし、処理速度を改善した。 (#778 #790) (@hitenkoku)
- 検知したルール作者のリストが空の時にルール作者のリストを表示しないように修正した。(#795) (@hitenkoku)
- プロファイルで出力できる情報にルールID(`%RuleID%`)、プロバイダー名情報(`%Provider%`)を追加した。 (#794) (@hitenkoku)

**バグ修正:**

- ルール作者数の集計に誤りがあったのを修正した。 (#783) (@hitenkoku)

## 1.7.2 [2022/10/17]

**新機能:**

- 利用可能な出力プロファイルの一覧を出力する`--list-profiles` オプションを追加した。 (#746) (@hitenkoku)

**改善:**

- 見やすくするためにファイル保存の出力をする位置とupdateオプションの出力を変更した。 (#754) (@YamatoSecurity)
- 検知したルールの作者名の最大文字数を40文字にした。 (#751) (@hitenkoku)

**バグ修正:**

- フィールド内にドライブレター(ex c:)が入っていた場合JSON/JSONL出力機能のフィールドの値がずれてしまっていたバグを修正した。 (#748) (@hitenkoku)

## 1.7.1 [2022/10/10]

**改善:**

- より正確な結果を出力するために、チャンネルとEIDの情報を`rules/config/channel_eid_info.txt`に基づいてチェックするようにした。 (#463) (@garigariganzy)
- 検知ルールを利用しないオプション(`-M`と`-L`オプション)の時のメッセージの出力内容を修正した。 (#730) (@hitenkoku)
- 検出したルールの作者名を標準出力に追加した。 (#724) (@hitenkoku)
- チャンネル情報が`null`となっているレコード(ETWイベント)を検知およびmetricの対象から除外した。 (#727) (@hitenkoku)

**バグ修正:**

- mericオプションのEventIDのキー名の数え上げが原因となっていたイベント集計の誤りを修正した。 (#729) (@hitenkoku)

## 1.7.0 [2022/09/29]

**新機能:**

- HTMLレポート機能 (`-H, --html-report`)の追加。 (#689) (@hitenkoku, @nishikawaakira)

**改善:**

- EventID解析のオプションをmetricsオプションに変更した。(旧: `-s, --statistics` -> 新: `-M, --metrics`) (#706) (@hitenkoku)
- ルール更新オプション(`-u`)を利用したときにHayabusaの新バージョンがないかを確認し、表示するようにした。 (#710) (@hitenkoku)
- HTMLレポート内にロゴを追加した。 (#714) (@hitenkoku)
- メトリクスオプション(`-M --metrics`)もしくはログオン情報(`-L --logon-summary`)と`-d`オプションを利用した場合に1つのテーブルで表示されるように修正した。 (#707) (@hitenkoku)
- メトリクスオプションの結果出力にチャンネル列を追加した。 (#707) (@hitenkoku)
- メトリクスオプション(`-M --metrics`)もしくはログオン情報(`-L --logon-summary`)と`-d`オプションを利用した場合に「First Timestamp」と「Last Timestamp」の出力を行わないように修正した。 (#707) (@hitenkoku)
- メトリクスオプションとログオン情報オプションに対してcsv出力機能(`-o --output`)を追加した。 (#707) (@hitenkoku)
- メトリクスオプションの出力を検出回数と全体の割合が1つのセルで表示されていた箇所を2つの列に分けた。 (#707) (@hitenkoku)
- メトリクスオプションとログオン情報の画面出力に利用していたprettytable-rsクレートをcomfy_tableクレートに修正した. (#707) (@hitenkoku)
- HTMLレポート内にfavicon.pngを追加した。 (#722) (@hitenkoku)

## v1.6.0 [2022/09/16]

**新機能:**

- 解析結果をJSONに出力する機能(`-j, --json-timeline`)を追加した。 (#654) (@hitenkoku)
- 解析結果をJSONL形式で出力する機能 (`-J, --jsonl` )を追加した。 (#694) (@hitenkoku)

**改善:**

- 結果概要に各レベルで検知した上位5つのルールを表示するようにした。 (#667) (@hitenkoku)
- 結果概要を出力しないようにするために `--no-summary` オプションを追加した。 (#672) (@hitenkoku)
- 結果概要の表示を短縮させた。 (#675 #678) (@hitenkoku)
- channel_abbreviations.txtによるChannelフィールドのチェックを大文字小文字の区別をなくした。 (#685) (@hitenkoku)
- 出力結果の区切り文字を`|`から`‖`に変更した。 (#687) (@hitenkoku)
- 結果概要の検知数と総イベント数の数に色付けを行い見やすくした。 (#690) (@hitenkoku)
- evtxクレートを0.8.0にアップデート。(ヘッダーや日付の値が無効な場合の処理が改善された。)
- 出力プロファイルの更新。（@YamatoSecurity)

**バグ修正:**

- ログオン情報の要約オプションを追加した場合に、Hayabusaがクラッシュしていたのを修正した。 (#674) (@hitenkoku)
- configオプションで指定したルールコンフィグの読み込みができていない問題を修正した。 (#681) (@hitenkoku)
- 結果概要のtotal eventsで読み込んだレコード数が出力されていたのを、検査対象にしているevtxファイルの実際のレコード数に修正した。 (#683) (@hitenkoku)

## v1.5.1 [2022/08/20]

**改善:**

- TimesketchにインポートできるCSV形式を出力するプロファイルを追加して、v1.5.1を再リリースした。 (#668) (@YamatoSecurity)

## v1.5.1 [2022/08/19]

**バグ修正:**

- Critical, medium、lowレベルのアラートはカラーで出力されていなかった。 (#663) (@fukusuket)
- `-f`で存在しないevtxファイルが指定された場合は、Hayabusaがクラッシュしていた。 (#664) (@fukusuket)

## v1.5.0 [2022/08/18]

**新機能:**

- `config/profiles.yaml`と`config/default_profile.yaml`の設定ファイルで、出力内容をカスタマイズできる。 (#165) (@hitenkoku)
- 対象のフィールドがレコード内に存在しないことを確認する `null` キーワードに対応した。 (#643) (@hitenkoku)

**改善:**

- ルールのアップデート機能のルールパスの出力から./を削除した。 (#642) (@hitenkoku)
- MITRE ATT&CK関連のタグとその他タグを出力するための出力用のエイリアスを追加した。 (#637) (@hitenkoku)
- 結果概要の数値をカンマをつけて見やすくした。 (#649) (@hitenkoku)
- `-h`オプションでメニューを使いやすいようにグループ化した。 (#651) (@YamatoSecurity and @hitenkoku)
- 結果概要内の検知数にパーセント表示を追加した。 (#658) (@hitenkoku)

**バグ修正:**

- aggregation conditionのルール検知が原因で検知しなかったイベント数の集計に誤りがあったので修正した。 (#640) (@hitenkoku)
- 一部のイベント（0.01%程度）が検出されないレースコンディションの不具合を修正した。 (#639 #660) (@fukusuket)

## v1.4.3 [2022/08/03]

**バグ修正:**

- VC再頒布パッケージがインストールされていない環境でエラーが発生している状態を修正した。 (#635) (@fukusuket)

## v1.4.2 [2022/07/24]

**改善:**

- `--update-rules` オプションを利用する時に、更新対象のレポジトリを`--rules`オプションで指定できるようにした。 (#615) (@hitenkoku)
- 並列処理の改善による高速化。 (#479) (@kazuminn)
- `--output`オプションを利用したときのRulePathをRuleFileに変更した。RuleFileは出力するファイルの容量を低減させるためにファイル名のみを出力するようにした。 (#623) (@hitenkoku)

**バグ修正:**

- `cargo run`コマンドでhayabusaを実行するとconfigフォルダの読み込みエラーが発生する問題を修正した。 (#618) (@hitenkoku)

## v1.4.1 [2022/06/30]

**改善:**

- ルールや`./rules/config/default_details.txt` に対応する`details`の記載がない場合、すべてのフィールド情報を結果の``Details`列に出力するようにした (#606) (@hitenkoku)
- `--deep-scan`オプションの追加。 このオプションがない場合、`config/target_event_ids.txt`で指定されたイベントIDのみをスキャン対象とします。 このオプションをつけることですべてのイベントIDをスキャン対象とします。(#608) (@hitenkoku)
- `-U, --update-rules`オプションで`channel_abbreviations.txt`、`statistics_event_info.txt`、`target_event_IDs.txt`を更新できるように、`config`ディレクトリから`rules/config`ディレクトリに移動した。

## v1.4.0 [2022/06/26]

**新機能:**

- `--target-file-ext` オプションの追加。evtx以外の拡張子を指定する事ができます。ただし、ファイルの中身の形式はevtxファイル形式である必要があります。 (#586) (@hitenkoku)
- `--exclude-status` オプションの追加。ルール内の`status`フィールドをもとに、読み込み対象から除外するフィルタを利用することができます。 (#596) (@hitenkoku)

**改善:**

- ルール内に`details`フィールドがないときに、`rules/config/default_details.txt`に設定されたデフォルトの出力を行えるようにした。 (#359) (@hitenkoku)
- Clap Crateパッケージの更新 (#413) (@hitenkoku)
- オプションの指定がないときに、`--help`と同じ画面出力を行うように変更した。(#387) (@hitenkoku)
- hayabusa.exeをカレントワーキングディレクトリ以外から動作できるようにした。 (#592) (@hitenkoku)
- `output` オプションで指定されファイルのサイズを出力するようにした。 (#595) (@hitenkoku)

**バグ修正:**

- カラー出力で長い出力があった場合にエラーが出て終了する問題を修正した。 (#603) (@hitenkoku)
- `Excluded rules`の合計で`rules/tools/sigmac/testfiles`配下のテストルールも入っていたので、無視するようにした。 (#602) (@hitenkoku)

## v1.3.2 [2022/06/13]

- evtxクレートを0.7.2から0.7.3に更新し、パッケージを全部更新した。 (@YamatoSecurity)

## v1.3.1 [2022/06/13]

**新機能:**

- ルール内の`details`で複数の`Data`レコードから特定のデータを指定して出力できるようにした。 (#487) (@hitenkoku)
- 読み込んだルールのステータス情報の要約を追加した。 (#583) (@hitenkoku)

**改善:**

- LinuxとmacOSのバイナリサイズをより小さくするために、デバッグシンボルをストリップします。(#568) (@YamatoSecurity)
- Crateパッケージの更新 (@YamatoSecurity)
- 新たな時刻表示のオプションとして`--US-time`、`--US-military-time`、`--European-time`の3つを追加した (#574) (@hitenkoku)
- `--rfc-3339` オプションの時刻表示形式を変更した。 (#574) (@hitenkoku)
- `-R/ --display-record-id`オプションを`-R/ --hide-record-id`に変更。レコードIDはデフォルトで出力するようにして`-R`オプションを付けた際に表示しないように変更した。(#579) (@hitenkoku)
- ルール読み込み時のメッセージを追加した。 (#583) (@hitenkoku)
- `rules/tools/sigmac/testfiles`内のテスト用のymlファイルを読み込まないようにした. (#602) (@hitenkoku)

**バグ修正:**

- 対応するオプションを付与していないときにもRecordIDとRecordInformationの列が出力されていたのを修正した。 (#577) (@hitenkoku)

## v1.3.0 [2022/06/06]

**新機能:**

- `--visualize-timeline`オプションで検知されたイベントが5つ以上の時、イベント頻度のタイムラインを作成するようにした。 (#533, #566) (@hitenkoku)
- `--all-tags`オプションでルールにある全てのtagsを、outputで指定したcsvのMitreAttackの列に出力するようにした。 (#525) (@hitenkoku)
- `-R` / `--display-record-id` オプションの追加。evtx file内のレコードを特定するレコードID`<Event><System><EventRecordID>`が出力できるようになった。 (#548) (@hitenkoku)
- レベルごとの検知数が最も多い日を表示するようにした。 (#550) (@hitenkoku)
- レベルごとの検知数上位3つのコンピュータ名を表示するようにした。 (#557)(@hitenkoku)

**改善:**

- ルールの`details`でeventkey_alias.txtやEvent.EventData内に存在しない情報を`n/a` (not available)と表記するようにした。(#528) (@hitenkoku)
- 読み込んだイベント数と検知しなかったイベント数を表示するようにした。 (#538) (@hitenkoku)
- 新しいロゴに変更した。(#536) (@YamatoSecurity)
- evtxファイルのファイルサイズの合計を出力するようにした。(#540) (@hitenkoku)
- ロゴの色を変更した (#537) (@hitenkoku)
- Channelの列にchannel_abbrevations.txtに記載されていないチャンネルも表示するようにした。(#553) (@hitenkoku)
- `Ignored rules`として集計されていた`Exclude rules`、`Noisy rules`、`Deprecated rules`に分けて表示するようにした。 (#556) (@hitenkoku)
- `output`オプションが指定されているときに、ファイル出力中のメッセージを表示するようにした。 (#561) (@hitenkoku)

**バグ修正:**

- `--start-timeline`、`--end-timeline`オプションが動かなかったのを修正した。 (#546) (@hitenkoku)
- ルール内の`level`が正しくない場合に検知数が最も多い日の集計の際にcrashが起きるのを修正した。 (#560) (@hitenkoku)

## v1.2.2 [2022/05/20]

**新機能:**

- ログオン情報の要約の機能の追加。 (`-L` / `--logon-summary`) (@garigariganzy)

**改善:**

- カラー出力はデフォルトで有効になって、コマンドプロンプトとPowerShellプロンプトに対応している。 (@hitenkoku)

**バグ修正:**

- `rules`フォルダが存在するが、レポジトリがダウンロードされていない場合は、ルール更新が失敗していたが、修正した。(#516) (@hitenkoku)
- .gitフォルダ内にあるymlファイルが一部のWindows環境で読み込まれた際にエラーが発生していたが、修正した。(#524)(@hitenkoku)
- 1.2.1バイナリで表示する誤ったバージョン番号の修正。

## v1.2.1 [2022/04/20] Black Hat Asia Arsenal 2022 RC2

**新機能:**

- `./config/channel_abbreviations`の設定ファイルにより、`Channel`列も出力されるようになった。 (@hitenkoku)
- ルールとルールの設定ファイルは強制的に上書きされる。 (@hitenkoku)

**バグ修正:**

- ルールがnoisyもしくはexcludedと設定された場合は、`--level-tuning`オプションで`level`が更新されなかったが、修正した。 (@hitenkoku)

## v1.2.0 [2022/04/15] Black Hat Asia Arsenal 2022 RC1

**新機能:**

- `-C / --config` オプションの追加。検知ルールのコンフィグを指定することが可能。(Windowsでのライブ調査に便利) (@hitenkoku)
- `|equalsfield` と記載することでルール内で二つのフィールドの値が一致するかを記載に対応。 (@hach1yon)
- `-p / --pivot-keywords-list` オプションの追加。攻撃されたマシン名や疑わしいユーザ名などの情報をピボットキーワードリストとして出力する。 (@kazuminn)
- `-F / --full-data`オプションの追加。ルールの`details`で指定されたフィールドだけではなく、全フィールド情報を出力する。(@hach1yon)
- `--level-tuning` オプションの追加。ルールの検知ファイルを設定したコンフィグファイルに従って検知レベルをチューニングすることが可能(@itib、@hitenkoku)

**改善:**

- 検知ルールとドキュメントの更新。 (@YamatoSecurity)
- MacとLinuxのバイナリに必要なOpenSSLライブラリを静的コンパイルした。 (@YamatoSecurity)
- タブ等の文字が含まれたフィールドに対しての検知性能の改善。 (@hach1yon、@hitenkoku)
- eventkey_alias.txt内に定義されていないフィールドをEvent.EventData内を自動で検索することが可能。 (@kazuminn、@hitenkoku)
- 検知ルールの更新時、更新されたルールのファイル名が表示される。 (@hitenkoku)
- ソースコードにあるClippyの警告を修正。 (@hitenkoku、@hach1yon)
- イベントIDとタイトルが記載されたコンフィグファイルの名前を `timeline_event_info.txt` から `statistics_event_info.txt`に変更。 (@YamatoSecurity、 @garigariganzy)
- 64bit Windowsで32bit版のバイナリを実行しないように修正(@hitenkoku)
- MITRE ATT&CKのデータの出力を`output_tag.txt`で修正できるように修正(@hitenkoku)
- 出力にChannel名のカラムを追加(@hitenkoku)

**バグ修正:**

- `.git` フォルダ内にある `.yml` ファイルがパースエラーを引き起こしていた問題の修正。 (@hitenkoku)
- テスト用のルールファイルの読み込みエラーで不必要な改行が発生していた問題の修正。 (@hitenkoku)
- Windows Terminalのバグで標準出力が途中で止まる場合がありましたが、Hayabusa側で解決しました。 (@hitenkoku)

## v1.1.0 [2022/03/03]

**新機能:**

- `-r / --rules`オプションで一つのルール指定が可能。(ルールをテストする際に便利！) (@kazuminn)
- ルール更新オプション (`-u / --update-rules`): [hayabusa-rules](https://github.com/Yamato-Security/hayabusa-rules)レポジトリにある最新のルールに更新できる。 (@hitenkoku)
- ライブ調査オプション (`-l / --live-analysis`): Windowsイベントログディレクトリを指定しないで、楽にWindows端末でライブ調査ができる。(@hitenkoku)

**改善:**

- ドキュメンテーションの更新。 (@kazuminn、@itiB、@hitenkoku、@YamatoSecurity)
- ルールの更新。(Hayabusaルール: 20個以上、Sigmaルール: 200個以上) (@YamatoSecurity)
- Windowsバイナリは静的でコンパイルしているので、Visual C++ 再頒布可能パッケージをインストールする必要はない。(@hitenkoku)
- カラー出力 (`-c / --color`) True Colorに対応しているターミナル(Windows Terminal、iTerm2等々)ではカラーで出力できる。(@hitenkoku)
- MITRE ATT&CK戦略が出力される。(@hitenkoku)
- パフォーマンスの改善。(@hitenkoku)
- exclude_rules.txtとnoisy_rules.txtの設定ファイルのコメント対応。(@kazuminn)
- より速いメモリアロケータの利用。 (Windowsの場合はrpmalloc、macOS/Linuxの場合は、jemalloc) (@kazuminn)
- Cargo crateの更新。 (@YamatoSecurity)

**バグ修正:**

- `cargo update`がより安定するために、clapのバージョンを固定した。(@hitenkoku)
- フィールドのタブや改行がある場合に、ルールが検知しなかったので、修正した。(@hitenkoku)

## v1.0.0-Release 2 [2022/01/27]

- アンチウィルスに誤検知されたExcelの結果ファイルの削除。(@YamatoSecurity)
- Rustのevtxライブラリを0.7.2に更新。 (@YamatoSecurity)

## v1.0.0 [2021/12/25]

- 最初のリリース
