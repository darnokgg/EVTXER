use cidr_utils::cidr::IpCidr;
use compact_str::CompactString;
use hashbrown::HashMap;
use maxminddb::{MaxMindDbError, Reader, geoip2};
use std::io::Error;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::{net::IpAddr, str::FromStr};

/// Wraps the three MaxMind GeoLite2 database readers (ASN, Country, City) used to enrich IP
/// addresses found in event records when the GeoIP option is enabled.
#[derive(Debug)]
pub struct GeoIPSearch {
    pub asn_reader: Reader<Vec<u8>>,
    pub country_reader: Reader<Vec<u8>>,
    pub city_reader: Reader<Vec<u8>>,
    // Cache of IP address -> formatted geo data ("ASN🦅Country🦅City"), so each address is only
    // looked up in the MaxMind databases once.
    ip_map: Mutex<HashMap<IpAddr, CompactString>>,
}

impl GeoIPSearch {
    /// Opens the three .mmdb databases. `asn_country_city_filename` must list the ASN, Country
    /// and City database file names in that order.
    pub fn new(path: &Path, asn_country_city_filename: Vec<&str>) -> GeoIPSearch {
        GeoIPSearch {
            asn_reader: maxminddb::Reader::open_readfile(path.join(asn_country_city_filename[0]))
                .unwrap(),
            country_reader: maxminddb::Reader::open_readfile(
                path.join(asn_country_city_filename[1]),
            )
            .unwrap(),
            city_reader: maxminddb::Reader::open_readfile(path.join(asn_country_city_filename[2]))
                .unwrap(),
            ip_map: Mutex::new(HashMap::new()),
        }
    }

    /// Checks that all .mmdb files required by the GeoIP option exist under the given
    /// directory. Returns Ok(None) when the option was not specified, and an error listing
    /// every missing file otherwise.
    pub fn check_exist_geo_ip_files(
        geo_ip_dir_path: &Option<PathBuf>,
        check_files: Vec<&str>,
    ) -> Result<Option<PathBuf>, String> {
        if let Some(path) = geo_ip_dir_path {
            let mut combined_err = vec![];
            for file_name in check_files {
                let mmdb_path = path.join(file_name);
                if !mmdb_path.exists() {
                    combined_err.push(format!(
                        "Cannot find the appropriate MaxMind GeoIP .mmdb database files. filepath: {mmdb_path:?}"
                    ));
                }
            }
            if combined_err.is_empty() {
                Ok(geo_ip_dir_path.to_owned())
            } else {
                Err(combined_err.join("\n"))
            }
        } else {
            Ok(None)
        }
    }

    /// Checks whether target_ip falls within one of the CIDR ranges below, which are excluded
    /// from GeoIP lookup and reported as "Private".
    fn check_in_private_ip_range(&self, target_ip: &IpAddr) -> bool {
        let private_cidr = if target_ip.is_ipv4() {
            vec![
                IpCidr::from_str("10.0.0.0/8").unwrap(),
                IpCidr::from_str("172.16.0.0/12").unwrap(),
                IpCidr::from_str("192.168.0.0/16").unwrap(),
            ]
        } else {
            vec![
                IpCidr::from_str("::/128").unwrap(),    // IPv6 Unspecified
                IpCidr::from_str("FE80::/10").unwrap(), // IPv6 Link Local Unicast
                IpCidr::from_str("FC00::/7").unwrap(), // IPv6 Unique Local Address (covers FD00::/8)
                IpCidr::from_str("FF00::/8").unwrap(), // IPv6 Multicast Address
            ]
        };
        for cidr in private_cidr {
            if cidr.contains(target_ip) {
                return true;
            }
        }
        false
    }

    /// Resolves an IP address string to geo data in the form "ASN🦅Country🦅City" (the caller
    /// splits on '🦅' to fill the SrcASN/SrcCountry/SrcCity etc. profile fields). Local and
    /// private addresses get placeholder values without a database lookup.
    pub fn convert_ip_to_geo(&self, target_ip: &str) -> Result<String, MaxMindDbError> {
        // Some events (e.g. RDP logons) record the literal string "LOCAL" instead of an IP
        // address; the first literal checked below is the Japanese-localized equivalent.
        if target_ip == "ローカル" || target_ip == "LOCAL" {
            return Ok("Local🦅-🦅-".to_string());
        }
        // Strip the IPv4-mapped IPv6 prefix so the address is handled as plain IPv4.
        let target = if target_ip.starts_with("::ffff:") {
            target_ip.replace("::ffff:", "")
        } else {
            target_ip.to_string()
        };
        let addr;
        if let Ok(conv) = IpAddr::from_str(&target) {
            addr = conv;
        } else {
            let msg = format!("Failed Convert IP Address. input: {target_ip}");
            return Err(MaxMindDbError::Io(Error::other(msg)));
        };

        if addr.is_loopback() || target_ip == "0.0.0.0" {
            return Ok("Local🦅-🦅-".to_string());
        }

        if self.check_in_private_ip_range(&addr) {
            return Ok("Private🦅-🦅-".to_string());
        }

        // The same IP address always resolves to the same geo data, so return the cached result
        // when available and skip the database lookups.
        if let Some(cached_data) = self.ip_map.lock().unwrap().get(&addr) {
            return Ok(cached_data.to_string());
        }
        let asn_search = self.asn_reader.lookup(addr);
        let country_search = self.country_reader.lookup(addr);
        let city_search = self.city_reader.lookup(addr);

        let output_asn = if let Ok(asn) = asn_search {
            if let Ok(Some(asn)) = asn.decode::<geoip2::Asn>() {
                asn.autonomous_system_organization.unwrap_or("-")
            } else {
                ""
            }
        } else {
            ""
        };

        let output_country = if let Ok(country) = country_search {
            let mut ret = "";
            if let Ok(Some(country)) = country.decode::<geoip2::Country>() {
                let name_tree = country.country.names;
                ret = name_tree.english.unwrap_or("")
            }
            ret
        } else {
            "-"
        };

        let output_city = if let Ok(city) = city_search {
            let mut ret = "";
            if let Ok(Some(city)) = city.decode::<geoip2::City>() {
                let name_tree = city.city.names;
                ret = name_tree.english.unwrap_or("")
            }
            ret
        } else {
            ""
        };

        let geo_data = format!("{output_asn}🦅{output_country}🦅{output_city}");
        self.ip_map
            .lock()
            .unwrap()
            .insert(addr, CompactString::from(&geo_data));
        Ok(geo_data)
    }
}

#[cfg(test)]
mod tests {
    use super::GeoIPSearch;
    use compact_str::CompactString;
    use std::{net::IpAddr, path::Path, str::FromStr};

    #[test]
    fn test_no_specified_geo_ip_option() {
        // Test files from https://github.com/maxmind/MaxMind-DB/tree/a8ae5b4ac0aa730e2783f708cdaa208aca20e9ec/test-data
        assert!(
            GeoIPSearch::check_exist_geo_ip_files(
                &None,
                vec![
                    "GeoLite2-ASN-Test.mmdb",
                    "GeoLite2-Country-Test.mmdb",
                    "GeoLite2-City-Test.mmdb",
                ]
            )
            .unwrap()
            .is_none()
        )
    }

    #[test]
    fn test_not_exist_files() {
        let target_files = vec![
            "GeoLite2-NoExist1.mmdb",
            "GeoLite2-NoExist2.mmdb",
            "GeoLite2-NoExist3.mmdb",
        ];
        let test_path = Path::new("test_files/mmdb").to_path_buf();
        let mut expect_err_msg = vec![];
        for file_path in &target_files {
            expect_err_msg.push(format!(
                "Cannot find the appropriate MaxMind GeoIP .mmdb database files. filepath: {:?}",
                test_path.join(file_path)
            ));
        }
        assert_eq!(
            GeoIPSearch::check_exist_geo_ip_files(&Some(test_path), target_files),
            Err(expect_err_msg.join("\n"))
        )
    }

    #[test]
    fn test_convert_ip_to_geo() {
        let test_path = Path::new("test_files/mmdb").to_path_buf();

        // Test files from https://github.com/maxmind/MaxMind-DB/tree/a8ae5b4ac0aa730e2783f708cdaa208aca20e9ec/test-data
        let target_files = vec![
            "GeoLite2-ASN.mmdb",
            "GeoLite2-Country.mmdb",
            "GeoLite2-City.mmdb",
        ];
        assert_eq!(
            GeoIPSearch::check_exist_geo_ip_files(&Some(test_path.clone()), target_files.clone()),
            Ok(Some(test_path.clone()))
        );
        let geo_ip = GeoIPSearch::new(&test_path, target_files);
        let expect = "🦅United Kingdom🦅Boxford";
        let actual = geo_ip.convert_ip_to_geo("2.125.160.216");
        assert!(actual.is_ok());
        assert_eq!(expect, actual.unwrap());
    }

    #[test]
    fn test_already_convert_ip_to_geo() {
        let test_path = Path::new("test_files/mmdb").to_path_buf();

        // Test files from https://github.com/maxmind/MaxMind-DB/tree/a8ae5b4ac0aa730e2783f708cdaa208aca20e9ec/test-data
        // The upstream files were renamed locally as follows:
        //   GeoLite2-ASN-Test.mmdb     -> GeoLite2-ASN.mmdb
        //   GeoLite2-Country-Test.mmdb -> GeoLite2-Country.mmdb
        //   GeoLite2-City-Test.mmdb    -> GeoLite2-City.mmdb
        let target_files = vec![
            "GeoLite2-ASN.mmdb",
            "GeoLite2-Country.mmdb",
            "GeoLite2-City.mmdb",
        ];
        assert_eq!(
            GeoIPSearch::check_exist_geo_ip_files(&Some(test_path.clone()), target_files.clone()),
            Ok(Some(test_path.clone()))
        );
        let geo_ip = GeoIPSearch::new(&test_path, target_files);
        // Pre-populate this instance's cache so the lookup returns the cached value instead of
        // hitting the databases.
        geo_ip.ip_map.lock().unwrap().insert(
            IpAddr::from_str("2.125.160.217").unwrap(),
            "this is dummy".into(),
        );
        let actual = geo_ip.convert_ip_to_geo("2.125.160.217");
        assert!(actual.is_ok());
        assert_eq!(CompactString::from("this is dummy"), actual.unwrap());
    }

    #[test]
    fn test_check_in_private_range_v4() {
        let test_path = Path::new("test_files/mmdb").to_path_buf();

        // Test files from https://github.com/maxmind/MaxMind-DB/tree/a8ae5b4ac0aa730e2783f708cdaa208aca20e9ec/test-data
        let target_files = vec![
            "GeoLite2-ASN.mmdb",
            "GeoLite2-Country.mmdb",
            "GeoLite2-City.mmdb",
        ];
        assert_eq!(
            GeoIPSearch::check_exist_geo_ip_files(&Some(test_path.clone()), target_files.clone()),
            Ok(Some(test_path.clone()))
        );
        let geo_ip = GeoIPSearch::new(&test_path, target_files);
        let loopback = geo_ip.convert_ip_to_geo("127.0.0.1");
        assert!(loopback.is_ok());
        assert_eq!("Local🦅-🦅-", loopback.unwrap());
        let actual_class_a = geo_ip.convert_ip_to_geo("10.1.1.128");
        assert!(actual_class_a.is_ok());
        assert_eq!("Private🦅-🦅-", actual_class_a.unwrap());
        let actual_class_b = geo_ip.convert_ip_to_geo("172.19.128.128");
        assert!(actual_class_b.is_ok());
        assert_eq!("Private🦅-🦅-", actual_class_b.unwrap());
        let actual_class_c = geo_ip.convert_ip_to_geo("192.168.128.128");
        assert!(actual_class_c.is_ok());
        assert_eq!("Private🦅-🦅-", actual_class_c.unwrap());
    }

    #[test]
    fn test_check_in_private_range_v6() {
        let test_path = Path::new("test_files/mmdb").to_path_buf();

        // Test files from https://github.com/maxmind/MaxMind-DB/tree/a8ae5b4ac0aa730e2783f708cdaa208aca20e9ec/test-data
        let target_files = vec![
            "GeoLite2-ASN.mmdb",
            "GeoLite2-Country.mmdb",
            "GeoLite2-City.mmdb",
        ];
        assert_eq!(
            GeoIPSearch::check_exist_geo_ip_files(&Some(test_path.clone()), target_files.clone()),
            Ok(Some(test_path.clone()))
        );
        let geo_ip = GeoIPSearch::new(&test_path, target_files);
        let loopback = geo_ip.convert_ip_to_geo("::1");
        assert!(loopback.is_ok());
        assert_eq!("Local🦅-🦅-", loopback.unwrap());
        let link_local = geo_ip.convert_ip_to_geo("fe80::123:33ef:fe11:1");
        assert!(link_local.is_ok());
        assert_eq!("Private🦅-🦅-", link_local.unwrap());
        let unspecified = geo_ip.convert_ip_to_geo("::");
        assert!(unspecified.is_ok());
        assert_eq!("Private🦅-🦅-", unspecified.unwrap());
        let unique_local = geo_ip.convert_ip_to_geo("fd12:3456:789a::1");
        assert!(unique_local.is_ok());
        assert_eq!("Private🦅-🦅-", unique_local.unwrap());
        let multicast = geo_ip.convert_ip_to_geo("ff02::1");
        assert!(multicast.is_ok());
        assert_eq!("Private🦅-🦅-", multicast.unwrap());
        // Global unicast addresses must be looked up in the databases instead of being
        // reported as Private (issue #1819). 2001:218::/32 is Japan in the MaxMind test
        // data (with no ASN or city entry, so those fields are empty).
        let global_unicast = geo_ip.convert_ip_to_geo("2001:218::1");
        assert!(global_unicast.is_ok());
        assert_eq!("🦅Japan🦅", global_unicast.unwrap());
    }
}
