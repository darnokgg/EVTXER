use hashbrown::HashSet;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use yaml_rust2::YamlLoader;
use yaml_rust2::yaml::Hash;

/// Recursively collects the paths of all `.yml` files under `dir`.
fn list_yml_files<P: AsRef<Path>>(dir: P) -> Vec<String> {
    let mut yml_files = Vec::new();
    if let Ok(entries) = fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                yml_files.extend(list_yml_files(path));
            } else if let Some(ext) = path.extension()
                && ext == "yml"
            {
                yml_files.push(path.to_string_lossy().to_string());
            }
        }
    }
    yml_files
}

/// Walks a rule's detection section and records every key that uses the `|expand` modifier,
/// mapping the key (e.g. `CommandLine|expand`) to its string value, which is the placeholder
/// (e.g. `%Admins_Workstations%`). Only string values are recorded; nested mappings are searched
/// recursively, but list values are not descended into.
fn extract_expand_keys_recursive(hash: &Hash, expand_keys: &mut HashMap<String, String>) {
    for (key, value) in hash {
        if let Some(key_str) = key.as_str() {
            if key_str.contains("|expand")
                && let Some(value_str) = value.as_str()
            {
                expand_keys.insert(key_str.to_string(), value_str.to_string());
            }
            if let Some(sub_hash) = value.as_hash() {
                extract_expand_keys_recursive(sub_hash, expand_keys);
            }
        }
    }
}
fn extract_expand_keys(detection: &Hash) -> HashMap<String, String> {
    let mut expand_keys = HashMap::new();
    extract_expand_keys_recursive(detection, &mut expand_keys);
    expand_keys
}

/// Returns the set of placeholder strings (e.g. `%Admins_Workstations%`) referenced by `|expand`
/// field modifiers in the detection sections of all `.yml` rules under `dir`. This backs the
/// `expand-list` command, which shows users which placeholders they need to define in
/// `config/expand`.
pub fn expand_list(dir: &PathBuf) -> HashSet<String> {
    let yml_files = list_yml_files(dir);
    let mut result = HashSet::new();
    for file in yml_files {
        if let Ok(content) = fs::read_to_string(&file)
            && let Ok(docs) = YamlLoader::load_from_str(&content)
            && let Some(yaml) = docs.first()
            && let Some(detection) = yaml["detection"].as_hash()
        {
            let expand_keys = extract_expand_keys(detection);
            if !expand_keys.is_empty() {
                result.extend(expand_keys.values().cloned())
            }
        }
    }
    result
}
