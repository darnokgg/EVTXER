extern crate bytesize;
extern crate downcast_rs;
extern crate maxminddb;
extern crate serde;
extern crate serde_derive;

use bytesize::ByteSize;
use chrono::{DateTime, Datelike, Local, NaiveDateTime, Utc};
use clap::Command;
use colored::Colorize;
use compact_str::CompactString;
use console::{Style, style};
use dialoguer::Confirm;
use dialoguer::{Select, theme::ColorfulTheme};
use evtx::{EvtxParser, ParserSettings, RecordAllocation};
use hashbrown::{HashMap, HashSet};
use hayabusa::debug::checkpoint_process_timer::CheckPointProcessTimer;
use hayabusa::detections::configs::{
    Action, CURRENT_EXE_PATH, ConfigReader, EventKeyAliasConfig, ONE_CONFIG_MAP, OutputType,
    StoredStatic, TargetEventTime, TargetIds, load_pivot_keywords, resolve_config_file,
};
use hayabusa::detections::detection::{self, EvtxRecordInfo};
use hayabusa::detections::message::{AlertMessage, DetectInfo, get_event_time};
use hayabusa::detections::rule::{RuleNode, get_detection_keys};
use hayabusa::detections::utils;
use hayabusa::detections::utils::{
    check_setting_path, get_file_size, get_writable_color, output_and_data_stack_for_html,
    output_profile_name,
};
use hayabusa::filter::{create_channel_filter, filter_evtx_files};
use hayabusa::level::LEVEL;
use hayabusa::options::htmlreport::{self, HtmlReporter};
use hayabusa::options::pivot::create_output;
use hayabusa::options::profile::set_default_profile;
use hayabusa::options::{expand_list::expand_list, level_tuning::LevelTuning, update::Update};
use hayabusa::results::{self, OutputWriter, ResultOutputState};
use hayabusa::timeline::computer_metrics::countup_event_by_computer;
use hayabusa::timeline::sort_csv;
use hayabusa::{detections::configs, timeline::timelines::Timeline};
use hayabusa::{detections::utils::write_color_buffer, filter};
use hayabusa::{options, yaml};
use indicatif::ProgressBar;
use indicatif::{ProgressDrawTarget, ProgressStyle};
#[cfg(target_os = "windows")]
use is_elevated::is_elevated;
use itertools::{Itertools, MinMaxResult};
use libmimalloc_sys::mi_stats_print_out;
use mimalloc::MiMalloc;
use nested::Nested;
use num_format::{Locale, ToFormattedString};
use rand::prelude::*;
use rust_embed::Embed;
use serde_json::{Map, Value};
use std::borrow::BorrowMut;
use std::cell::Cell;
use std::ffi::{OsStr, OsString};
use std::fmt::Display;
use std::fmt::Write as _;
use std::io::{BufRead, BufWriter, Write};
use std::path::Path;
use std::ptr::null_mut;
use std::sync::Arc;
use std::time::Duration;
use std::{
    env,
    fs::{self, File},
    io,
    path::PathBuf,
    vec,
};
use termcolor::{BufferWriter, Color, ColorChoice};
use tokio::runtime::Runtime;
use tokio::spawn;
use tokio::task::JoinHandle;
use ureq::get;
#[cfg(target_os = "windows")]
use winapi::{
    ctypes::c_void,
    shared::ntdef::PVOID,
    um::wow64apiset::{Wow64DisableWow64FsRedirection, Wow64RevertWow64FsRedirection},
};
use yaml_rust2::YamlLoader;

#[derive(Embed)]
#[folder = "art/"]
struct Arts;

#[derive(Embed)]
#[folder = "./"]
#[include = "contributors.txt"]
struct Contributors;

#[global_allocator]
static GLOBAL: MiMalloc = MiMalloc;

// The number of records to load and scan at a time. In test benchmarks, 1000 gave the fastest
// results and the lowest memory usage.
const MAX_DETECT_RECORDS: usize = 1000;

fn main() {
    let mut config_reader = ConfigReader::new();
    // Create the parsed command information and store it in a static variable.
    let mut stored_static = StoredStatic::create_static_data(config_reader.config.unwrap());
    config_reader.config = None;
    let mut app = App::new(stored_static.thread_number);
    app.exec(&mut config_reader.app, &mut stored_static);
    app.runtime.shutdown_background();
    if app.failed.get() {
        // The run was rejected or aborted before producing output; do not report success.
        std::process::exit(1);
    }
}

/// RAII guard that disables WOW64 filesystem redirection while it is alive and restores the
/// previous state on drop. Without this, a 32-bit binary running on 64-bit Windows would have
/// paths like C:\Windows\System32\winevt\Logs silently redirected to SysWOW64 and could not read
/// the real event logs. On non-Windows targets this is a no-op.
struct Wow64RedirectionGuard {
    #[cfg(target_os = "windows")]
    old_state: *mut c_void,
}

impl Wow64RedirectionGuard {
    fn new() -> Option<Self> {
        #[cfg(target_os = "windows")]
        {
            let mut old_state: *mut winapi::ctypes::c_void = std::ptr::null_mut();
            unsafe {
                if Wow64DisableWow64FsRedirection(&mut old_state as *mut *mut _ as *mut PVOID) != 0
                {
                    Some(Self { old_state })
                } else {
                    None
                }
            }
        }

        #[cfg(not(target_os = "windows"))]
        {
            Some(Self {})
        }
    }
}

impl Drop for Wow64RedirectionGuard {
    fn drop(&mut self) {
        #[cfg(target_os = "windows")]
        unsafe {
            Wow64RevertWow64FsRedirection(self.old_state as PVOID);
        }
    }
}

/// Application driver: owns the Tokio runtime used for record processing and the union of event
/// field keys referenced by the loaded detection rules.
pub struct App {
    runtime: Runtime,
    /// Set when a run is aborted by a usage or environment error, so `main` can exit non-zero.
    ///
    /// The abort paths below report the problem and `return`, which — because `exec` returns `()`
    /// and `main` then ends normally — used to leave the exit status at 0. A script or CI job
    /// checking `$?` could not tell a rejected command from a completed scan. A flag rather than
    /// `process::exit` because the unit tests drive `exec` into several of these paths and would
    /// otherwise take the test process down with them.
    failed: Cell<bool>,
    rule_keys: Nested<String>,
    /// Records how long each processing phase takes; printed per-phase only with `--debug`,
    /// with the accumulated total shown as "Elapsed time" in the results summary.
    checkpoint: CheckPointProcessTimer,
}

/// The stream-vs-buffer policy for detection results, applied at every detection site.
/// `stored_static.is_low_memory` is set for an unsorted csv/json timeline (the case that permits
/// streaming — it is broader than the explicit `--low-memory` flag): each batch is then emitted to
/// the writer immediately. Otherwise the records are buffered in `buffer` so they can be sorted and
/// written once at the end.
fn emit_or_buffer(
    log_records: &mut Vec<DetectInfo>,
    buffer: &mut Vec<DetectInfo>,
    stored_static: &StoredStatic,
    output_writer: &mut OutputWriter,
    result_state: &mut ResultOutputState,
) {
    if stored_static.is_low_memory {
        let empty_ids = HashSet::new();
        results::emit_csv(
            log_records,
            &empty_ids,
            stored_static,
            output_writer,
            result_state,
        );
    } else {
        buffer.append(log_records);
    }
}

/// Per-batch policy for `process_detection_batch`, as named fields so the two flags cannot be
/// swapped at a call site.
struct BatchPolicy {
    /// Run the detection rules on this batch (false for metrics / logon-summary / search commands,
    /// which do not detect).
    run_rules: bool,
    /// Widen the results-summary detection time span from this batch's hits. The evtx path does
    /// this; the JSON path does not.
    update_time_range: bool,
}

/// The inputs `create_rec_info` needs, built once per scanned file so the alias config (and rule
/// keys) are cloned a single time — into `Arc`s shared across every detection batch and per-record
/// task — instead of being re-cloned for each batch. The `Arc`s are cheap to clone into each task.
struct RecordBuildContext {
    rule_keys: Arc<Nested<String>>,
    eventkey_alias: Arc<EventKeyAliasConfig>,
    no_pwsh_field_extraction: bool,
}

/// Records the run's General Overview report header — the invoking command line and the analysis
/// start time. Shared by `exec` and its test so the two cannot drift.
fn add_general_overview_header(
    html_reporter: &mut HtmlReporter,
    analysis_start_time: DateTime<Local>,
) {
    let mut output_data = Nested::<String>::new();
    output_data.extend(vec![
        format!("- Command line: {}", env::args().join(" ")),
        format!(
            "- Start time: {}",
            analysis_start_time.format("%Y/%m/%d %H:%M")
        ),
    ]);
    html_reporter.add_md_data(htmlreport::GENERAL_OVERVIEW_SECTION, output_data);
}

/// Filter used by [`calculate_wizard_rule_count`] to select which loadable rules to tally.
struct WizardCountFilter<'a> {
    /// When true, count only the statuses listed in `exclude_noisy_status` (used for the
    /// deprecated/unsupported/noisy prompts); when false, those statuses are skipped unless
    /// `target_status` contains "*", in which case all statuses are counted.
    exclude_noisytarget_flag: bool,
    exclude_noisy_status: Vec<&'a str>,
    min_level: &'a str,
    target_status: Vec<&'a str>,
    target_tags: Vec<&'a str>,
}

/// Count the loadable rules per status (or per tag when `filter.target_tags` is non-empty) at or
/// above `filter.min_level`, based on `rule_counter_wizard_map` (keyed as status -> level -> tag
/// -> count). Promoted from the closure that was embedded in `analysis_files`'s scan wizard.
fn calculate_wizard_rule_count(
    rule_counter_wizard_map: &HashMap<
        CompactString,
        HashMap<CompactString, HashMap<CompactString, i128>>,
    >,
    filter: WizardCountFilter,
) -> HashMap<CompactString, i128> {
    let WizardCountFilter {
        exclude_noisytarget_flag,
        exclude_noisy_status,
        min_level,
        target_status,
        target_tags,
    } = filter;
    let mut ret = HashMap::new();
    if exclude_noisytarget_flag {
        for status in exclude_noisy_status {
            let mut ret_cnt = 0;
            if let Some(target_status_count) = rule_counter_wizard_map.get(status) {
                target_status_count.iter().for_each(|(rule_level, value)| {
                    let doc_level_num = LEVEL::from(rule_level.as_str()).index();
                    let args_level_num = LEVEL::from(min_level).index();
                    if doc_level_num >= args_level_num {
                        ret_cnt += value.iter().map(|(_, cnt)| cnt).sum::<i128>()
                    }
                });
            }
            if ret_cnt > 0 {
                ret.insert(CompactString::from(status), ret_cnt);
            }
        }
    } else {
        let all_status_flag = target_status.contains(&"*");
        for status in rule_counter_wizard_map.keys() {
            // Skip aggregation for items that do not match the specified status.
            if (exclude_noisy_status.contains(&status.as_str())
                || !target_status.contains(&status.as_str()))
                && !all_status_flag
            {
                continue;
            }
            let mut ret_cnt = 0;
            if let Some(target_status_count) = rule_counter_wizard_map.get(status) {
                target_status_count.iter().for_each(|(rule_level, value)| {
                    let doc_level_num = LEVEL::from(rule_level.as_str()).index();
                    let args_level_num = LEVEL::from(min_level).index();
                    if doc_level_num >= args_level_num {
                        if !target_tags.is_empty() {
                            for (tag, cnt) in value.iter() {
                                if target_tags.contains(&tag.as_str()) {
                                    let matched_tag_cnt = ret.entry(tag.clone());
                                    *matched_tag_cnt.or_insert(0) += cnt;
                                }
                            }
                        } else {
                            ret_cnt += value.iter().map(|(_, cnt)| cnt).sum::<i128>()
                        }
                    }
                });
                if ret_cnt > 0 {
                    ret.insert(status.clone(), ret_cnt);
                }
            }
        }
    }
    ret
}

/// Apply the ad-hoc channel filters used by the non-timeline subcommands: `logon-summary` and
/// `config-critical-systems` each narrow `evtx_files` to those containing their required
/// channels, and `log-metrics` applies its include/exclude channel/filename filters.
fn apply_channel_filters(
    mut evtx_files: Vec<PathBuf>,
    stored_static: &StoredStatic,
) -> Vec<PathBuf> {
    if stored_static.logon_summary_flag && !stored_static.json_input_flag {
        // Create a channel filter for the logon summary.
        let yaml_str = r#"
            detection:
                selection:
                    Channel:
                        - Security
                        - Microsoft-Windows-TerminalServices-Gateway/Operational
                        - Microsoft-Windows-TerminalServices-LocalSessionManager/Operational
                        - Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational
            "#;
        let yaml_data = YamlLoader::load_from_str(yaml_str);
        let node = RuleNode::new(
            "logon".to_string(),
            yaml_data.ok().unwrap_or_default().first().unwrap().clone(),
        );
        let rule_files = vec![node];
        let mut channel_filter = create_channel_filter(
            &evtx_files,
            &rule_files,
            stored_static.quiet_errors_flag,
            &stored_static.error_log_stack,
        );
        evtx_files.retain(|evtx_file| channel_filter.scannable_rule_exists(evtx_file));
    }

    if matches!(
        stored_static.config.action.as_ref().unwrap(),
        Action::ConfigCriticalSystems(_)
    ) {
        // Create a channel filter for config-critical-systems.
        let yaml_str = r#"
            detection:
                selection:
                    Channel: Security
            "#;
        let yaml_data = YamlLoader::load_from_str(yaml_str);
        let node = RuleNode::new(
            "config-critical-systems".to_string(),
            yaml_data.ok().unwrap_or_default().first().unwrap().clone(),
        );
        let rule_files = vec![node];
        let mut channel_filter = create_channel_filter(
            &evtx_files,
            &rule_files,
            stored_static.quiet_errors_flag,
            &stored_static.error_log_stack,
        );
        evtx_files.retain(|evtx_file| channel_filter.scannable_rule_exists(evtx_file));
    }

    if let Some(Action::LogMetrics(opt)) = &stored_static.config.action {
        evtx_files = filter_evtx_files(
            evtx_files,
            &opt.include_channel,
            &opt.include_filename,
            &opt.exclude_channel,
            &opt.exclude_filename,
            &stored_static.error_log_stack,
        );
    }
    evtx_files
}

/// Build the indicatif progress bar (spinner + bar) used for the per-file scan.
fn build_progress_bar(stored_static: &StoredStatic, file_count: u64) -> ProgressBar {
    // Build the indicatif progress bar template. In the colored branch, the doubled braces
    // in the format! call are escapes that produce literal braces, so the indicatif
    // placeholders like {elapsed_precise} survive intact while the spinner and bar are
    // wrapped in green truecolor escape sequences.
    let template = if stored_static.common_options.no_color {
        "[{elapsed_precise}] {human_pos} / {human_len} {spinner} [{bar:40}] {percent}%\n\n{msg}"
            .to_string()
    } else {
        let spinner = "{spinner}".truecolor(0, 255, 0).to_string();
        let bar = "{bar:40}".truecolor(0, 255, 0).to_string();
        format!(
            "[{{elapsed_precise}}] {{human_pos}} / {{human_len}} {spinner} [{bar}] {{percent}}%\n\n{{msg}}",
        )
    };

    let progress_style = ProgressStyle::with_template(&template)
        .unwrap()
        .progress_chars("=> ");

    let progress_bar =
        ProgressBar::with_draw_target(Some(file_count), ProgressDrawTarget::stdout_with_hz(10))
            .with_tab_width(55);
    progress_bar.set_style(progress_style);
    progress_bar
}
impl App {
    pub fn new(thread_number: Option<usize>) -> App {
        App {
            runtime: utils::create_tokio_runtime(thread_number),
            failed: Cell::new(false),
            rule_keys: Nested::<String>::new(),
            checkpoint: CheckPointProcessTimer::create_checkpoint_timer(),
        }
    }

    /// Dispatch and run the subcommand selected on the command line, then print the closing
    /// summary output (elapsed time, error log, HTML report, etc.).
    fn exec(&mut self, app: &mut Command, stored_static: &mut StoredStatic) {
        // sort-csv is pure CSV post-processing: it needs none of the rule/profile/evtx machinery
        // the other subcommands set up below, so handle it up front and return.
        if let Some(Action::SortCsv(opt)) = stored_static.config.action.clone() {
            sort_csv::sort_csv(&opt);
            return;
        }
        if stored_static.profiles.is_none() {
            return;
        }

        let mut html_reporter = HtmlReporter::new();
        let analysis_start_time: DateTime<Local> = Local::now();
        if stored_static.html_report_flag {
            add_general_overview_header(&mut html_reporter, analysis_start_time);
        }

        // Output subcommand help when no arguments are provided. Subcommands that work without arguments do not output help.
        let subcommand_name = Action::get_action_name(stored_static.config.action.as_ref());
        if stored_static.config.action.is_some()
            && !self.check_is_valid_args_num(stored_static.config.action.as_ref())
        {
            if !stored_static.common_options.quiet {
                self.output_logo(stored_static);
                write_color_buffer(&BufferWriter::stdout(ColorChoice::Always), None, "", true).ok();
            }
            app.find_subcommand(subcommand_name)
                .unwrap()
                .clone()
                .print_help()
                .ok();
            println!();
            return;
        }

        // Show usage when no arguments are provided.
        if stored_static.config.action.is_none() {
            if !stored_static.common_options.quiet {
                self.output_logo(stored_static);
                write_color_buffer(&BufferWriter::stdout(ColorChoice::Always), None, "", true).ok();
            }
            app.print_help().ok();
            println!();
            return;
        }

        // The CSV Output options only make sense for CSV output; reject them with a non-CSV -t.
        if let Some(Action::DfirTimeline(opt)) = &stored_static.config.action
            && !matches!(opt.output_type, OutputType::Csv)
        {
            // `-R, --remove-duplicate-data` is deliberately not in this list: it applies to every
            // output format. It only replaces a repeated field value with "DUP", which the JSON
            // writer implements too (`output_json_str`), and it is a field of the shared
            // `OutputOption` rather than of `DfirTimelineOption`. Grouping it with these two by
            // proximity would regress `json-timeline -R`, a supported v3 invocation.
            let mut csv_only = vec![];
            if opt.multiline {
                csv_only.push("-M, --multiline");
            }
            if opt.tab_separator {
                csv_only.push("-S, --tab-separator");
            }
            if !csv_only.is_empty() {
                AlertMessage::alert(&format!(
                    "The following option(s) only apply to CSV output and cannot be used with the selected -t, --output-type: {}",
                    csv_only.join(", ")
                ))
                .ok();
                self.failed.set(true);
                return;
            }
        }
        if !stored_static.common_options.quiet {
            self.output_logo(stored_static);
            write_color_buffer(&BufferWriter::stdout(ColorChoice::Always), None, "", true).ok();
            self.output_eggs(&format!(
                "{:02}/{:02}",
                analysis_start_time.month(),
                analysis_start_time.day()
            ));
        }
        let _guard = if !self.is_matched_architecture_and_binary() {
            Wow64RedirectionGuard::new()
        } else {
            None
        };

        if Path::new("encoded_rules.yml").exists() && Path::new("rules").exists() {
            println!(
                "You have the rules directory and encoded_rules.yml in your path. Please delete one of them."
            );
            println!();
            return;
        }

        // If the rules-config option was not specified (the path is still the default
        // ./rules/config), resolve it relative to the executable's directory so that running
        // Hayabusa from a different current directory does not cause errors.
        if stored_static.config_path == Path::new("./rules/config") {
            stored_static.config_path =
                check_setting_path(&CURRENT_EXE_PATH.to_path_buf(), "rules/config", true).unwrap();
        }

        let time_filter = TargetEventTime::new(stored_static);
        if !time_filter.is_parse_success() {
            return;
        }

        let _ = self.output_open_close_message("opening_messages.txt", stored_static);
        if let Action::ListContributors(_) = &stored_static.config.action.as_ref().unwrap() {
            self.print_contributors();
            return;
        }

        if stored_static.metrics_flag {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "Generating Event ID Metrics",
                true,
            )
            .ok();
            println!();
        }
        if stored_static.logon_summary_flag {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "Generating Logon Summary",
                true,
            )
            .ok();
            println!();
        }
        if stored_static.search_flag {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "Searching...",
                true,
            )
            .ok();
            println!();
        }

        if matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::ConfigCriticalSystems(_)
        ) {
            Self::prompt_critical_systems_config(stored_static);
        }

        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(0, 255, 0)),
                stored_static.common_options.no_color,
            ),
            "Start time: ",
            false,
        )
        .ok();
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            None,
            &format!("{}\n", analysis_start_time.format("%Y/%m/%d %H:%M")),
            false,
        )
        .ok();
        self.checkpoint.set_checkpoint(analysis_start_time);
        let target_extensions = if let Some(output_option) = stored_static.output_option.as_ref() {
            configs::get_target_extensions(
                output_option.detect_common_options.evtx_file_ext.as_ref(),
                stored_static.json_input_flag,
            )
        } else {
            HashSet::default()
        };
        let no_color = stored_static.common_options.no_color;
        let output_saved_file = |output_path: &Option<PathBuf>,
                                 message: &str,
                                 html_report_flag: &bool,
                                 html_reporter: &mut HtmlReporter| {
            if let Some(path) = output_path
                && let Ok(metadata) = fs::metadata(path)
            {
                let output_saved_str = format!("{message}:");
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    get_writable_color(Some(Color::Rgb(0, 255, 0)), no_color),
                    &output_saved_str,
                    false,
                )
                .ok();
                let file_str = format!(
                    " {} ({})",
                    path.display(),
                    ByteSize::b(metadata.len()).display()
                );
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    None,
                    &file_str,
                    true,
                )
                .ok();
                println!();
                output_and_data_stack_for_html(
                    &format!("{message}: {file_str}"),
                    htmlreport::GENERAL_OVERVIEW_SECTION,
                    html_report_flag,
                    html_reporter,
                );
            }
        };

        let action = stored_static.config.action.clone().unwrap();
        match &action {
            Action::DfirTimeline(_) => {
                // If the rules option was not specified (the path is still the default ./rules),
                // resolve it relative to the executable's directory so that running Hayabusa from
                // a different current directory does not cause errors.
                if stored_static.output_option.as_ref().unwrap().rules == Path::new("./rules") {
                    if Path::new("./encoded_rules.yml").exists() {
                        stored_static.output_option.as_mut().unwrap().rules = check_setting_path(
                            &CURRENT_EXE_PATH.to_path_buf(),
                            "encoded_rules.yml",
                            true,
                        )
                        .unwrap();
                    } else {
                        stored_static.output_option.as_mut().unwrap().rules =
                            check_setting_path(&CURRENT_EXE_PATH.to_path_buf(), "rules", true)
                                .unwrap();
                    }
                }
                // Check the rule config folder and files, and terminate if there are errors.
                if let Err(e) = utils::check_rule_config(&stored_static.config_path) {
                    AlertMessage::alert(&e).ok();
                    self.failed.set(true);
                    return;
                }
                if stored_static.profiles.is_none() {
                    return;
                }
                if let Some(html_path) = &stored_static.output_option.as_ref().unwrap().html_report
                {
                    // If an HTML report file with the same name already exists, output an alert message and exit.
                    if !stored_static
                        .output_option
                        .as_ref()
                        .unwrap()
                        .is_clobber_enabled()
                        && utils::check_file_expect_not_exist(
                            html_path.as_path(),
                            format!(
                                " The file {} already exists. Please specify a different filename or add the -C, --clobber option to overwrite.\n",
                                html_path.to_str().unwrap()
                            ),
                        )
                    {
                        return;
                    }
                }
                if let Some(path) = &stored_static.output_path
                    && !stored_static
                        .output_option
                        .as_ref()
                        .unwrap()
                        .is_clobber_enabled()
                    && utils::check_file_expect_not_exist(
                        path.as_path(),
                        format!(
                            " The file {} already exists. Please specify a different filename or add the -C, --clobber option to overwrite.\n",
                            path.as_os_str().to_str().unwrap()
                        ),
                    )
                {
                    return;
                }
                if stored_static.json_input_flag
                    && (stored_static.scan_all_evtx_files || stored_static.enable_all_rules)
                {
                    AlertMessage::alert("It is not necessary to specify -A (--enable-all-rules) or -a (--scan-all-evtx-files) with -J (--json-input) because the default channel filter only works with EVTX files.").ok();
                    println!();
                    self.failed.set(true);
                    return;
                }
                self.analysis_start(
                    &target_extensions,
                    &time_filter,
                    stored_static,
                    &mut html_reporter,
                );

                output_profile_name(
                    &stored_static.output_option,
                    false,
                    stored_static.common_options.no_color,
                    &mut html_reporter,
                );
                output_saved_file(
                    &stored_static.output_path,
                    "Saved file",
                    &stored_static.html_report_flag,
                    &mut html_reporter,
                );
            }
            Action::LogonSummary(_) => {
                let mut target_output_path = Nested::<String>::new();
                if let Some(path) = &stored_static.output_path {
                    for suffix in &["-successful.csv", "-failed.csv"] {
                        let output_file = format!("{}{suffix}", path.to_str().unwrap());
                        if !stored_static
                            .output_option
                            .as_ref()
                            .unwrap()
                            .is_clobber_enabled()
                            && utils::check_file_expect_not_exist(
                                Path::new(output_file.as_str()),
                                format!(
                                    " The files with a base name of {} already exist. Please specify a different base filename or add the -C, --clobber option to overwrite.\n",
                                    path.as_os_str().to_str().unwrap()
                                ),
                            )
                        {
                            return;
                        }
                        target_output_path.push(output_file);
                    }
                }
                self.analysis_start(
                    &target_extensions,
                    &time_filter,
                    stored_static,
                    &mut html_reporter,
                );
                for target_path in target_output_path.iter() {
                    let mut msg = "";
                    if target_path.ends_with("-successful.csv") {
                        msg = "Successful logon results"
                    }
                    if target_path.ends_with("-failed.csv") {
                        msg = "Failed logon results"
                    }
                    output_saved_file(
                        &Some(Path::new(target_path).to_path_buf()),
                        msg,
                        &stored_static.html_report_flag,
                        &mut html_reporter,
                    );
                }
                println!();
            }
            Action::EidMetrics(_)
            | Action::ComputerMetrics(_)
            | Action::LogMetrics(_)
            | Action::Search(_)
            | Action::ExtractBase64(_) => {
                if let Some(path) = &stored_static.output_path
                    && !stored_static
                        .output_option
                        .as_ref()
                        .unwrap()
                        .is_clobber_enabled()
                    && utils::check_file_expect_not_exist(
                        path.as_path(),
                        format!(
                            " The file {} already exists. Please specify a different filename or add the -C, --clobber option to overwrite.\n",
                            path.as_os_str().to_str().unwrap()
                        ),
                    )
                {
                    return;
                }
                self.analysis_start(
                    &target_extensions,
                    &time_filter,
                    stored_static,
                    &mut html_reporter,
                );
                output_saved_file(
                    &stored_static.output_path,
                    "Saved results",
                    &stored_static.html_report_flag,
                    &mut html_reporter,
                );
            }
            Action::PivotKeywordsList(_) => {
                // Resolve pivot_keywords.txt through the `-c` custom config directory (falling back
                // to the bundled copy), the same way every other config file is loaded, so that
                // `-c <dir>` can supply a custom pivot_keywords.txt (issue #1046).
                load_pivot_keywords(
                    resolve_config_file(&stored_static.config_path, "pivot_keywords.txt")
                        .to_str()
                        .unwrap(),
                    &stored_static.pivot_keyword,
                );
                if Path::new("./encoded_rules.yml").exists() {
                    stored_static.output_option.as_mut().unwrap().rules = check_setting_path(
                        &CURRENT_EXE_PATH.to_path_buf(),
                        "encoded_rules.yml",
                        true,
                    )
                    .unwrap();
                }

                // When outputting a file with the pivot feature, if a file with the same name already exists, output an error and terminate.
                let mut error_flag = false;
                if let Some(csv_path) = &stored_static.output_path {
                    let pivot_key_unions = stored_static.pivot_keyword.read().unwrap();
                    pivot_key_unions.iter().for_each(|(key, _)| {
                        let keywords_file_name =
                            csv_path.as_path().display().to_string() + "-" + key + ".txt";
                        if !stored_static.output_option.as_ref().unwrap().is_clobber_enabled() && utils::check_file_expect_not_exist(
                            Path::new(&keywords_file_name),
                            format!(
                                " The file {} already exists. Please specify a different filename or add the -C, --clobber option to overwrite.",
                                keywords_file_name
                            ),
                        ) {
                            error_flag = true
                        };
                    });
                }
                if error_flag {
                    println!();
                    return;
                }

                self.analysis_start(
                    &target_extensions,
                    &time_filter,
                    stored_static,
                    &mut html_reporter,
                );

                Self::run_pivot_keywords_output(stored_static);
            }
            Action::UpdateRules(_) => {
                self.run_update_rules(stored_static);
                return;
            }
            Action::LevelTuning(option) => {
                self.run_level_tuning(option, stored_static);
                return;
            }
            Action::SetDefaultProfile(_) => {
                self.run_set_default_profile(stored_static);
                return;
            }
            Action::ListProfiles(_) => {
                self.run_list_profiles(stored_static);
                return;
            }
            Action::ExpandList(opt) => {
                self.run_expand_list(opt, stored_static);
                return;
            }
            Action::ConfigCriticalSystems(_) => {
                self.analysis_start(
                    &target_extensions,
                    &time_filter,
                    stored_static,
                    &mut html_reporter,
                );
                let _ = self.output_open_close_message("closing_messages.txt", stored_static);
                return;
            }
            _ => {}
        }

        self.print_closing_summary(stored_static, &mut html_reporter);
    }

    fn prompt_critical_systems_config(stored_static: &StoredStatic) {
        let msg = "This command tries to find critical systems like domain controllers and file servers by checking for logs that should only exist in those systems.
It will search for Security 4768 (Kerberos TGT requested) events to determine if it is a domain controller.
It will search for Security 5145 (Network Share File Access) events to determine if it is a file server.
Any hostnames added to the critical_systems.txt file will have all alerts above low increased by one level with a maximum of emergency level.";
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(255, 175, 0)),
                stored_static.common_options.no_color,
            ),
            msg,
            true,
        )
        .ok();
        println!();
        let conf = &CURRENT_EXE_PATH.to_path_buf().join("config");
        if !conf.exists() {
            fs::create_dir(conf).ok();
        }
        let config_path = conf.join("critical_systems.txt");
        if !config_path.exists() {
            fs::write(&config_path, "").ok();
        }
        if let Ok(metadata) = fs::metadata(&config_path)
            && metadata.len() > 0
        {
            let color_theme = if stored_static.common_options.no_color {
                ColorfulTheme {
                    defaults_style: Style::new().for_stderr(),
                    prompt_style: Style::new().for_stderr().bold(),
                    prompt_prefix: style("?".to_string()).for_stderr(),
                    prompt_suffix: style("›".to_string()).for_stderr(),
                    success_prefix: style("✔".to_string()).for_stderr(),
                    success_suffix: style("·".to_string()).for_stderr(),
                    error_prefix: style("✘".to_string()).for_stderr(),
                    error_style: Style::new().for_stderr(),
                    hint_style: Style::new().for_stderr(),
                    values_style: Style::new().for_stderr(),
                    active_item_style: Style::new().for_stderr(),
                    inactive_item_style: Style::new().for_stderr(),
                    active_item_prefix: style("❯".to_string()).for_stderr(),
                    inactive_item_prefix: style(" ".to_string()).for_stderr(),
                    checked_item_prefix: style("✔".to_string()).for_stderr(),
                    unchecked_item_prefix: style("⬚".to_string()).for_stderr(),
                    picked_item_prefix: style("❯".to_string()).for_stderr(),
                    unpicked_item_prefix: style(" ".to_string()).for_stderr(),
                }
            } else {
                ColorfulTheme {
                    active_item_prefix: Style::new().color256(214).apply_to("❯".to_string()), // orange
                    checked_item_prefix: Style::new().color256(46).apply_to("✔".to_string()), // green
                    picked_item_prefix: Style::new().color256(214).apply_to("❯".to_string()), // orange
                    values_style: Style::new().color256(46), // green
                    prompt_prefix: Style::new().color256(160).apply_to("?".to_string()), // red
                    prompt_suffix: Style::new().color256(15).apply_to("›".to_string()), // white
                    prompt_style: Style::new().color256(160).bold(), // red
                    defaults_style: Style::new().color256(51), // cyan
                    hint_style: Style::new().color256(214),  // orange
                    success_prefix: Style::new().color256(46).apply_to("✔".to_string()), // green
                    success_suffix: Style::new().color256(15).apply_to("·".to_string()), // white
                    ..Default::default()
                }
            };
            let prompt_fmt = "Warning: the config/critical_systems.txt file is not empty. Would you like to erase the contents first?";
            let config_clear = Confirm::with_theme(&color_theme)
                .with_prompt(prompt_fmt)
                .default(true)
                .show_default(true)
                .interact()
                .unwrap();
            if config_clear {
                fs::write(config_path, "").expect("Failed to clear the file");
            }
            println!();
        }
    }

    fn run_pivot_keywords_output(stored_static: &StoredStatic) {
        let pivot_key_unions = stored_static.pivot_keyword.read().unwrap();
        if let Some(pivot_file) = &stored_static.output_path {
            // For file output
            pivot_key_unions.iter().for_each(|(key, pivot_keyword)| {
                let mut writer = BufWriter::new(
                    File::create(pivot_file.as_path().display().to_string() + "-" + key + ".txt")
                        .unwrap(),
                );
                writer
                    .write_all(
                        create_output(String::default(), key, pivot_keyword, "file", stored_static)
                            .as_bytes(),
                    )
                    .unwrap();
            });
            println!();
            println!();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                "Pivot keyword results were saved to the following files: ",
                true,
            )
            .ok();
            let mut output = "".to_string();
            pivot_key_unions.iter().for_each(|(key, _)| {
                writeln!(
                    output,
                    "{}",
                    (pivot_file.as_path().display().to_string() + "-" + key + ".txt")
                )
                .ok();
            });
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(None, stored_static.common_options.no_color),
                output.as_str(),
                true,
            )
            .ok();
        } else {
            // For standard output
            let output = "The following pivot keywords were found:";
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                output,
                true,
            )
            .ok();
            pivot_key_unions.iter().for_each(|(key, pivot_keyword)| {
                create_output(
                    String::default(),
                    key,
                    pivot_keyword,
                    "standard",
                    stored_static,
                );

                if pivot_keyword.keywords.is_empty() {
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(Some(Color::Red), stored_static.common_options.no_color),
                        "No keywords found\n",
                        true,
                    )
                    .ok();
                }
            });
        }
    }

    fn run_update_rules(&self, stored_static: &mut StoredStatic) {
        let update_target = match &stored_static.config.action.as_ref().unwrap() {
            Action::UpdateRules(option) => Some(option.rules.to_owned()),
            _ => None,
        };
        println!();
        // If an error occurs (e.g. no internet connection), ignore it and do not output
        // an error message.
        let latest_version_data = Update::get_latest_hayabusa_version().unwrap_or_default();
        let now_version = &format!("v{}", env!("CARGO_PKG_VERSION"));
        stored_static.include_status.insert("*".into());
        let rule_encoded =
            check_setting_path(&CURRENT_EXE_PATH.to_path_buf(), "encoded_rules.yml", true).unwrap();
        if rule_encoded.exists() {
            let url = "https://raw.githubusercontent.com/Yamato-Security/hayabusa-encoded-rules/main/encoded_rules.yml";
            match get(url).call() {
                Ok(mut res) => {
                    let mut dst = File::create(Path::new("./encoded_rules.yml")).unwrap();
                    dst.write_all(res.body_mut().read_to_vec().unwrap().as_slice())
                        .unwrap();
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(
                            Some(Color::Rgb(255, 175, 0)),
                            stored_static.common_options.no_color,
                        ),
                        "Rules file encoded_rules.yml updated successfully.",
                        true,
                    )
                    .ok();
                }
                Err(_) => {
                    AlertMessage::alert("Failed to update rules.").ok();
                }
            }

            if !ONE_CONFIG_MAP.is_empty() {
                let url = "https://raw.githubusercontent.com/Yamato-Security/hayabusa-encoded-rules/refs/heads/main/rules_config_files.txt";
                match get(url).call() {
                    Ok(mut res) => {
                        let mut dst = File::create(Path::new("./rules_config_files.txt")).unwrap();
                        dst.write_all(res.body_mut().read_to_string().unwrap().as_bytes())
                            .unwrap();
                        write_color_buffer(
                            &BufferWriter::stdout(ColorChoice::Always),
                            get_writable_color(
                                Some(Color::Rgb(255, 175, 0)),
                                stored_static.common_options.no_color,
                            ),
                            "Config file rules_config_files.txt updated successfully.",
                            true,
                        )
                        .ok();
                    }
                    Err(_) => {
                        AlertMessage::alert("Failed to update config file.").ok();
                    }
                }
            }
        } else {
            match Update::update_rules(update_target.unwrap().to_str().unwrap(), stored_static) {
                Ok(output) => {
                    if output != "You currently have the latest rules." {
                        write_color_buffer(
                            &BufferWriter::stdout(ColorChoice::Always),
                            get_writable_color(
                                Some(Color::Rgb(255, 175, 0)),
                                stored_static.common_options.no_color,
                            ),
                            "Rules updated successfully.",
                            true,
                        )
                        .ok();
                    }
                }
                Err(e) => {
                    if e.message().is_empty() {
                        AlertMessage::alert("Failed to update rules.").ok();
                    } else {
                        AlertMessage::alert(&format!("Failed to update rules. {e:?}  ")).ok();
                    }
                }
            }
        }
        let split_now_version = &now_version
            .replace("-dev", "")
            .replace("v", "")
            .split('.')
            .filter_map(|part| part.parse().ok())
            .collect::<Vec<i8>>();
        let split_latest_version = &latest_version_data
            .as_ref()
            .unwrap_or(now_version)
            .replace('"', "")
            .replace("v", "")
            .split('.')
            .filter_map(|part| part.parse().ok())
            .collect::<Vec<i8>>();
        if split_latest_version > split_now_version {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                &format!(
                    "There is a new version of Hayabusa: {}",
                    latest_version_data.unwrap().replace('\"', "")
                ),
                true,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "You can download it at https://github.com/Yamato-Security/hayabusa/releases",
                true,
            )
            .ok();
        }
        println!();
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);
    }

    fn run_level_tuning(
        &self,
        option: &configs::LevelTuningOption,
        stored_static: &mut StoredStatic,
    ) {
        let level_tuning_config_path =
            if option.level_tuning.to_str().unwrap() != "./rules/config/level_tuning.txt" {
                check_setting_path(
                    option
                        .level_tuning
                        .parent()
                        .unwrap_or_else(|| Path::new("")),
                    option
                        .level_tuning
                        .file_name()
                        .unwrap()
                        .to_str()
                        .unwrap_or_default(),
                    false,
                )
                .unwrap_or_else(|| {
                    check_setting_path(
                        &CURRENT_EXE_PATH.to_path_buf(),
                        "rules/config/level_tuning.txt",
                        true,
                    )
                    .unwrap()
                })
                .display()
                .to_string()
            } else {
                check_setting_path(&stored_static.config_path, "level_tuning.txt", false)
                    .unwrap_or_else(|| {
                        check_setting_path(
                            &CURRENT_EXE_PATH.to_path_buf(),
                            "rules/config/level_tuning.txt",
                            true,
                        )
                        .unwrap()
                    })
                    .display()
                    .to_string()
            };

        let rules_path = if stored_static.output_option.as_ref().is_some() {
            stored_static
                .output_option
                .as_ref()
                .unwrap()
                .rules
                .as_os_str()
                .to_str()
                .unwrap()
        } else {
            "./rules"
        };

        if Path::new(&level_tuning_config_path).exists() {
            stored_static.include_status.insert("*".into());
            if let Err(err) = LevelTuning::run(&level_tuning_config_path, rules_path, stored_static)
            {
                AlertMessage::alert(&err).ok();
            }
        } else {
            AlertMessage::alert(
                        "Need rule_levels.txt file to use --level-tuning option [default: ./rules/config/level_tuning.txt]",
                    )
                    .ok();
        }
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);
    }

    fn run_set_default_profile(&self, stored_static: &StoredStatic) {
        println!();
        let is_existed_config_path =
            CURRENT_EXE_PATH.to_path_buf().join("config").exists() || Path::new("config").exists();
        if !is_existed_config_path {
            println!(
                "Default profile cannot be set due to the absence of a config folder. Please check the config folder."
            );
            return;
        }
        if let Err(e) = set_default_profile(
            check_setting_path(
                &CURRENT_EXE_PATH.to_path_buf(),
                "config/default_profile.yaml",
                true,
            )
            .unwrap()
            .to_str()
            .unwrap(),
            check_setting_path(
                &CURRENT_EXE_PATH.to_path_buf(),
                "config/profiles.yaml",
                true,
            )
            .unwrap()
            .to_str()
            .unwrap(),
            stored_static,
        ) {
            AlertMessage::alert(&e).ok();
        }
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);
    }

    fn run_list_profiles(&self, stored_static: &StoredStatic) {
        let profile_list = options::profile::get_profile_list("config/profiles.yaml");
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(0, 255, 0)),
                stored_static.common_options.no_color,
            ),
            "List of available profiles:",
            true,
        )
        .ok();
        for profile in profile_list.iter() {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                Some(Color::Rgb(0, 255, 0)),
                &format!("- {:<25}", format!("{}:", profile[0])),
                false,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                None,
                &profile[1],
                true,
            )
            .ok();
        }
        println!();
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);
    }

    fn run_expand_list(&self, opt: &configs::ExpandListOption, stored_static: &StoredStatic) {
        let encoded_rule_dir = Path::new("./encoded_rules.yml");
        let rule_dir = if encoded_rule_dir.exists() {
            &encoded_rule_dir.to_path_buf()
        } else {
            &opt.rules
        };
        // Terminate with an alert if the rules directory does not exist.
        if !rule_dir.exists() {
            AlertMessage::alert("The rules directory does not exist. Please check the path.").ok();
            self.failed.set(true);
            return;
        }
        println!();
        let result = expand_list(rule_dir);
        let result: Vec<&String> = result.iter().collect();
        if result.is_empty() {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "No expanded rules found.",
                true,
            )
            .ok();
        } else {
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                &format!("{:?} unique expand placeholders found:", result.len()),
                true,
            )
            .ok();
            for expand in result {
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    None,
                    &expand.replace("%", ""),
                    true,
                )
                .ok();
            }
        }
        println!();
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);
    }

    fn print_closing_summary(
        &self,
        stored_static: &StoredStatic,
        html_reporter: &mut HtmlReporter,
    ) {
        // Output processing time.
        let elapsed_output_str = self.checkpoint.calculate_all_stocked_results();
        output_and_data_stack_for_html(
            &format!("Elapsed time: {elapsed_output_str}"),
            htmlreport::GENERAL_OVERVIEW_SECTION,
            &stored_static.html_report_flag,
            html_reporter,
        );
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(0, 255, 0)),
                stored_static.common_options.no_color,
            ),
            "Elapsed time: ",
            false,
        )
        .ok();
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            None,
            elapsed_output_str.as_str(),
            true,
        )
        .ok();
        if let Some(Action::DfirTimeline(_)) = stored_static.config.action {
            println!();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                "Please report any issues with Hayabusa rules to: ",
                false,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(None, stored_static.common_options.no_color),
                "https://github.com/Yamato-Security/hayabusa-rules/issues",
                true,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                "Please report any false positives with Sigma rules to: ",
                false,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(None, stored_static.common_options.no_color),
                "https://github.com/SigmaHQ/sigma/issues",
                true,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(0, 255, 0)),
                    stored_static.common_options.no_color,
                ),
                "Please submit new Sigma rules with pull requests to: ",
                false,
            )
            .ok();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                None,
                "https://github.com/SigmaHQ/sigma/pulls",
                true,
            )
            .ok();
            if stored_static.html_report_flag {
                let html_str = html_reporter.create_html();
                htmlreport::create_html_file(
                    html_str,
                    stored_static
                        .output_option
                        .as_ref()
                        .unwrap()
                        .html_report
                        .as_ref()
                        .unwrap()
                        .to_str()
                        .unwrap_or(""),
                    stored_static.common_options.no_color,
                )
            }
        }

        // If the -Q option is specified or there are no parse errors, the error stack is 0 and no error log file is generated.
        if !stored_static.error_log_stack.lock().unwrap().is_empty() {
            AlertMessage::create_error_log(
                stored_static.quiet_errors_flag,
                stored_static.common_options.no_color,
                &stored_static.error_log_stack,
            );
        }
        println!();
        let _ = self.output_open_close_message("closing_messages.txt", stored_static);

        // When the debug flag is set, output statistics such as memory usage to the screen.
        if stored_static.config.debug {
            self.checkpoint.output_stocked_result();
            println!();
            println!("Memory usage stats:");
            unsafe {
                mi_stats_print_out(None, null_mut());
            }
        }
    }

    /// Determine the input source (live analysis, directory tree, or single file), collect the
    /// target files, and start the analysis.
    fn analysis_start(
        &mut self,
        target_extensions: &HashSet<String>,
        time_filter: &TargetEventTime,
        stored_static: &mut StoredStatic,
        html_reporter: &mut HtmlReporter,
    ) {
        if stored_static.output_option.is_none() {
        } else if let Some(output_option) = stored_static.output_option.as_ref()
            && output_option.input_args.live_analysis
        {
            let live_analysis_list =
                self.collect_liveanalysis_files(target_extensions, stored_static);
            if live_analysis_list.is_none() {
                return;
            }
            self.analysis_files(
                live_analysis_list.unwrap(),
                time_filter,
                stored_static.borrow_mut(),
                html_reporter,
            );
        } else if let Some(output_option) = &stored_static.output_option.as_ref()
            && let Some(directories) = &output_option.input_args.directory
        {
            let mut evtx_files = Vec::new();
            for directory in directories {
                evtx_files.extend(Self::collect_evtxfiles(
                    directory.as_os_str().to_str().unwrap(),
                    target_extensions,
                    stored_static,
                ));
            }
            if evtx_files.is_empty() {
                AlertMessage::alert("No .evtx files were found.").ok();
                self.failed.set(true);
                return;
            }
            self.analysis_files(
                evtx_files,
                time_filter,
                stored_static.borrow_mut(),
                html_reporter,
            );
        } else {
            // For cases other than directory and live_analysis, a filepath is specified.
            if let Some(input_args) = &stored_static.output_option.as_ref()
                && let Some(filepath) = &input_args.input_args.filepath
            {
                let mut replaced_filepath = filepath.display().to_string();
                if replaced_filepath.starts_with('"') {
                    replaced_filepath.remove(0);
                }
                if replaced_filepath.ends_with('"') {
                    replaced_filepath.remove(replaced_filepath.len() - 1);
                }
                let check_path = Path::new(&replaced_filepath);
                if !check_path.exists() {
                    AlertMessage::alert(&format!(
                        " The file {} does not exist. Please specify a valid file path.",
                        filepath.as_os_str().to_str().unwrap()
                    ))
                    .ok();
                    self.failed.set(true);
                    return;
                }
                if !target_extensions.contains(
                    check_path
                        .extension()
                        .unwrap_or_else(|| OsStr::new("."))
                        .to_str()
                        .unwrap(),
                ) || check_path
                    .file_stem()
                    .unwrap_or_else(|| OsStr::new("."))
                    .to_str()
                    .unwrap()
                    .trim()
                    .starts_with('.')
                {
                    AlertMessage::alert(
                        "-f (--filepath) only accepts .evtx files. Hidden files are ignored. If you want to input event logs in JSON format, please specify -J (--json-input).",
                    )
                    .ok();
                    self.failed.set(true);
                    return;
                }
                self.analysis_files(
                    vec![check_path.to_path_buf()],
                    time_filter,
                    stored_static.borrow_mut(),
                    html_reporter,
                );
            }
        }
    }

    #[cfg(not(target_os = "windows"))]
    fn collect_liveanalysis_files(
        &self,
        _target_extensions: &HashSet<String>,
        _stored_static: &StoredStatic,
    ) -> Option<Vec<PathBuf>> {
        AlertMessage::alert("-l, --live-analysis needs to be run as Administrator on Windows.")
            .ok();
        println!();
        None
    }

    #[cfg(target_os = "windows")]
    fn collect_liveanalysis_files(
        &self,
        target_extensions: &HashSet<String>,
        stored_static: &StoredStatic,
    ) -> Option<Vec<PathBuf>> {
        if is_elevated() {
            let log_dir = env::var("windir").expect("windir is not found");
            let evtx_files = Self::collect_evtxfiles(
                &[log_dir, "System32\\winevt\\Logs".to_string()].join("/"),
                target_extensions,
                stored_static,
            );
            if evtx_files.is_empty() {
                AlertMessage::alert("No .evtx files were found.").ok();
                return None;
            }
            Some(evtx_files)
        } else {
            AlertMessage::alert("-l, --live-analysis needs to be run as Administrator on Windows.")
                .ok();
            println!();
            None
        }
    }

    /// Recursively collect files under `dir_path` whose extension is one of `target_extensions`,
    /// skipping hidden files (names starting with a dot). The files are returned in sorted path
    /// order, independent of the order in which the filesystem lists them.
    fn collect_evtxfiles(
        dir_path: &str,
        target_extensions: &HashSet<String>,
        stored_static: &StoredStatic,
    ) -> Vec<PathBuf> {
        let mut dirpath = dir_path.to_string();
        if dirpath.starts_with('"') {
            dirpath.remove(0);
        }
        if dirpath.ends_with('"') {
            dirpath.remove(dirpath.len() - 1);
        }
        let entries = fs::read_dir(dirpath);
        if let Err(e) = &entries {
            let mut errmsg = format!("{}", e);
            if errmsg.ends_with("123)") {
                errmsg = format!(
                    "{errmsg}. You may not be able to load evtx files when there are spaces in the directory path. Please enclose the path with double quotes and remove any trailing slash at the end of the path."
                );
            }
            if stored_static.verbose_flag {
                AlertMessage::alert(&errmsg).ok();
            }
            if !stored_static.quiet_errors_flag {
                stored_static
                    .error_log_stack
                    .lock()
                    .unwrap()
                    .push(format!("[ERROR] {errmsg}"));
            }
            return vec![];
        }

        // Visit the entries in sorted order. `read_dir` order depends on the filesystem, and an
        // unsorted timeline is written in scan order, so without this the same logs could produce
        // a differently ordered timeline on another OS or filesystem. `PathBuf` compares
        // component-wise, so sorting each directory level yields a fully sorted file list.
        let mut paths: Vec<PathBuf> = entries
            .unwrap()
            .filter_map(|entry| entry.ok().map(|entry| entry.path()))
            .collect();
        paths.sort();

        let mut ret = vec![];
        for path in paths {
            if path.is_dir() {
                path.to_str().map(|path_str| {
                    let subdir_ret =
                        Self::collect_evtxfiles(path_str, target_extensions, stored_static);
                    ret.extend(subdir_ret);
                    Some(())
                });
            } else if target_extensions.contains(
                path.extension()
                    .unwrap_or_else(|| OsStr::new(""))
                    .to_str()
                    .unwrap(),
            ) && !path
                .file_stem()
                .unwrap_or_else(|| OsStr::new("."))
                .to_str()
                .unwrap()
                .starts_with('.')
            {
                ret.push(path);
            }
        }

        ret
    }

    fn print_contributors(&self) {
        let contributors = Contributors::get("contributors.txt").unwrap();
        let content = std::str::from_utf8(contributors.data.as_ref()).unwrap_or_default();

        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            None,
            content,
            true,
        )
        .ok();
    }

    /// Show the interactive rule-set wizard (Core / Core+ / Core++ / All) when it is enabled
    /// for the current action, prompt for emerging-threats / threat-hunting / deprecated /
    /// unsupported / noisy / sysmon rule inclusion, and apply the choices to `stored_static`.
    /// Returns the selected rule-set label for the HTML report, or `None` when it did not run.
    fn run_scan_wizard(&mut self, stored_static: &mut StoredStatic) -> Option<String> {
        let mut status_append_output = None;
        let need_wizard = matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::DfirTimeline(_) | Action::PivotKeywordsList(_)
        ) && !stored_static.output_option.as_ref().unwrap().no_wizard;
        if need_wizard {
            self.checkpoint.lap_checkpoint("Rule Parse Processing Time");
            let mut rule_counter_wizard_map = HashMap::new();
            yaml::count_rules(
                &stored_static.output_option.as_ref().unwrap().rules,
                &filter::exclude_ids(stored_static),
                stored_static,
                &mut rule_counter_wizard_map,
            );
            println!();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                Some(Color::Rgb(0, 255, 0)),
                "Scan wizard:",
                true,
            )
            .ok();
            let selections_status = &[
                (
                    "1. Core ( status: test, stable | level: high, critical )",
                    (vec!["test", "stable"], "high"),
                ),
                (
                    "2. Core+ ( status: test, stable | level: medium, high, critical )",
                    (vec!["test", "stable"], "medium"),
                ),
                (
                    "3. Core++ ( status: experimental, test, stable | level: medium, high, critical )",
                    (vec!["experimental", "test", "stable"], "medium"),
                ),
                (
                    "4. All alert rules ( status: * | level: low+ )",
                    (vec!["*"], "low"),
                ),
                (
                    "5. All event and alert rules ( status: * | level: informational+ )",
                    (vec!["*"], "informational"),
                ),
            ];

            let sections_rule_cnt = selections_status
                .iter()
                .map(|(_, (status, min_level))| {
                    calculate_wizard_rule_count(
                        &rule_counter_wizard_map,
                        WizardCountFilter {
                            exclude_noisytarget_flag: false,
                            exclude_noisy_status: [
                                "excluded",
                                "deprecated",
                                "unsupported",
                                "noisy",
                            ]
                            .to_vec(),
                            min_level,
                            target_status: status.to_vec(),
                            target_tags: [].to_vec(),
                        },
                    )
                })
                .collect_vec();
            let selection_status_items = &[
                format!(
                    "1. Core ({} rules) ( status: test, stable | level: high, critical )",
                    (sections_rule_cnt[0]
                        .iter()
                        .map(|(_, cnt)| cnt)
                        .sum::<i128>()
                        - sections_rule_cnt[0].get("excluded").unwrap_or(&0))
                    .to_formatted_string(&Locale::en)
                ),
                format!(
                    "2. Core+ ({} rules) ( status: test, stable | level: medium, high, critical )",
                    (sections_rule_cnt[1]
                        .iter()
                        .map(|(_, cnt)| cnt)
                        .sum::<i128>()
                        - sections_rule_cnt[1].get("excluded").unwrap_or(&0))
                    .to_formatted_string(&Locale::en)
                ),
                format!(
                    "3. Core++ ({} rules) ( status: experimental, test, stable | level: medium, high, critical )",
                    (sections_rule_cnt[2]
                        .iter()
                        .map(|(_, cnt)| cnt)
                        .sum::<i128>()
                        - sections_rule_cnt[2].get("excluded").unwrap_or(&0))
                    .to_formatted_string(&Locale::en)
                ),
                format!(
                    "4. All alert rules ({} rules) ( status: * | level: low+ )",
                    (sections_rule_cnt[3]
                        .iter()
                        .map(|(_, cnt)| cnt)
                        .sum::<i128>()
                        - sections_rule_cnt[3].get("excluded").unwrap_or(&0))
                    .to_formatted_string(&Locale::en)
                ),
                format!(
                    "5. All event and alert rules ({} rules) ( status: * | level: informational+ )",
                    (sections_rule_cnt[4]
                        .iter()
                        .map(|(_, cnt)| cnt)
                        .sum::<i128>()
                        - sections_rule_cnt[4].get("excluded").unwrap_or(&0))
                    .to_formatted_string(&Locale::en)
                ),
            ];

            let color_theme = if stored_static.common_options.no_color {
                ColorfulTheme {
                    defaults_style: Style::new().for_stderr(),
                    prompt_style: Style::new().for_stderr().bold(),
                    prompt_prefix: style("?".to_string()).for_stderr(),
                    prompt_suffix: style("›".to_string()).for_stderr(),
                    success_prefix: style("✔".to_string()).for_stderr(),
                    success_suffix: style("·".to_string()).for_stderr(),
                    error_prefix: style("✘".to_string()).for_stderr(),
                    error_style: Style::new().for_stderr(),
                    hint_style: Style::new().for_stderr(),
                    values_style: Style::new().for_stderr(),
                    active_item_style: Style::new().for_stderr(),
                    inactive_item_style: Style::new().for_stderr(),
                    active_item_prefix: style("❯".to_string()).for_stderr(),
                    inactive_item_prefix: style(" ".to_string()).for_stderr(),
                    checked_item_prefix: style("✔".to_string()).for_stderr(),
                    unchecked_item_prefix: style("⬚".to_string()).for_stderr(),
                    picked_item_prefix: style("❯".to_string()).for_stderr(),
                    unpicked_item_prefix: style(" ".to_string()).for_stderr(),
                }
            } else {
                ColorfulTheme {
                    active_item_prefix: Style::new().color256(214).apply_to("❯".to_string()), // orange
                    checked_item_prefix: Style::new().color256(46).apply_to("✔".to_string()), // green
                    picked_item_prefix: Style::new().color256(214).apply_to("❯".to_string()), // orange
                    values_style: Style::new().color256(46), // green
                    prompt_prefix: Style::new().color256(214).apply_to("?".to_string()), // orange
                    prompt_suffix: Style::new().color256(15).apply_to("›".to_string()), // white
                    defaults_style: Style::new().color256(51), // cyan
                    hint_style: Style::new().color256(214),  // orange
                    success_prefix: Style::new().color256(46).apply_to("✔".to_string()), // green
                    success_suffix: Style::new().color256(15).apply_to("·".to_string()), // white
                    error_prefix: Style::new().color256(9).apply_to("✘".to_string()), // red
                    ..Default::default()
                }
            };
            let selected_index = Select::with_theme(&color_theme)
                .with_prompt("Which set of detection rules would you like to load?")
                .default(0)
                .items(selection_status_items.as_slice())
                .interact()
                .unwrap();
            // Store just the selected rule-set label here; the HTML-report block below adds the
            // "- Selected detection rule set: " prefix when it renders this line.
            status_append_output = Some(selections_status[selected_index].0.to_string());
            stored_static.output_option.as_mut().unwrap().min_level =
                selections_status[selected_index].1.1.into();

            let exclude_noisy_cnt = calculate_wizard_rule_count(
                &rule_counter_wizard_map,
                WizardCountFilter {
                    exclude_noisytarget_flag: true,
                    exclude_noisy_status: ["excluded", "noisy", "deprecated", "unsupported"]
                        .to_vec(),
                    min_level: selections_status[selected_index].1.1,
                    target_status: [].to_vec(),
                    target_tags: [].to_vec(),
                },
            );

            stored_static.include_status.extend(
                selections_status[selected_index]
                    .1
                    .0
                    .iter()
                    .map(|x| x.to_owned().into()),
            );

            let mut output_option = stored_static.output_option.clone().unwrap();
            let exclude_tags = output_option.exclude_tag.get_or_insert_with(Vec::new);
            let tags_cnt = calculate_wizard_rule_count(
                &rule_counter_wizard_map,
                WizardCountFilter {
                    exclude_noisytarget_flag: false,
                    exclude_noisy_status: [].to_vec(),
                    min_level: selections_status[selected_index].1.1,
                    target_status: selections_status[selected_index].1.0.clone(),
                    target_tags: [
                        "detection.emerging_threats",
                        "detection.threat_hunting",
                        "sysmon",
                    ]
                    .to_vec(),
                },
            );
            // If anything other than "4. All alert rules" or "5. All event and alert rules" was selected, ask questions about tags.
            if selected_index < 3 {
                if let Some(emerging_threats_count) = tags_cnt.get("detection.emerging_threats") {
                    let prompt_fmt = format!(
                        "Include Emerging Threats rules? ({} rules)",
                        emerging_threats_count.to_formatted_string(&Locale::en)
                    );
                    let et_rules_load_flag = Confirm::with_theme(&color_theme)
                        .with_prompt(prompt_fmt)
                        .default(true)
                        .show_default(true)
                        .interact()
                        .unwrap();
                    // If no is selected, then add "--exclude-tags detection.emerging_threats"
                    if !et_rules_load_flag {
                        exclude_tags.push("detection.emerging_threats".into());
                    }
                }
                if let Some(threat_hunting_count) = tags_cnt.get("detection.threat_hunting") {
                    let prompt_fmt = format!(
                        "Include Threat Hunting rules? ({} rules)",
                        threat_hunting_count.to_formatted_string(&Locale::en)
                    );
                    let th_rules_load_flag = Confirm::with_theme(&color_theme)
                        .with_prompt(prompt_fmt)
                        .default(false)
                        .show_default(true)
                        .interact()
                        .unwrap();
                    // If no is selected, then add "--exclude-tags detection.threat_hunting"
                    if !th_rules_load_flag {
                        exclude_tags.push("detection.threat_hunting".into());
                    }
                }
            } else {
                // If "4. All alert rules" or "5. All event and alert rules" was selected, ask questions about deprecated and unsupported rules.
                if let Some(dep_cnt) = exclude_noisy_cnt.get("deprecated") {
                    // Prompt whether to load deprecated rules.
                    let prompt_fmt = format!(
                        "Include deprecated rules? ({} rules)",
                        dep_cnt.to_formatted_string(&Locale::en)
                    );
                    let dep_rules_load_flag = Confirm::with_theme(&color_theme)
                        .with_prompt(prompt_fmt)
                        .default(false)
                        .show_default(true)
                        .interact()
                        .unwrap();
                    if dep_rules_load_flag {
                        stored_static
                            .output_option
                            .as_mut()
                            .unwrap()
                            .enable_deprecated_rules = true;
                    }
                }
                if let Some(unsup_cnt) = exclude_noisy_cnt.get("unsupported") {
                    // Prompt whether to load unsupported rules.
                    let prompt_fmt = format!(
                        "Include unsupported rules? ({} rules)",
                        unsup_cnt.to_formatted_string(&Locale::en)
                    );
                    let unsupported_rules_load_flag = Confirm::with_theme(&color_theme)
                        .with_prompt(prompt_fmt)
                        .default(false)
                        .show_default(true)
                        .interact()
                        .unwrap();
                    if unsupported_rules_load_flag {
                        stored_static
                            .output_option
                            .as_mut()
                            .unwrap()
                            .enable_unsupported_rules = true;
                    }
                }
            }

            self.checkpoint.set_checkpoint(Local::now());

            if let Some(noisy_cnt) = exclude_noisy_cnt.get("noisy") {
                // Prompt whether to load noisy rules.
                let prompt_fmt = format!(
                    "Include noisy rules? ({} rules)",
                    noisy_cnt.to_formatted_string(&Locale::en)
                );
                let noisy_rules_load_flag = Confirm::with_theme(&color_theme)
                    .with_prompt(prompt_fmt)
                    .default(false)
                    .show_default(true)
                    .interact()
                    .unwrap();
                if noisy_rules_load_flag {
                    stored_static
                        .output_option
                        .as_mut()
                        .unwrap()
                        .enable_noisy_rules = true;
                }
            }

            if let Some(sysmon_cnt) = tags_cnt.get("sysmon") {
                let prompt_fmt = format!(
                    "Include sysmon rules? ({} rules)",
                    sysmon_cnt.to_formatted_string(&Locale::en)
                );
                let sysmon_rules_load_flag = Confirm::with_theme(&color_theme)
                    .with_prompt(prompt_fmt)
                    .default(true)
                    .show_default(true)
                    .interact()
                    .unwrap();

                // If no is selected, then add "--exclude-tags sysmon"
                if !sysmon_rules_load_flag {
                    exclude_tags.push("sysmon".into());
                }
            }

            if !exclude_tags.is_empty() {
                stored_static.output_option.as_mut().unwrap().exclude_tag =
                    Some(exclude_tags.to_owned());
            }
        } else if stored_static.include_status.is_empty() {
            stored_static.include_status.insert("*".into());
        }
        status_append_output
    }

    /// Run the scan over the collected files: show the rule-set wizard if enabled, load and
    /// filter the detection rules, apply channel filters, analyze each file, and emit the
    /// results.
    fn analysis_files(
        &mut self,
        mut evtx_files: Vec<PathBuf>,
        time_filter: &TargetEventTime,
        stored_static: &mut StoredStatic,
        html_reporter: &mut HtmlReporter,
    ) {
        let target_level = stored_static
            .output_option
            .as_ref()
            .unwrap()
            .exact_level
            .as_ref()
            .unwrap_or(&String::default())
            .to_uppercase();
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(0, 255, 0)),
                stored_static.common_options.no_color,
            ),
            "Total event log files: ",
            false,
        )
        .ok();
        let log_files = &evtx_files.len().to_formatted_string(&Locale::en);
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            None,
            log_files,
            true,
        )
        .ok();
        let mut total_file_size = ByteSize::b(0);
        for file_path in &evtx_files {
            let file_size = get_file_size(
                file_path,
                stored_static.verbose_flag,
                stored_static.quiet_errors_flag,
                &stored_static.error_log_stack,
            );
            total_file_size += ByteSize::b(file_size);
        }
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            get_writable_color(
                Some(Color::Rgb(0, 255, 0)),
                stored_static.common_options.no_color,
            ),
            "Total file size: ",
            false,
        )
        .ok();
        let total_size = total_file_size;
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            None,
            &total_file_size.display().to_string(),
            true,
        )
        .ok();
        let status_append_output = self.run_scan_wizard(stored_static);
        let event_timeline_config = &stored_static.event_timeline_config;
        let target_event_ids = &stored_static.target_eventids;

        if stored_static.html_report_flag {
            let mut output_data = Nested::<String>::new();
            let mut html_report_data = Nested::<String>::from_iter(vec![
                format!(
                    "- Analyzed event files: {}",
                    evtx_files.len().to_formatted_string(&Locale::en)
                ),
                format!("- Total file size: {total_size}"),
            ]);
            if let Some(status_report) = status_append_output {
                html_report_data.push(format!("- Selected detection rule set: {status_report}"));
            }
            let exclude_tags_data = stored_static
                .output_option
                .as_ref()
                .unwrap()
                .exclude_tag
                .clone()
                .unwrap_or_default()
                .join(" / ");
            if !exclude_tags_data.is_empty() {
                html_report_data.push(format!("- Excluded tags: {exclude_tags_data}"));
            }
            output_data.extend(html_report_data.iter());
            html_reporter.add_md_data(htmlreport::GENERAL_OVERVIEW_SECTION, output_data);
        }

        let level = stored_static
            .output_option
            .as_ref()
            .unwrap()
            .min_level
            .to_uppercase();
        let mut wait_message = "";
        if matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::DfirTimeline(_) | Action::PivotKeywordsList(_)
        ) {
            wait_message = "Loading detection rules. Please wait.";
        } else if stored_static.logon_summary_flag {
            wait_message = "Currently scanning for the logon summary. Please wait.";
        } else if stored_static.search_flag {
            wait_message = "Currently searching. Please wait.";
        } else if stored_static.metrics_flag {
            wait_message = "Currently scanning for event ID metrics. Please wait.";
        } else if stored_static.computer_metrics_flag {
            wait_message = "Currently scanning for computer metrics. Please wait.";
        } else if stored_static.log_metrics_flag {
            wait_message = "Currently scanning for log metrics. Please wait.";
        }
        if !wait_message.is_empty() {
            println!();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                wait_message,
                true,
            )
            .ok();
        }
        println!();

        let mut rule_files = vec![];
        let need_rules = matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::DfirTimeline(_) | Action::PivotKeywordsList(_)
        );
        if need_rules {
            rule_files = detection::Detection::parse_rule_files(
                &level,
                &target_level,
                &stored_static.output_option.as_ref().unwrap().rules,
                &filter::exclude_ids(stored_static),
                stored_static,
                html_reporter,
            );
            self.checkpoint.lap_checkpoint("Rule Parse Processing Time");
            self.checkpoint.set_checkpoint(Local::now());
            if rule_files.is_empty() {
                AlertMessage::alert(
                        "No rules were loaded. Please download the latest rules with the update-rules command.\r\n",
                    )
                    .ok();
                self.failed.set(true);
                return;
            }
            if !stored_static.json_input_flag
                && !stored_static.scan_all_evtx_files
                && !stored_static.enable_all_rules
            {
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    get_writable_color(
                        Some(Color::Rgb(255, 175, 0)),
                        stored_static.common_options.no_color,
                    ),
                    "Creating the channel filter. Please wait.",
                    true,
                )
                .ok();
                println!();
                let mut channel_filter = create_channel_filter(
                    &evtx_files,
                    &rule_files,
                    stored_static.quiet_errors_flag,
                    &stored_static.error_log_stack,
                );
                if !stored_static.scan_all_evtx_files {
                    evtx_files.retain(|evtx_file| channel_filter.scannable_rule_exists(evtx_file));
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(
                            Some(Color::Rgb(0, 255, 0)),
                            stored_static.common_options.no_color,
                        ),
                        "Evtx files loaded after channel filter: ",
                        false,
                    )
                    .ok();
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        None,
                        evtx_files.len().to_formatted_string(&Locale::en).as_str(),
                        true,
                    )
                    .ok();
                }
                if !stored_static.enable_all_rules {
                    rule_files.retain(|rule| {
                        channel_filter.rule_paths.contains(&rule.rule_path)
                            || !rule.yaml["correlation"].is_badvalue()
                    });
                    let rules_after_channel_filter =
                        rule_files.len().to_formatted_string(&Locale::en);
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(
                            Some(Color::Rgb(0, 255, 0)),
                            stored_static.common_options.no_color,
                        ),
                        "Detection rules enabled after channel filter: ",
                        false,
                    )
                    .ok();
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        None,
                        rules_after_channel_filter.as_str(),
                        true,
                    )
                    .ok();
                    println!();
                }
            }
            output_profile_name(
                &stored_static.output_option,
                true,
                stored_static.common_options.no_color,
                html_reporter,
            );
            println!();
            write_color_buffer(
                &BufferWriter::stdout(ColorChoice::Always),
                get_writable_color(
                    Some(Color::Rgb(255, 175, 0)),
                    stored_static.common_options.no_color,
                ),
                "Scanning in progress. Please wait.",
                true,
            )
            .ok();
            println!();
        }

        evtx_files = apply_channel_filters(evtx_files, stored_static);

        let progress_bar = build_progress_bar(stored_static, evtx_files.len() as u64);
        self.rule_keys = self.get_all_keys(&rule_files);
        let mut detection = detection::Detection::new(rule_files);
        let mut timeline = Timeline::new();
        // Snapshot `stored_static` once and share it with the per-rule parallel tasks in
        // `Detection::execute_rules` via cheap `Arc::clone`s. The Arc-wrapped inner fields
        // (e.g. error_log_stack, pivot_keyword) stay shared with the live `stored_static`,
        // so accumulation from the parallel path is still visible; the plain config/flag
        // fields are read-only during the scan.
        let stored_static_arc = Arc::new(stored_static.clone());
        let mut result_state = ResultOutputState::default();
        let mut all_detect_infos = vec![];
        let mut output_writer = results::init_writer(stored_static);
        let is_show_progress = stored_static.output_path.is_some()
            || matches!(
                stored_static.config.action.as_ref().unwrap(),
                Action::ConfigCriticalSystems(_)
                    | Action::PivotKeywordsList(_)
                    | Action::ExtractBase64(_)
                    | Action::LogonSummary(_)
                    | Action::ComputerMetrics(_)
                    | Action::LogMetrics(_)
                    | Action::EidMetrics(_)
            );
        if is_show_progress {
            progress_bar.enable_steady_tick(Duration::from_millis(300));
        }
        for evtx_file in evtx_files {
            if is_show_progress {
                let size = get_file_size(
                    &evtx_file,
                    stored_static.verbose_flag,
                    stored_static.quiet_errors_flag,
                    &stored_static.error_log_stack,
                );
                let file_size = ByteSize::b(size);
                let pb_msg = format!(
                    "{:?} ({})",
                    evtx_file.to_str().unwrap_or_default().replace('\\', "/"),
                    file_size.display()
                );
                if !pb_msg.is_empty() {
                    progress_bar.set_message(pb_msg);
                }
            }

            let (detection_tmp, cnt_tmp, tl_tmp, recover_cnt_tmp, mut detect_infos) =
                if evtx_file.extension().unwrap() == "json"
                    || evtx_file.extension().unwrap() == "jsonl"
                {
                    self.analysis_json_file(
                        (evtx_file, time_filter, target_event_ids, stored_static),
                        &stored_static_arc,
                        detection,
                        timeline.to_owned(),
                        &mut output_writer,
                        &mut result_state,
                    )
                } else {
                    self.analysis_file(
                        (evtx_file, time_filter, target_event_ids, stored_static),
                        &stored_static_arc,
                        detection,
                        timeline.to_owned(),
                        &mut output_writer,
                        &mut result_state,
                    )
                };
            detection = detection_tmp;
            timeline = tl_tmp;
            result_state.record_cnt += cnt_tmp as u128;
            result_state.recover_record_cnt += recover_cnt_tmp as u128;
            all_detect_infos.append(&mut detect_infos);
            if is_show_progress {
                progress_bar.inc(1);
            }
        }
        let is_timeline_cmd = matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::DfirTimeline(_)
        );
        if !is_timeline_cmd {
            let msg = if stored_static.common_options.no_color {
                style("Scanning finished.\n").color256(15).to_string()
            } else {
                style("Scanning finished.\n").color256(214).to_string()
            };
            progress_bar.finish_with_message(msg);
        }
        self.checkpoint.lap_checkpoint("Analysis Processing Time");
        self.checkpoint.set_checkpoint(Local::now());

        if stored_static.metrics_flag {
            timeline.tm_stats_dsp_msg(event_timeline_config, stored_static);
        } else if stored_static.logon_summary_flag {
            timeline.tm_logon_stats_dsp_msg(stored_static);
        } else if stored_static.search_flag {
            timeline.search_dsp_msg(stored_static);
        } else if stored_static.computer_metrics_flag {
            timeline.computer_metrics_dsp_msg(stored_static)
        } else if stored_static.log_metrics_flag {
            timeline.log_metrics_dsp_msg(stored_static)
        } else if stored_static.extract_base64_flag {
            timeline.extract_base64_dsp_msg(stored_static)
        } else if let Action::ConfigCriticalSystems(_) =
            &stored_static.config.action.as_ref().unwrap()
        {
            timeline.config_critical_systems_dsp_msg(stored_static.common_options.no_color);
        }
        if is_timeline_cmd {
            let mut log_records = detection.add_aggcondition_msgs(&self.runtime, stored_static);
            emit_or_buffer(
                &mut log_records,
                &mut all_detect_infos,
                stored_static,
                &mut output_writer,
                &mut result_state,
            );
            result_state.timeline_start_time = timeline.stats.start_time;
            result_state.timeline_end_time = timeline.stats.end_time;

            let msg = if stored_static.output_path.is_some() {
                if stored_static.common_options.no_color {
                    style("Scanning finished. Please wait while the results are being saved.\n")
                        .color256(15)
                        .to_string()
                } else {
                    style("Scanning finished. Please wait while the results are being saved.\n")
                        .color256(214)
                        .to_string()
                }
            } else if stored_static.common_options.no_color {
                style("Scanning finished.\n").color256(15).to_string()
            } else {
                style("Scanning finished.\n").color256(214).to_string()
            };
            // The styled message was converted to a plain String above because
            // finish_with_message requires a string type.
            if is_show_progress {
                progress_bar.finish_with_message(msg);
            } else {
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    get_writable_color(
                        Some(Color::Rgb(255, 175, 0)),
                        stored_static.common_options.no_color,
                    ),
                    "Scanning finished.",
                    true,
                )
                .ok();
            }

            // Output the post-detection results (results output processing).
            if stored_static.is_low_memory {
                results::output_result_summary(
                    stored_static,
                    &mut output_writer,
                    &result_state,
                    html_reporter,
                );
            } else {
                results::output_results(
                    &mut all_detect_infos,
                    &mut output_writer,
                    stored_static,
                    &mut result_state,
                    html_reporter,
                );
            }

            if let Some(Action::DfirTimeline(json_options)) = &stored_static.config.action
                && matches!(json_options.output_type, OutputType::Jsonl)
                && let Some(path) = &stored_static.output_path
                && let Ok(mut file) = fs::OpenOptions::new().append(true).open(path)
            {
                let _ = file.write_all(b"\n");
            }
        }
        self.checkpoint.lap_checkpoint("Output Processing Time");
        self.checkpoint.set_checkpoint(Local::now());
    }

    /// Analyze one Windows .evtx event log file: iterate its records in chunks of
    /// MAX_DETECT_RECORDS, apply the computer/EventID/channel/time filters, and run timeline
    /// processing and rule detection on the surviving records.
    fn analysis_file(
        &self,
        (evtx_filepath, time_filter, target_event_ids, stored_static): (
            PathBuf,
            &TargetEventTime,
            &TargetIds,
            &StoredStatic,
        ),
        stored_static_arc: &Arc<StoredStatic>,
        mut detection: detection::Detection,
        mut timeline: Timeline,
        output_writer: &mut OutputWriter,
        result_state: &mut ResultOutputState,
    ) -> (
        detection::Detection,
        usize,
        Timeline,
        usize,
        Vec<DetectInfo>,
    ) {
        let path = evtx_filepath.display();
        let parser = self.evtx_to_jsons(&evtx_filepath, stored_static);
        let mut record_cnt = 0;
        let mut recover_records_cnt = 0;
        let mut detect_infos: Vec<DetectInfo> = vec![];
        if parser.is_none() {
            return (detection, record_cnt, timeline, 0, detect_infos);
        }

        let mut parser = parser.unwrap();
        let mut records = parser.records_json_value();

        let verbose_flag = stored_static.verbose_flag;
        let quiet_errors_flag = stored_static.quiet_errors_flag;
        let need_rule = matches!(
            stored_static.config.action.as_ref().unwrap(),
            Action::DfirTimeline(_) | Action::PivotKeywordsList(_)
        );
        let rec_ctx = RecordBuildContext {
            rule_keys: Arc::new(self.rule_keys.to_owned()),
            eventkey_alias: Arc::new(stored_static.eventkey_alias.clone()),
            no_pwsh_field_extraction: stored_static.no_pwsh_field_extraction,
        };
        loop {
            let mut records_per_detect = vec![];
            while records_per_detect.len() < MAX_DETECT_RECORDS {
                // If parsing fails, output an error message.
                let next_rec = records.next();
                if next_rec.is_none() {
                    break;
                }
                record_cnt += 1;
                let record_result = next_rec.unwrap();

                if record_result.is_ok()
                    && record_result.as_ref().unwrap().allocation == RecordAllocation::EmptyPage
                {
                    recover_records_cnt += 1;
                }

                if let Err(e) = record_result {
                    let evtx_filepath = &path;
                    let errmsg = format!(
                        "Failed to parse event file.\nEventFile: {}\nError: {}\n",
                        evtx_filepath, e
                    );
                    if verbose_flag {
                        AlertMessage::alert(&errmsg).ok();
                    }
                    if !quiet_errors_flag {
                        stored_static
                            .error_log_stack
                            .lock()
                            .unwrap()
                            .push(format!("[ERROR] {errmsg}"));
                    }
                    continue;
                }

                let data = &record_result.as_ref().unwrap().data;
                if stored_static.computer_metrics_flag {
                    countup_event_by_computer(data, &stored_static.eventkey_alias, &mut timeline);
                    // The computer-metrics command does not perform detection, so only count and check the next record.
                    continue;
                }
                if !stored_static.search_flag {
                    // Filter if the Computer name does not match include_computer or matches exclude_computer.
                    if utils::is_filtered_by_computer_name(
                        utils::get_event_value(
                            "Event.System.Computer",
                            data,
                            &stored_static.eventkey_alias,
                        ),
                        (
                            &stored_static.include_computer,
                            &stored_static.exclude_computer,
                        ),
                    ) {
                        continue;
                    }

                    // Filter if the EventID does not match include_eid, matches exclude_eid, or is not an EventID specified in target_eventids.txt.
                    if self.is_filtered_by_eid(
                        data,
                        &stored_static.eventkey_alias,
                        (&stored_static.include_eid, &stored_static.exclude_eid),
                        stored_static.output_option.as_ref().unwrap().eid_filter,
                        target_event_ids,
                    ) {
                        continue;
                    }

                    // Filter if channel is null.
                    if !self._is_valid_channel(
                        data,
                        &stored_static.eventkey_alias,
                        "Event.System.Channel",
                    ) {
                        continue;
                    }
                }
                // Separated the time-based filtering condition branch to avoid confusion with EventID conditions.
                let timestamp = get_event_time(data, stored_static.json_input_flag);
                if !time_filter.is_target(&timestamp) {
                    continue;
                }

                let recover_record_flag = record_result.is_ok()
                    && record_result.as_ref().unwrap().allocation == RecordAllocation::EmptyPage;
                records_per_detect.push((data.to_owned(), recover_record_flag));
            }
            if records_per_detect.is_empty() {
                break;
            }

            detection = self.process_detection_batch(
                (records_per_detect, &path, &rec_ctx),
                detection,
                &mut timeline,
                stored_static,
                stored_static_arc,
                (&mut detect_infos, output_writer, result_state),
                BatchPolicy {
                    run_rules: need_rule,
                    update_time_range: true,
                },
            );
        }
        timeline.total_record_cnt += record_cnt;
        (
            detection,
            record_cnt,
            timeline,
            recover_records_cnt,
            detect_infos,
        )
    }

    /// Runs one accumulated batch of records through the shared detection pipeline tail: build
    /// EvtxRecordInfo structs, feed the timeline, and (when `run_rules`) run the rules and either
    /// stream or buffer the results. `update_time_range` widens the results-summary detection time
    /// span (the evtx path does this; the JSON path does not). This is the tail that was
    /// copy-pasted at the end of both the evtx and JSON batch loops.
    #[allow(clippy::too_many_arguments)]
    fn process_detection_batch(
        &self,
        (records_per_detect, path, rec_ctx): (
            Vec<(Value, bool)>,
            &dyn Display,
            &RecordBuildContext,
        ),
        mut detection: detection::Detection,
        timeline: &mut Timeline,
        stored_static: &StoredStatic,
        // A snapshot of `stored_static` shared with the per-rule parallel tasks in
        // `Detection::execute_rules`; see the Arc created in `analysis_files`.
        stored_static_arc: &Arc<StoredStatic>,
        (detect_infos, output_writer, result_state): (
            &mut Vec<DetectInfo>,
            &mut OutputWriter,
            &mut ResultOutputState,
        ),
        policy: BatchPolicy,
    ) -> detection::Detection {
        let BatchPolicy {
            run_rules,
            update_time_range,
        } = policy;
        let records_per_detect = self.runtime.block_on(App::create_rec_infos(
            records_per_detect,
            path,
            Arc::clone(&rec_ctx.rule_keys),
            Arc::clone(&rec_ctx.eventkey_alias),
            rec_ctx.no_pwsh_field_extraction,
        ));
        timeline.start(&records_per_detect, stored_static);
        if run_rules {
            // Run the loaded detection rules against this batch of records.
            let (detection_tmp, mut log_records) = detection.start(
                &self.runtime,
                records_per_detect,
                Arc::clone(stored_static_arc),
            );

            if update_time_range
                && let MinMaxResult::MinMax(min_time, max_time) =
                    log_records.iter().map(|info| info.detected_time).minmax()
            {
                if result_state.detect_starttime.is_none()
                    || result_state.detect_starttime.unwrap() > min_time
                {
                    result_state.detect_starttime = Some(min_time);
                }
                if result_state.detect_endtime.is_none()
                    || result_state.detect_endtime.unwrap() < max_time
                {
                    result_state.detect_endtime = Some(max_time);
                }
            }
            emit_or_buffer(
                &mut log_records,
                detect_infos,
                stored_static,
                output_writer,
                result_state,
            );
            detection = detection_tmp;
        }
        detection
    }

    /// Apply the computer, EventID, channel, and timestamp filters to a JSON record. Returns
    /// true if the record should be filtered out (skipped).
    fn is_filtered_record(
        &self,
        (path, time_filter, target_event_ids, stored_static): (
            &str,
            &TargetEventTime,
            &TargetIds,
            &StoredStatic,
        ),
        (is_splunk_json, is_splunk_api_json): (bool, bool),
        data: &Value,
    ) -> bool {
        // Filter if the Computer name does not match include_computer or matches exclude_computer.
        if utils::is_filtered_by_computer_name(
            utils::get_event_value("Event.System.Computer", data, &stored_static.eventkey_alias),
            (
                &stored_static.include_computer,
                &stored_static.exclude_computer,
            ),
        ) {
            return true;
        }

        // Filter if the EventID does not match one specified in include_eid or matches one
        // specified in exclude_eid, or if the EventID filter option is specified and the EventID
        // is not one specified in target_eventids.txt.
        if self.is_filtered_by_eid(
            data,
            &stored_static.eventkey_alias,
            (&stored_static.include_eid, &stored_static.exclude_eid),
            stored_static.output_option.as_ref().unwrap().eid_filter,
            target_event_ids,
        ) {
            return true;
        }

        // Filter if channel is null.
        if !self._is_valid_channel(
            data,
            &stored_static.eventkey_alias,
            "Event.EventData.Channel",
        ) {
            return true;
        }
        let target_timestamp = if data["Event"]["EventData"]["@timestamp"].is_null() {
            &data["Event"]["EventData"]["TimeGenerated"]
        } else {
            &data["Event"]["EventData"]["@timestamp"]
        };
        let time_fmt = if is_splunk_json {
            "%Y-%m-%dT%H:%M:%S%.3f%:z"
        } else if is_splunk_api_json {
            "%Y-%m-%dT%H:%M:%S%.9fZ"
        } else {
            "%Y-%m-%dT%H:%M:%S%.fZ"
        };
        // Separated the time-based filtering condition branch to avoid confusion with EventID conditions.
        let timestamp = match NaiveDateTime::parse_from_str(
            &target_timestamp
                .to_string()
                .replace("\\\"", "")
                .replace(['"', '\''], ""),
            time_fmt,
        ) {
            Ok(without_timezone_datetime) => Some(DateTime::<Utc>::from_naive_utc_and_offset(
                without_timezone_datetime,
                Utc,
            )),
            Err(e) => {
                // Gate this per-record parse error like the EVTX path does, so it
                // honors --verbose/--quiet-errors, stays out of the live progress
                // bar, and lands in the error log instead of leaking to stderr.
                // Only build the message when it will actually be emitted.
                if stored_static.verbose_flag || !stored_static.quiet_errors_flag {
                    let errmsg = format!(
                        "Timestamp parse error. Filepath: {},{} {}",
                        path,
                        target_timestamp
                            .to_string()
                            .replace("\\\"", "")
                            .replace('"', ""),
                        e
                    );
                    if stored_static.verbose_flag {
                        AlertMessage::alert(&errmsg).ok();
                    }
                    if !stored_static.quiet_errors_flag {
                        stored_static
                            .error_log_stack
                            .lock()
                            .unwrap()
                            .push(format!("[ERROR] {errmsg}"));
                    }
                }
                None
            }
        };
        if !time_filter.is_target(&timestamp) {
            return true;
        }
        false
    }

    /// Analyze one JSON-format event log file (JSONL, JSON array, or Splunk exports): normalize
    /// each record so it looks like an evtx-converted record (Event.System, Event.EventData,
    /// etc.), then apply the filters and run timeline processing and rule detection.
    fn analysis_json_file(
        &self,
        (filepath, time_filter, target_event_ids, stored_static): (
            PathBuf,
            &TargetEventTime,
            &TargetIds,
            &StoredStatic,
        ),
        stored_static_arc: &Arc<StoredStatic>,
        mut detection: detection::Detection,
        mut timeline: Timeline,
        output_writer: &mut OutputWriter,
        result_state: &mut ResultOutputState,
    ) -> (
        detection::Detection,
        usize,
        Timeline,
        usize,
        Vec<DetectInfo>,
    ) {
        let path = filepath.display();
        let mut record_cnt = 0;
        let recover_records_cnt = 0;
        let mut is_splunk_api_json;
        let filename = filepath.to_str().unwrap_or_default();
        let filepath = if filename.starts_with("./") {
            check_setting_path(&CURRENT_EXE_PATH.to_path_buf(), filename, true)
                .unwrap()
                .to_str()
                .unwrap()
                .to_string()
        } else {
            filename.to_string()
        };
        let jsonl_value_iter = utils::read_jsonl_to_value(&filepath);
        let mut detect_infos: Vec<DetectInfo> = vec![];
        let mut records = match jsonl_value_iter {
            // For JSONL format
            Ok(values) => values,
            // For non-JSONL format (JSON Array or jq format)
            Err(_) => {
                let json_value_iter = utils::read_json_to_value(&filepath);
                match json_value_iter {
                    Ok(values) => values,
                    Err(e) => {
                        AlertMessage::alert(&e).ok();
                        return (
                            detection,
                            record_cnt,
                            timeline,
                            recover_records_cnt,
                            detect_infos,
                        );
                    }
                }
            }
        };

        let rec_ctx = RecordBuildContext {
            rule_keys: Arc::new(self.rule_keys.to_owned()),
            eventkey_alias: Arc::new(stored_static.eventkey_alias.clone()),
            no_pwsh_field_extraction: stored_static.no_pwsh_field_extraction,
        };
        loop {
            let mut records_per_detect = vec![];
            while records_per_detect.len() < MAX_DETECT_RECORDS {
                // Read the next record; stop this chunk when the iterator is exhausted.
                let next_rec = records.next();
                if next_rec.is_none() {
                    break;
                }
                let mut data = next_rec.unwrap();
                let is_splunk_json = data["Event"]["EventData"]["result"].is_object();
                is_splunk_api_json = !data["Event"]["EventData"]["rows"].is_null();
                // Data such as Channel must exist in Event -> System, but to keep the rest of
                // the processing simple, the data from Event -> EventData is inserted as-is.
                // clone() is used because serde_json::Value does not implement the Copy trait.
                if is_splunk_api_json {
                    let tmp_data = data["Event"]["EventData"]["rows"].clone();
                    let tmp_data_value = data["Event"]["EventData"]["fields"].clone();
                    let empty = vec![];
                    let field_value = tmp_data.as_array().unwrap_or(&empty);
                    let fields_key = tmp_data_value.as_array().unwrap_or(&empty);
                    record_cnt += field_value.len();
                    for splunk_api_rec in field_value {
                        let mut splunk_api_record = Value::Null;
                        for (v_idx, row_name) in fields_key.iter().enumerate() {
                            if let Some(row) = row_name.as_str() {
                                // For Splunk API JSON, the record comes as parallel "rows"
                                // (values) and "fields" (names) arrays. Insert each value under
                                // both Event.System and Event.EventData keyed by its field name:
                                // later processing expects System fields (e.g. Channel, EventID)
                                // under Event.System and reads field data from Event.EventData.
                                splunk_api_record["Event"]["System"][row.to_string()] =
                                    splunk_api_rec[v_idx].clone();
                                splunk_api_record["Event"]["EventData"][row.to_string()] =
                                    splunk_api_rec[v_idx].clone();
                            }
                        }
                        let timestamp = match NaiveDateTime::parse_from_str(
                            &splunk_api_record["Event"]["System"]["SystemTime"]
                                .to_string()
                                .replace("\\\"", "")
                                .replace(['"', '\''], ""),
                            "%Y-%m-%dT%H:%M:%S%.9fZ",
                        ) {
                            Ok(without_timezone_datetime) => {
                                DateTime::<Utc>::from_naive_utc_and_offset(
                                    without_timezone_datetime,
                                    Utc,
                                )
                                .format("%Y-%m-%dT%H:%M:%S%.fZ")
                            }
                            Err(e) => {
                                // Gate like the EVTX path so it honors
                                // --verbose/--quiet-errors and is logged rather
                                // than leaked to stderr over the progress bar.
                                // Only build the message when it will be emitted.
                                if stored_static.verbose_flag || !stored_static.quiet_errors_flag {
                                    let errmsg = format!(
                                        "Timestamp parse error. Filepath: {},{} {}",
                                        path,
                                        splunk_api_record["Event"]["System"]["SystemTime"]
                                            .to_string()
                                            .replace("\\\"", "")
                                            .replace('"', ""),
                                        e
                                    );
                                    if stored_static.verbose_flag {
                                        AlertMessage::warn(&errmsg).ok();
                                    }
                                    if !stored_static.quiet_errors_flag {
                                        stored_static
                                            .error_log_stack
                                            .lock()
                                            .unwrap()
                                            .push(format!("[WARN] {errmsg}"));
                                    }
                                }
                                DateTime::<Utc>::default().format("%Y-%m-%dT%H:%M:%S%.fZ")
                            }
                        };

                        splunk_api_record["Event"]["UserData"] =
                            splunk_api_record["Event"]["EventData"].clone();
                        splunk_api_record["Event"]["EventData"]["@timestamp"] =
                            Value::String(timestamp.to_string());
                        splunk_api_record["Event"]["System"]["@timestamp"] =
                            splunk_api_record["Event"]["EventData"]["@timestamp"].clone();
                        splunk_api_record["Event"]["System"]
                            .as_object_mut()
                            .unwrap()
                            .insert(
                                "Provider_attributes".to_string(),
                                Value::Object(Map::from_iter(vec![(
                                    "Name".to_string(),
                                    Value::from(1),
                                )])),
                            );
                        splunk_api_record["Event"]["System"]["Provider_attributes"]["Name"] =
                            splunk_api_record["Event"]["EventData"]["Name"].clone();
                        if stored_static.computer_metrics_flag {
                            // The computer-metrics command does not perform detection, so only
                            // count the event by computer name.
                            countup_event_by_computer(
                                &splunk_api_record,
                                &stored_static.eventkey_alias,
                                &mut timeline,
                            );
                        }
                        if !self.is_filtered_record(
                            (
                                filepath.as_str(),
                                time_filter,
                                target_event_ids,
                                stored_static,
                            ),
                            (is_splunk_json, is_splunk_api_json),
                            &splunk_api_record,
                        ) {
                            records_per_detect.push((splunk_api_record.to_owned(), false));
                        }
                    }
                    continue;
                } else if is_splunk_json {
                    data["Event"]["System"] = data["Event"]["EventData"]["result"].clone();
                    data["Event"]["EventData"] = data["Event"]["EventData"]["result"].clone();
                }
                record_cnt += 1;
                if data["Event"]["EventData"].is_object() {
                    data["Event"]["System"] = data["Event"]["EventData"].clone();
                } else if let Some(first) = data["Event"]["EventData"]
                    .as_array()
                    .and_then(|array| array.first())
                {
                    data["Event"]["System"] = first.clone();
                }
                // If EventData was an empty array, a scalar, or an array whose first
                // element isn't an object, `System` is not a JSON object and the
                // normalization below would panic at `as_object_mut().unwrap()`. Skip
                // the malformed record instead of aborting the whole scan.
                if !data["Event"]["System"].is_object() {
                    let errmsg = format!(
                        "Skipped a malformed JSON record (unexpected Event.EventData shape). Filepath: {path}"
                    );
                    if stored_static.verbose_flag {
                        AlertMessage::warn(&errmsg).ok();
                    }
                    if !stored_static.quiet_errors_flag {
                        stored_static
                            .error_log_stack
                            .lock()
                            .unwrap()
                            .push(format!("[WARN] {errmsg}"));
                    }
                    continue;
                }
                data["Event"]["System"]
                    .as_object_mut()
                    .unwrap()
                    .insert("EventRecordID".to_string(), Value::from(1));
                data["Event"]["System"]["EventRecordID"] =
                    data["Event"]["EventData"]["RecordNumber"].clone();
                data["Event"]["System"].as_object_mut().unwrap().insert(
                    "Provider_attributes".to_string(),
                    Value::Object(Map::from_iter(vec![("Name".to_string(), Value::from(1))])),
                );
                data["Event"]["UserData"] = data["Event"]["EventData"].clone();

                if is_splunk_json {
                    data["Event"]["EventData"]["@timestamp"] =
                        data["Event"]["EventData"]["_time"].clone();
                    data["Event"]["System"]["@timestamp"] =
                        data["Event"]["EventData"]["_time"].clone();
                    data["Event"]["System"]["Provider_attributes"]["Name"] =
                        data["Event"]["EventData"]["Name"].clone();
                } else {
                    data["Event"]["System"]["Provider_attributes"]["Name"] =
                        data["Event"]["EventData"]["SourceName"].clone();
                    // The field corresponding to the Computer name turned out to be Hostname, so
                    // clone that value into System.Computer.
                    data["Event"]["System"]["Computer"] =
                        data["Event"]["EventData"]["Hostname"].clone();
                }

                if stored_static.computer_metrics_flag {
                    countup_event_by_computer(&data, &stored_static.eventkey_alias, &mut timeline);
                    // The computer-metrics command does not perform detection, so only count and check the next record.
                    continue;
                }
                if !self.is_filtered_record(
                    (
                        filepath.as_str(),
                        time_filter,
                        target_event_ids,
                        stored_static,
                    ),
                    (is_splunk_json, is_splunk_api_json),
                    &data,
                ) {
                    records_per_detect.push((data.to_owned(), false));
                }
            }
            if records_per_detect.is_empty() {
                break;
            }

            detection = self.process_detection_batch(
                (records_per_detect, &path, &rec_ctx),
                detection,
                &mut timeline,
                stored_static,
                stored_static_arc,
                (&mut detect_infos, output_writer, result_state),
                BatchPolicy {
                    run_rules: !(stored_static.metrics_flag
                        || stored_static.logon_summary_flag
                        || stored_static.log_metrics_flag
                        || stored_static.search_flag),
                    update_time_range: false,
                },
            );
        }
        timeline.total_record_cnt += record_cnt;
        (
            detection,
            record_cnt,
            timeline,
            recover_records_cnt,
            detect_infos,
        )
    }

    /// Convert a chunk of raw JSON records into EvtxRecordInfo structs in parallel on the Tokio
    /// runtime (one task per record).
    async fn create_rec_infos(
        records_per_detect: Vec<(Value, bool)>,
        path: &dyn Display,
        rule_keys: Arc<Nested<String>>,
        eventkey_alias: Arc<EventKeyAliasConfig>,
        no_pwsh_field_extraction: bool,
    ) -> Vec<EvtxRecordInfo> {
        let no_pwsh_field_extraction = Arc::new(no_pwsh_field_extraction);
        let path = Arc::new(path.to_string());
        let threads: Vec<JoinHandle<EvtxRecordInfo>> = {
            let this = records_per_detect.into_iter().map(
                |(rec, recovered_record_flag)| -> JoinHandle<EvtxRecordInfo> {
                    let arc_rule_keys = Arc::clone(&rule_keys);
                    let arc_path = Arc::clone(&path);
                    let arc_no_pwsh_field_extraction = Arc::clone(&no_pwsh_field_extraction);
                    let arc_eventkey_alias = Arc::clone(&eventkey_alias);
                    spawn(async move {
                        utils::create_rec_info(
                            rec,
                            arc_path.to_string(),
                            &arc_rule_keys,
                            &recovered_record_flag,
                            &arc_no_pwsh_field_extraction,
                            &arc_eventkey_alias,
                        )
                    })
                },
            );
            FromIterator::from_iter(this)
        };

        let mut ret = vec![];
        for thread in threads.into_iter() {
            ret.push(thread.await.unwrap());
        }

        ret
    }

    /// Collect the deduplicated set of event field keys referenced by the detection sections of
    /// all loaded rules.
    fn get_all_keys(&self, rules: &[RuleNode]) -> Nested<String> {
        let mut key_set = HashSet::new();
        for rule in rules {
            let keys = get_detection_keys(rule);
            key_set.extend(keys.iter().map(|x| x.to_string()));
        }

        key_set.into_iter().collect::<Nested<String>>()
    }

    /// Filter based on the settings in target_eventids.txt. Returns true if it is an EventID subject to detection check.
    fn _is_target_event_id(
        &self,
        data: &Value,
        target_event_ids: &TargetIds,
        eventkey_alias: &EventKeyAliasConfig,
    ) -> bool {
        let eventid = utils::get_event_value(&utils::get_event_id_key(), data, eventkey_alias);
        if eventid.is_none() {
            return true;
        }

        match eventid.unwrap() {
            Value::String(s) => target_event_ids.is_target(&s.replace('\"', ""), true),
            Value::Number(n) => target_event_ids.is_target(&n.to_string().replace('\"', ""), true),
            _ => true, // If EventId cannot be obtained from the record, do not filter.
        }
    }

    /// Function that determines whether the channel value in the record is valid (a String and not null).
    fn _is_valid_channel(
        &self,
        data: &Value,
        eventkey_alias: &EventKeyAliasConfig,
        channel_key: &str,
    ) -> bool {
        let channel = utils::get_event_value(channel_key, data, eventkey_alias);
        if channel.is_none() {
            return false;
        }
        match channel.unwrap() {
            Value::String(s) => s != "null",
            _ => false, // Since the channel value is expected to be a string, return false for any other data type.
        }
    }

    /// Returns true if the record should be filtered out based on its EventID (the include/
    /// exclude EID options and the target_eventids.txt filter).
    fn is_filtered_by_eid(
        &self,
        data: &Value,
        eventkey_alias: &EventKeyAliasConfig,
        (include_eid, exclude_eid): (&HashSet<CompactString>, &HashSet<CompactString>),
        eid_filter: bool,
        target_event_ids: &TargetIds,
    ) -> bool {
        let target_eid = if !include_eid.is_empty() || !exclude_eid.is_empty() {
            if let Some(eid_record) =
                utils::get_event_value(&utils::get_event_id_key(), data, eventkey_alias)
            {
                utils::get_serde_number_to_string(eid_record, false).unwrap_or_default()
            } else {
                CompactString::default()
            }
        } else {
            CompactString::default()
        };
        // Filter in the following cases.
        // 1. include_eid is specified, but the EventID is not included in include_eid.
        // 2. exclude_eid is specified, and the EventID is included in exclude_eid.
        // 3. eid_filter is specified, and the EventID is not one specified in target_eventids.txt.
        (!include_eid.is_empty() && !include_eid.contains(&target_eid))
            || (!exclude_eid.is_empty() && exclude_eid.contains(&target_eid))
            || (eid_filter && !self._is_target_event_id(data, target_event_ids, eventkey_alias))
    }

    /// Open an .evtx file and return an EvtxParser configured for JSON output. Returns None
    /// (after logging the error) if the file cannot be opened.
    fn evtx_to_jsons(
        &self,
        evtx_filepath: &PathBuf,
        stored_static: &StoredStatic,
    ) -> Option<EvtxParser<File>> {
        match EvtxParser::from_path(evtx_filepath) {
            Ok(evtx_parser) => {
                // Change the default parser settings.
                let mut parse_config = ParserSettings::default()
                    .parse_empty_chunks(stored_static.enable_recover_records);
                parse_config = parse_config.separate_json_attributes(true); // Set rules for converting XML attributes to JSON.
                parse_config = parse_config.num_threads(stored_static.thread_number.unwrap_or(0));
                parse_config = parse_config.validate_checksums(stored_static.validate_checksum);

                let evtx_parser = evtx_parser.with_configuration(parse_config);
                Some(evtx_parser)
            }
            Err(e) => {
                let errmsg = format!(
                    "Failed to open event file.\nEventFile: {}\nError: {}\n",
                    evtx_filepath.display(),
                    e
                );
                if stored_static.verbose_flag {
                    AlertMessage::alert(&errmsg).ok();
                }
                if !stored_static.quiet_errors_flag {
                    stored_static
                        .error_log_stack
                        .lock()
                        .unwrap()
                        .push(format!("[ERROR] {errmsg}"));
                }
                None
            }
        }
    }

    /// Output the Hayabusa ASCII art logo.
    fn output_logo(&self, stored_static: &StoredStatic) {
        let logo = Arts::get("logo.txt").unwrap();
        let content = std::str::from_utf8(logo.data.as_ref()).unwrap_or_default();
        let output_color = if stored_static.common_options.no_color {
            None
        } else {
            Some(Color::Rgb(0, 255, 0))
        };
        write_color_buffer(
            &BufferWriter::stdout(ColorChoice::Always),
            output_color,
            content,
            true,
        )
        .ok();
    }

    /// Output seasonal easter egg ASCII art when the run date matches a special day.
    fn output_eggs(&self, exec_datestr: &str) {
        let mut eggs: HashMap<&str, (&str, Color)> = HashMap::new();
        eggs.insert("01/01", ("happynewyear.txt", Color::Rgb(255, 0, 0))); // Red
        eggs.insert("02/22", ("ninja.txt", Color::Rgb(0, 171, 240))); // Cerulean
        eggs.insert("05/09", ("goku.txt", Color::Rgb(243, 156, 22))); // Middle Washed Orange
        eggs.insert("08/08", ("takoyaki.txt", Color::Rgb(181, 101, 29))); // Light Brown
        eggs.insert("10/31", ("halloween.txt", Color::Rgb(255, 87, 51))); // Pumpkin Orange
        eggs.insert("12/24", ("christmas.txt", Color::Rgb(0, 255, 0))); // Green
        eggs.insert("12/25", ("christmas.txt", Color::Rgb(0, 255, 0))); // Green

        match eggs.get(exec_datestr) {
            None => {}
            Some((path, color)) => {
                let art = Arts::get(path).unwrap();
                let content = std::str::from_utf8(art.data.as_ref()).unwrap_or_default();
                write_color_buffer(
                    &BufferWriter::stdout(ColorChoice::Always),
                    Some(color.to_owned()),
                    content,
                    true,
                )
                .ok();
            }
        }
    }

    /// Print a random line from the given messages file (rules/config/opening_messages.txt or
    /// closing_messages.txt), unless quiet mode is enabled.
    fn output_open_close_message(
        &self,
        file_path: &str,
        stored_static: &StoredStatic,
    ) -> io::Result<()> {
        if stored_static.common_options.quiet {
            return Ok(());
        }
        let checked_path = check_setting_path(
            &CURRENT_EXE_PATH.to_path_buf(),
            format!("rules/config/{file_path}").as_str(),
            true,
        );
        if let Some(path) = checked_path {
            if path.exists() {
                let file = File::open(path)?;
                let lines: Vec<String> =
                    io::BufReader::new(file).lines().collect::<Result<_, _>>()?;
                if let Some(random_line) = lines.choose(&mut rand::rng()) {
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(
                            Some(Color::Rgb(255, 175, 0)),
                            stored_static.common_options.no_color,
                        ),
                        random_line,
                        true,
                    )
                    .ok();
                    println!()
                }
            } else if let Some(contents) = ONE_CONFIG_MAP.get(file_path) {
                let lines: Vec<&str> = contents.lines().collect();
                if let Some(random_line) = lines.choose(&mut rand::rng()) {
                    write_color_buffer(
                        &BufferWriter::stdout(ColorChoice::Always),
                        get_writable_color(
                            Some(Color::Rgb(255, 175, 0)),
                            stored_static.common_options.no_color,
                        ),
                        random_line,
                        true,
                    )
                    .ok();
                    println!()
                }
            }
            write_color_buffer(&BufferWriter::stdout(ColorChoice::Always), None, "", false).ok();
        }
        Ok(())
    }

    /// Check whether this binary's architecture matches the OS architecture. Returns false for a
    /// 32-bit binary running on 64-bit Windows (WOW64), in which case filesystem redirection
    /// must be disabled so the real System32 event logs can be read.
    fn is_matched_architecture_and_binary(&self) -> bool {
        if cfg!(target_os = "windows") {
            let is_processor_arch_32bit = env::var_os("PROCESSOR_ARCHITECTURE")
                .unwrap_or_default()
                .eq("x86");
            // PROCESSOR_ARCHITEW6432 does not exist in 32-bit environments, so if the environment variable does not exist, it is determined to be a 32-bit environment.
            let not_wow_flag = env::var_os("PROCESSOR_ARCHITEW6432")
                .unwrap_or_else(|| OsString::from("x86"))
                .eq("x86");
            return (cfg!(target_pointer_width = "64") && !is_processor_arch_32bit)
                || (cfg!(target_pointer_width = "32") && is_processor_arch_32bit && not_wow_flag);
        }
        true
    }

    /// Returns false when a subcommand that requires arguments was invoked with none (i.e. argv
    /// only contains the program name and the subcommand), so that its help can be printed
    /// instead of running.
    fn check_is_valid_args_num(&self, action: Option<&Action>) -> bool {
        // Under `cargo test`, `env::args()` is the test harness's argv (e.g. it
        // contains `--test-threads=1` or a test-name filter), not hayabusa's own
        // arguments, so this "subcommand run with no args" heuristic would misfire
        // and make the app print help and return early. Skip it in test builds.
        // See https://github.com/Yamato-Security/hayabusa/issues/1170
        if cfg!(test) {
            return true;
        }
        match action.as_ref().unwrap() {
            Action::DfirTimeline(_)
            | Action::LogonSummary(_)
            | Action::EidMetrics(_)
            | Action::PivotKeywordsList(_)
            | Action::SetDefaultProfile(_)
            | Action::Search(_)
            | Action::ComputerMetrics(_) => env::args().len() != 2,
            _ => true,
        }
    }
}

#[cfg(test)]
mod tests {
    use std::{
        fs::{self, File, remove_file},
        path::Path,
        sync::Arc,
    };

    use chrono::{DateTime, Local};
    use hashbrown::HashSet;
    use yaml_rust2::YamlLoader;

    use crate::{App, add_general_overview_header};
    use hayabusa::{
        detections::{
            configs::{
                Action, ClobberOption, ComputerMetricsOption, Config, ConfigReader,
                DetectCommonOption, DfirTimelineOption, EidMetricsOption, InputOption,
                LogonSummaryOption, OutputOption, OutputType, StoredStatic, TargetEventTime,
                TargetIds,
            },
            detection,
            rule::create_rule,
        },
        options::htmlreport::{GENERAL_OVERVIEW_SECTION, HtmlReporter},
        results::{self, ResultOutputState},
        timeline::timelines::Timeline,
    };

    fn create_dummy_stored_static() -> StoredStatic {
        StoredStatic::create_static_data(Config {
            action: Some(Action::DfirTimeline(DfirTimelineOption {
                output_options: OutputOption {
                    min_level: "informational".to_string(),
                    detect_common_options: DetectCommonOption {
                        json_input: true,
                        ..Default::default()
                    },
                    no_wizard: true,
                    sort_events: true,
                    ..Default::default()
                },
                ..Default::default()
            })),
            debug: false,
        })
    }

    #[test]
    fn test_collect_evtxfiles() {
        let files = App::collect_evtxfiles(
            "test_files/evtx",
            &HashSet::from(["evtx".to_string()]),
            &create_dummy_stored_static(),
        );
        assert_eq!(3, files.len());

        files.iter().for_each(|file| {
            let is_contains = &vec!["test1.evtx", "test2.evtx", "testtest4.evtx"]
                .into_iter()
                .any(|filepath_str| {
                    file.file_name().unwrap().to_str().unwrap_or("") == filepath_str
                });
            assert_eq!(is_contains, &true);
        })
    }

    #[test]
    /// `collect_evtxfiles` must return files in sorted path order however `read_dir` lists them,
    /// so an unsorted timeline is written in the same order on every OS and filesystem.
    fn test_collect_evtxfiles_returns_sorted_paths() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path();
        // Created in an order that is neither sorted nor reverse-sorted, so the test cannot pass
        // by accident on a filesystem that lists entries in (reverse) creation order.
        for name in [
            "d.evtx",
            "a.evtx",
            "c.evtx",
            "b.evtx",
            ".hidden.evtx",
            "notes.txt",
        ] {
            fs::write(root.join(name), b"").unwrap();
        }
        fs::create_dir(root.join("b")).unwrap();
        for name in ["y.evtx", "x.evtx"] {
            fs::write(root.join("b").join(name), b"").unwrap();
        }

        let files = App::collect_evtxfiles(
            root.to_str().unwrap(),
            &HashSet::from(["evtx".to_string()]),
            &create_dummy_stored_static(),
        );

        // Depth-first in component-wise order, so the `b` directory comes before `b.evtx`. The
        // hidden file and the non-evtx file are skipped as before.
        let expected = vec![
            root.join("a.evtx"),
            root.join("b").join("x.evtx"),
            root.join("b").join("y.evtx"),
            root.join("b.evtx"),
            root.join("c.evtx"),
            root.join("d.evtx"),
        ];
        assert_eq!(files, expected);
    }

    #[test]
    fn test_exec_none_storedstatic() {
        let mut app = App::new(None);
        let mut config_reader = ConfigReader::new();
        let mut stored_static = StoredStatic::create_static_data(config_reader.config.unwrap());
        config_reader.config = None;
        stored_static.profiles = None;
        app.exec(&mut config_reader.app, &mut stored_static);
    }

    #[test]
    fn test_exec_general_html_output() {
        // Exercise the real header helper that exec calls, so the test and exec cannot drift.
        let analysis_start_time: DateTime<Local> = Local::now();
        let mut html_reporter = HtmlReporter::new();
        add_general_overview_header(&mut html_reporter, analysis_start_time);

        let general_contents = html_reporter
            .section_markdown
            .get(GENERAL_OVERVIEW_SECTION)
            .unwrap();
        let lines: Vec<&str> = general_contents.iter().collect();
        assert_eq!(lines.len(), 2);
        assert!(
            lines
                .iter()
                .any(|line| line.starts_with("- Command line: "))
        );
        assert!(lines.iter().any(|line| line.starts_with("- Start time: ")));
    }

    // End-to-end guard for the HtmlReporter threading: run `exec` with `--html-report` against a
    // JSON fixture and assert the rendered report file contains the sections `exec`'s single
    // threaded reporter accumulates. This proves `exec` builds one reporter, threads it through
    // analysis, and renders that same instance (which the header-helper unit test cannot).
    #[test]
    fn test_exec_html_report_end_to_end() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let report_path = output_tmp_dir.path().join("test_exec_html_report_e2e.html");
        let csv_path = output_tmp_dir.path().join("test_exec_html_report_e2e.csv");
        let mut app = App::new(None);
        let action = Action::DfirTimeline(DfirTimelineOption {
            output_options: OutputOption {
                input_args: InputOption {
                    filepath: Some(Path::new("test_files/evtx/test.json").to_path_buf()),
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                rules: Path::new("./test_files/rules/yaml/test_json_detect.yml").to_path_buf(),
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    config: Path::new("./rules/config").to_path_buf(),
                    ..Default::default()
                },
                html_report: Some(report_path.clone()),
                no_wizard: true,
                ..Default::default()
            },
            output: Some(csv_path.clone()),
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);

        let html = std::fs::read_to_string(&report_path)
            .expect("exec should have written the HTML report file");
        // The reporter exec threaded from start-up (General Overview: command line + start time)
        // through the summary path (Results Summary) is what gets rendered to the file.
        assert!(
            html.contains("General Overview"),
            "report is missing the General Overview section"
        );
        assert!(
            html.contains("Command line:"),
            "report is missing the General Overview command-line entry"
        );
        assert!(
            html.contains("Results Summary"),
            "report is missing the Results Summary section"
        );

        std::fs::remove_file(&report_path).ok();
        std::fs::remove_file(&csv_path).ok();
    }

    #[test]
    fn test_analysis_json_file() {
        let mut app = App::new(None);
        let stored_static = create_dummy_stored_static();
        let stored_static_arc = Arc::new(stored_static.clone());

        let rule_str = r#"
        enabled: true
        detection:
            selection1:
                Channel: 'Microsoft-Windows-Sysmon/Operational'
            condition: selection1
        details: testdata
        "#;
        let mut rule_yaml = YamlLoader::load_from_str(rule_str).unwrap().into_iter();
        let test_yaml_data = rule_yaml.next().unwrap();
        let mut rule = create_rule("testpath".to_string(), test_yaml_data);
        let rule_init = rule.init(&stored_static);
        assert!(rule_init.is_ok());
        let rule_files = vec![rule];
        app.rule_keys = app.get_all_keys(&rule_files);
        let detection = detection::Detection::new(rule_files);
        let target_time_filter = TargetEventTime::new(&stored_static);
        let timeline = Timeline::default();
        let target_event_ids = TargetIds::default();
        let mut result_state = ResultOutputState::default();
        let mut output_writer = results::init_writer(&stored_static);

        let actual = app.analysis_json_file(
            (
                Path::new("test_files/evtx/test.jsonl").to_path_buf(),
                &target_time_filter,
                &target_event_ids,
                &stored_static,
            ),
            &stored_static_arc,
            detection,
            timeline,
            &mut output_writer,
            &mut result_state,
        );
        assert_eq!(actual.1, 2);
        // Buffered (not low-memory): both matching records are collected into detect_infos rather
        // than streamed (the low-memory variant asserts this is 0).
        assert_eq!(actual.4.len(), 2);
    }

    #[test]
    fn test_same_file_output_csv_exit() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_csv_exit_csv = output_tmp_dir.path().join("overwrite_csv_exit.csv");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_csv_exit_csv).ok();
        let action = Action::DfirTimeline(DfirTimelineOption {
            output_options: OutputOption {
                input_args: InputOption {
                    filepath: Some(Path::new("test_files/evtx/test.json").to_path_buf()),
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                rules: Path::new("./test_files/rules/yaml/test_json_detect.yml").to_path_buf(),
                no_summary: true,
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                no_wizard: true,
                ..Default::default()
            },
            output: Some(out_overwrite_csv_exit_csv.clone()),
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        // TODO add check
        // assert_eq!(MESSAGES.len(), 0);

        // Delete the test file.
        remove_file(&out_overwrite_csv_exit_csv).ok();
    }

    #[test]
    fn test_overwrite_csv() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_csv_clobber_csv = output_tmp_dir.path().join("overwrite_csv_clobber.csv");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_csv_clobber_csv).ok();
        let action = Action::DfirTimeline(DfirTimelineOption {
            output_options: OutputOption {
                input_args: InputOption {
                    filepath: Some(Path::new("test_files/evtx/test.json").to_path_buf()),
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                rules: Path::new("test_files/rules/yaml/test_json_detect.yml").to_path_buf(),
                no_summary: true,
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                clobber_opt: ClobberOption { clobber: true },
                no_wizard: true,
                ..Default::default()
            },
            output: Some(out_overwrite_csv_clobber_csv.clone()),
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        // TODO add check
        // assert_ne!(MESSAGES.len(), 0);
        // Delete the test file.
        remove_file(&out_overwrite_csv_clobber_csv).ok();
    }

    #[test]
    fn test_same_file_output_json_exit() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_json_exit_json = output_tmp_dir.path().join("overwrite_json_exit.json");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_json_exit_json).ok();
        let action = Action::DfirTimeline(DfirTimelineOption {
            output_options: OutputOption {
                input_args: InputOption {
                    filepath: Some(Path::new("test_files/evtx/test.json").to_path_buf()),
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                rules: Path::new("./test_files/rules/yaml/test_json_detect.yml").to_path_buf(),
                no_summary: true,
                detect_common_options: DetectCommonOption {
                    config: Path::new("./rules/config").to_path_buf(),
                    json_input: true,
                    ..Default::default()
                },
                no_wizard: true,
                ..Default::default()
            },
            output: Some(out_overwrite_json_exit_json.clone()),
            // Without this the fixture falls back to `OutputType::default()` (CSV), so a
            // test named `..._json` writing a `.json` path exercises the CSV writer.
            output_type: OutputType::Json,
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        // TODO add check
        // assert_eq!(MESSAGES.len(), 0);

        // Delete the test file.
        remove_file(&out_overwrite_json_exit_json).ok();
    }

    #[test]
    fn test_overwrite_json() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_json_clobber_json =
            output_tmp_dir.path().join("overwrite_json_clobber.json");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_json_clobber_json).ok();
        let action = Action::DfirTimeline(DfirTimelineOption {
            output_options: OutputOption {
                input_args: InputOption {
                    filepath: Some(Path::new("test_files/evtx/test.json").to_path_buf()),
                    ..Default::default()
                },
                min_level: "informational".to_string(),
                rules: Path::new("test_files/rules/yaml/test_json_detect.yml").to_path_buf(),
                no_summary: true,
                detect_common_options: DetectCommonOption {
                    json_input: true,
                    ..Default::default()
                },
                clobber_opt: ClobberOption { clobber: true },
                no_wizard: true,
                ..Default::default()
            },
            output: Some(out_overwrite_json_clobber_json.clone()),
            // Without this the fixture falls back to `OutputType::default()` (CSV), so a
            // test named `..._json` writing a `.json` path exercises the CSV writer.
            output_type: OutputType::Json,
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        // TODO add check
        // assert_ne!(MESSAGES.len(), 0);
        // Delete the test file.
        remove_file(&out_overwrite_json_clobber_json).ok();
    }

    #[test]
    fn test_same_file_output_metric_csv_exit() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_metric_exit_csv = output_tmp_dir.path().join("overwrite_metric_exit.csv");
        let out_overwrite_metric_exit = output_tmp_dir.path().join("overwrite_metric_exit");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_metric_exit_csv).ok();
        let action = Action::EidMetrics(EidMetricsOption {
            output: Some(out_overwrite_metric_exit_csv.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            detect_common_options: DetectCommonOption {
                json_input: true,
                ..Default::default()
            },
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_metric_exit_csv).unwrap();
        assert_eq!(meta.len(), 0);

        // Delete the test file.
        remove_file(&out_overwrite_metric_exit_csv).ok();
        remove_file(&out_overwrite_metric_exit).ok();
    }

    #[test]
    fn test_same_file_output_metric_csv() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_metric_clobber_csv =
            output_tmp_dir.path().join("overwrite_metric_clobber.csv");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_metric_clobber_csv).ok();
        let action = Action::EidMetrics(EidMetricsOption {
            output: Some(out_overwrite_metric_clobber_csv.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            detect_common_options: DetectCommonOption {
                json_input: true,
                ..Default::default()
            },
            clobber_opt: ClobberOption { clobber: true },
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_metric_clobber_csv).unwrap();
        assert_ne!(meta.len(), 0);
        // Delete the test file.
        remove_file(&out_overwrite_metric_clobber_csv).ok();
    }

    #[test]
    fn test_same_file_output_logon_summary_csv_exit() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_logon_exit_successful_csv = output_tmp_dir
            .path()
            .join("overwrite_logon_exit-successful.csv");
        let out_overwrite_logon_exit = output_tmp_dir.path().join("overwrite_logon_exit");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_logon_exit_successful_csv).ok();
        let action = Action::LogonSummary(LogonSummaryOption {
            output: Some(out_overwrite_logon_exit.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            detect_common_options: DetectCommonOption {
                json_input: true,
                ..Default::default()
            },
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_logon_exit_successful_csv).unwrap();
        assert_eq!(meta.len(), 0);

        // Delete the test file.
        remove_file(&out_overwrite_logon_exit_successful_csv).ok();
    }

    #[test]
    fn test_same_file_output_logon_summary_csv() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_logon_clobber_successful_csv = output_tmp_dir
            .path()
            .join("overwrite_logon_clobber-successful.csv");
        let out_overwrite_logon_clobber_failed_csv = output_tmp_dir
            .path()
            .join("overwrite_logon_clobber-failed.csv");
        let out_overwrite_logon_clobber = output_tmp_dir.path().join("overwrite_logon_clobber");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_logon_clobber_successful_csv).ok();
        let action = Action::LogonSummary(LogonSummaryOption {
            output: Some(out_overwrite_logon_clobber.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            detect_common_options: DetectCommonOption {
                json_input: true,
                ..Default::default()
            },
            clobber_opt: ClobberOption { clobber: true },
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_logon_clobber_successful_csv).unwrap();
        assert_ne!(meta.len(), 0);
        // Delete the test files (LogonSummary writes both -successful and -failed).
        remove_file(&out_overwrite_logon_clobber_successful_csv).ok();
        remove_file(&out_overwrite_logon_clobber_failed_csv).ok();
    }

    #[test]
    fn test_same_file_output_computer_metrics_exit() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_computer_exit_csv =
            output_tmp_dir.path().join("overwrite_computer_exit.csv");
        let out_overwrite_computer_exit = output_tmp_dir.path().join("overwrite_computer_exit");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_computer_exit_csv).ok();
        let action = Action::ComputerMetrics(ComputerMetricsOption {
            output: Some(out_overwrite_computer_exit_csv.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            config: Path::new("./rules/config").to_path_buf(),
            json_input: true,
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_computer_exit_csv).unwrap();
        assert_eq!(meta.len(), 0);
        // Delete the test file.
        remove_file(&out_overwrite_computer_exit).ok();
        remove_file(&out_overwrite_computer_exit_csv).ok();
    }

    #[test]
    fn test_same_file_output_computer_metrics_csv() {
        let output_tmp_dir = tempfile::tempdir().unwrap();
        let out_overwrite_computer_clobber_csv =
            output_tmp_dir.path().join("overwrite_computer_clobber.csv");
        // Create an empty file first.
        let mut app = App::new(None);
        File::create(&out_overwrite_computer_clobber_csv).ok();
        let action = Action::ComputerMetrics(ComputerMetricsOption {
            output: Some(out_overwrite_computer_clobber_csv.clone()),
            input_args: InputOption {
                filepath: Some(Path::new("test_files/evtx/test_metrics.json").to_path_buf()),
                ..Default::default()
            },
            json_input: true,
            clobber_opt: ClobberOption { clobber: true },
            ..Default::default()
        });
        let config = Config {
            action: Some(action),
            debug: false,
        };
        let mut stored_static = StoredStatic::create_static_data(config);
        let mut config_reader = ConfigReader::new();
        app.exec(&mut config_reader.app, &mut stored_static);
        let meta = fs::metadata(&out_overwrite_computer_clobber_csv).unwrap();
        assert_ne!(meta.len(), 0);
        // Delete the test file.
        remove_file(&out_overwrite_computer_clobber_csv).ok();
    }

    #[test]
    fn test_analysis_json_file_include_eid() {
        let mut app = App::new(None);
        let mut stored_static = create_dummy_stored_static();
        stored_static.include_eid = HashSet::from_iter(vec!["10".into()]);
        let stored_static_arc = Arc::new(stored_static.clone());

        let rule_str = r#"
        enabled: true
        detection:
            selection1:
                Channel: 'Microsoft-Windows-Sysmon/Operational'
            condition: selection1
        details: testdata
        "#;
        let mut rule_yaml = YamlLoader::load_from_str(rule_str).unwrap().into_iter();
        let test_yaml_data = rule_yaml.next().unwrap();
        let mut rule = create_rule("testpath".to_string(), test_yaml_data);
        let rule_init = rule.init(&stored_static);
        assert!(rule_init.is_ok());
        let rule_files = vec![rule];
        app.rule_keys = app.get_all_keys(&rule_files);
        let detection = detection::Detection::new(rule_files);
        let target_time_filter = TargetEventTime::new(&stored_static);
        let timeline = Timeline::default();
        let target_event_ids = TargetIds::default();
        let mut result_state = ResultOutputState::default();
        let mut output_writer = results::init_writer(&stored_static);

        let actual = app.analysis_json_file(
            (
                Path::new("test_files/evtx/test.jsonl").to_path_buf(),
                &target_time_filter,
                &target_event_ids,
                &stored_static,
            ),
            &stored_static_arc,
            detection,
            timeline,
            &mut output_writer,
            &mut result_state,
        );
        assert_eq!(actual.1, 2);
        assert_eq!(actual.4.len(), 1);
    }

    #[test]
    fn test_analysis_json_file_exclude_eid() {
        let mut app = App::new(None);
        let mut stored_static = create_dummy_stored_static();
        stored_static.exclude_eid = HashSet::from_iter(vec!["10".into(), "11".into()]);
        let stored_static_arc = Arc::new(stored_static.clone());

        let rule_str = r#"
        enabled: true
        detection:
            selection1:
                Channel: 'Microsoft-Windows-Sysmon/Operational'
            condition: selection1
        details: testdata
        "#;
        let mut rule_yaml = YamlLoader::load_from_str(rule_str).unwrap().into_iter();
        let test_yaml_data = rule_yaml.next().unwrap();
        let mut rule = create_rule("testpath".to_string(), test_yaml_data);
        let rule_init = rule.init(&stored_static);
        assert!(rule_init.is_ok());
        let rule_files = vec![rule];
        app.rule_keys = app.get_all_keys(&rule_files);
        let detection = detection::Detection::new(rule_files);
        let target_time_filter = TargetEventTime::new(&stored_static);
        let timeline = Timeline::default();
        let target_event_ids = TargetIds::default();
        let mut result_state = ResultOutputState::default();
        let mut output_writer = results::init_writer(&stored_static);

        let actual = app.analysis_json_file(
            (
                Path::new("test_files/evtx/test.jsonl").to_path_buf(),
                &target_time_filter,
                &target_event_ids,
                &stored_static,
            ),
            &stored_static_arc,
            detection,
            timeline,
            &mut output_writer,
            &mut result_state,
        );
        assert_eq!(actual.1, 2);
        assert_eq!(actual.4.len(), 0);
    }

    #[test]
    fn test_analysis_json_file_low_memory_mode() {
        let mut app = App::new(None);
        let mut stored_static = create_dummy_stored_static();
        stored_static.include_eid = HashSet::from_iter(vec!["10".into()]);
        stored_static.is_low_memory = true;
        let stored_static_arc = Arc::new(stored_static.clone());

        let rule_str = r#"
        enabled: true
        detection:
            selection1:
                Channel: 'Microsoft-Windows-Sysmon/Operational'
            condition: selection1
        details: testdata
        "#;
        let mut rule_yaml = YamlLoader::load_from_str(rule_str).unwrap().into_iter();
        let test_yaml_data = rule_yaml.next().unwrap();
        let mut rule = create_rule("testpath".to_string(), test_yaml_data);
        let rule_init = rule.init(&stored_static);
        assert!(rule_init.is_ok());
        let rule_files = vec![rule];
        app.rule_keys = app.get_all_keys(&rule_files);
        let detection = detection::Detection::new(rule_files);
        let target_time_filter = TargetEventTime::new(&stored_static);
        let timeline = Timeline::default();
        let target_event_ids = TargetIds::default();
        let mut result_state = ResultOutputState::default();
        let mut output_writer = results::init_writer(&stored_static);

        let actual = app.analysis_json_file(
            (
                Path::new("test_files/evtx/test.jsonl").to_path_buf(),
                &target_time_filter,
                &target_event_ids,
                &stored_static,
            ),
            &stored_static_arc,
            detection,
            timeline,
            &mut output_writer,
            &mut result_state,
        );
        assert_eq!(actual.1, 2);
        assert_eq!(actual.4.len(), 0);
    }

    // A focused test of the extracted stream-vs-buffer policy: the default (sorted) mode moves the
    // batch into the buffer and drains it from the input; low-memory (unsorted) mode emits the
    // batch and leaves the buffer untouched. This locks down `emit_or_buffer` independently of the
    // evtx/JSON accumulation paths.
    #[test]
    fn test_emit_or_buffer_policy() {
        let stored_static = create_dummy_stored_static();
        let mut output_writer = results::init_writer(&stored_static);
        let mut result_state = ResultOutputState::default();

        // Buffered: records move into the buffer and the input list is emptied.
        let mut buffer = vec![];
        let mut log_records = vec![
            hayabusa::detections::message::DetectInfo::default(),
            hayabusa::detections::message::DetectInfo::default(),
        ];
        crate::emit_or_buffer(
            &mut log_records,
            &mut buffer,
            &stored_static,
            &mut output_writer,
            &mut result_state,
        );
        assert_eq!(buffer.len(), 2);
        assert!(log_records.is_empty());

        // Low-memory (unsorted timeline): the batch is streamed, so the buffer stays empty.
        let mut low = create_dummy_stored_static();
        low.is_low_memory = true;
        let mut low_writer = results::init_writer(&low);
        let mut buffer_low = vec![];
        let mut log_records_low = vec![hayabusa::detections::message::DetectInfo::default()];
        crate::emit_or_buffer(
            &mut log_records_low,
            &mut buffer_low,
            &low,
            &mut low_writer,
            &mut result_state,
        );
        assert!(buffer_low.is_empty());
    }

    #[test]
    fn test_calculate_wizard_rule_count() {
        use crate::{WizardCountFilter, calculate_wizard_rule_count};
        use compact_str::CompactString;
        use hashbrown::HashMap;

        // Build one status's `level -> tag -> count` map.
        fn lvl(
            pairs: &[(&str, &[(&str, i128)])],
        ) -> HashMap<CompactString, HashMap<CompactString, i128>> {
            pairs
                .iter()
                .map(|(level, tags)| {
                    (
                        CompactString::from(*level),
                        tags.iter()
                            .map(|(tag, count)| (CompactString::from(*tag), *count))
                            .collect(),
                    )
                })
                .collect()
        }

        // status -> level -> tag -> count
        let mut map: HashMap<CompactString, HashMap<CompactString, HashMap<CompactString, i128>>> =
            HashMap::new();
        map.insert(
            "stable".into(),
            lvl(&[
                ("high", &[("sysmon", 3), ("detection.emerging_threats", 2)]),
                ("low", &[("", 5)]),
            ]),
        );
        map.insert("test".into(), lvl(&[("critical", &[("", 4)])]));
        map.insert("deprecated".into(), lvl(&[("high", &[("", 7)])]));
        map.insert("noisy".into(), lvl(&[("medium", &[("", 9)])]));

        // (A) Per-status counts at/above HIGH, skipping the noisy/deprecated statuses.
        let per_status_counts = calculate_wizard_rule_count(
            &map,
            WizardCountFilter {
                exclude_noisytarget_flag: false,
                exclude_noisy_status: ["excluded", "deprecated", "unsupported", "noisy"].to_vec(),
                min_level: "high",
                target_status: ["test", "stable"].to_vec(),
                target_tags: [].to_vec(),
            },
        );
        assert_eq!(per_status_counts.get("stable"), Some(&5)); // 3 + 2 at HIGH; LOW(5) is below HIGH
        assert_eq!(per_status_counts.get("test"), Some(&4)); // CRITICAL >= HIGH
        assert_eq!(per_status_counts.get("deprecated"), None); // excluded status
        assert_eq!(per_status_counts.get("noisy"), None);
        assert_eq!(per_status_counts.len(), 2);

        // (B) Exclude-noisy mode: count only the listed noisy statuses, at/above MEDIUM.
        let noisy_status_counts = calculate_wizard_rule_count(
            &map,
            WizardCountFilter {
                exclude_noisytarget_flag: true,
                exclude_noisy_status: ["deprecated", "noisy"].to_vec(),
                min_level: "medium",
                target_status: [].to_vec(),
                target_tags: [].to_vec(),
            },
        );
        assert_eq!(noisy_status_counts.get("deprecated"), Some(&7));
        assert_eq!(noisy_status_counts.get("noisy"), Some(&9));
        assert_eq!(noisy_status_counts.len(), 2);

        // (C) Tag counts: only the requested tags at/above HIGH for the "stable" status; no
        // per-status entry is produced when `target_tags` is set.
        let tag_counts = calculate_wizard_rule_count(
            &map,
            WizardCountFilter {
                exclude_noisytarget_flag: false,
                exclude_noisy_status: [].to_vec(),
                min_level: "high",
                target_status: ["stable"].to_vec(),
                target_tags: ["sysmon", "detection.emerging_threats"].to_vec(),
            },
        );
        assert_eq!(tag_counts.get("sysmon"), Some(&3));
        assert_eq!(tag_counts.get("detection.emerging_threats"), Some(&2));
        assert_eq!(tag_counts.len(), 2);
    }
}
